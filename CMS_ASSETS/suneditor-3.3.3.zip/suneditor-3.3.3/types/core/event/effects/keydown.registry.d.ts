import type {} from '../../../typedef';
declare const _default: {
	/**  [backspace and delete]  */
	/** @action delFormatRemoveAndMove */
	'del.format.removeAndMove': ({ ports }: EffectContext_keydown, { container, formatEl }: any) => void;
	/** [backspace]  */
	/** @action backspaceBrLineStrip — extract first line from brLine (PRE) */
	'backspace.brline.strip': ({ ctx, ports }: EffectContext_keydown, { formatEl }: any) => void;
	/** @action backspaceFormatMaintain */
	'backspace.format.maintain': ({ ctx }: EffectContext_keydown, { formatEl }: any) => void;
	/** @action backspaceComponentSelect */
	'backspace.component.select': (
		{ ports }: EffectContext_keydown,
		{ selectionNode, range, fileComponentInfo }: any,
	) => void;
	/** @action backspaceComponentRemove */
	'backspace.component.remove': (
		{ ports }: EffectContext_keydown,
		{ isList, sel, formatEl, fileComponentInfo }: any,
	) => void;
	/** @action backspaceListMergePrev */
	'backspace.list.mergePrev': ({ ports }: EffectContext_keydown, { prev, formatEl, rangeEl }: any) => void;
	/** @action backspaceListRemoveNested */
	'backspace.list.removeNested': ({ ports }: EffectContext_keydown, { range }: any) => void;
	/** @action backspaceEmptyLineMergePrev */
	'backspace.emptyLine.mergePrev': ({ ports }: EffectContext_keydown, { formatEl, prev }: any) => void;
	/** @action backspaceBrLineRowMerge */
	'backspace.brline.rowMerge': ({ ports }: EffectContext_keydown, { rowEndBr, rowStartBr }: any) => void;
	/** @action backspaceSoftBreakMerge */
	'backspace.softBreak.merge': ({ ports }: EffectContext_keydown, { zws }: any) => void;
	/** [delete] */
	/** @action deleteComponentSelect */
	'delete.component.select': ({ ports }: EffectContext_keydown, { formatEl, fileComponentInfo }: any) => void;
	/** @action deleteComponentSelectNext */
	'delete.component.selectNext': ({ ports, ctx }: EffectContext_keydown, { formatEl, nextEl }: any) => void;
	/** @action deleteListRemoveNested */
	'delete.list.removeNested': ({ ports, ctx }: EffectContext_keydown, { range, formatEl, rangeEl }: any) => void;
	/** @action deleteEmptyLineMergeNext — remove an empty line, move caret to the start of the next line */
	'delete.emptyLine.mergeNext': ({ ports }: EffectContext_keydown, { formatEl, next }: any) => void;
	/**
	 * @action mergeLineInto — Merge one line into another across a block boundary.
	 */
	'line.merge': ({ ports }: EffectContext_keydown, { into, from }: any) => void;
	/** @action deleteBrLineRowMerge — remove an empty row inside a brLine (PRE), pull the next row up */
	'delete.brline.rowMerge': ({ ports }: EffectContext_keydown, { rowEndBr }: any) => void;
	/** @action deleteSoftBreakMerge */
	'delete.softBreak.merge': ({ ports }: EffectContext_keydown, { br }: any) => void;
	/** [tab] */
	/** @action tabFormatIndent */
	'tab.format.indent': ({ ports, ctx }: EffectContext_keydown, { range, formatEl, shift }: any) => boolean;
	/** [caret] */
	/** @action caretScrollTo */
	'caret.scrollTo': ({ ports }: EffectContext_keydown, { range }: any) => void;
	/** [enter] */
	/** @action enterLineAddDefault */
	'enter.line.addDefault': ({ ports }: EffectContext_keydown, { formatEl }: any) => void;
	/** @action enterListAddItem */
	'enter.list.addItem': ({ ports }: EffectContext_keydown, { formatEl, selectionNode }: any) => void;
	/** @action enterFormatExitEmpty */
	'enter.format.exitEmpty': ({ ports, ctx }: EffectContext_keydown, { formatEl, rangeEl }: any) => void;
	/** @action enterFormatCleanBrAndZWS */
	'enter.format.cleanBrAndZWS': (
		{ ports }: EffectContext_keydown,
		{ selectionNode, selectionFormat, brBlock, children, offset }: any,
	) => void;
	/** @action enterFormatInsertBrHtml */
	'enter.format.insertBrHtml': (
		{ ports }: EffectContext_keydown,
		{ brBlock, range, wSelection, offset }: any,
	) => void;
	/** @action enterBrLineInsert — insert exactly one empty row at the caret inside a normal brLine. */
	'enter.brline.insert': ({ ports }: EffectContext_keydown, { range }: any) => void;
	/** @action enterShiftBr — soft line break (Shift+Enter): insert a `<br>` at the caret, splitting the line. */
	'enter.shift.br': ({ ports, ctx }: EffectContext_keydown, { range }: any) => void;
	/** @action enterBrLineExit — consume only the caret's current (last) empty row and add a default line after the brLine. */
	'enter.brline.exit': ({ ports }: EffectContext_keydown, { brBlock }: any) => void;
	/** @action enterFormatInsertBrNode */
	'enter.format.insertBrNode': ({ ports }: EffectContext_keydown, { wSelection }: any) => void;
	/** @action enterFormatBreakAtEdge */
	'enter.format.breakAtEdge': (
		{ ports, ctx }: EffectContext_keydown,
		{ formatEl, selectionNode, formatStartEdge, formatEndEdge, bidiSwapped }: any,
	) => void;
	/** @action enterFormatBreakWithSelection */
	'enter.format.breakWithSelection': (
		{ ports, ctx }: EffectContext_keydown,
		{ formatEl, range, formatStartEdge, formatEndEdge }: any,
	) => void;
	/** @action enterFormatBreakAtCursor */
	'enter.format.breakAtCursor': ({ ports, ctx }: EffectContext_keydown, { formatEl, range }: any) => void;
	/** @action enterFigcaptionExitInList */
	'enter.figcaption.exitInList': ({ ports }: EffectContext_keydown, { formatEl }: any) => void;
	/** [keydown reducer] */
	/** @action keydownInputInsertNbsp */
	'keydown.input.insertNbsp': ({ ports }: EffectContext_keydown) => void;
	/** @action keydownInputInsertZWS */
	'keydown.input.insertZWS': ({ ports }: EffectContext_keydown) => void;
};
export default _default;
export type EffectContext_keydown = {
	/**
	 * - Ports for interacting with editor
	 */
	ports: import('../ports').EventReducerPorts;
	/**
	 * - Reducer context
	 */
	ctx: import('../reducers/keydown.reducer').KeydownReducerCtx;
};
export type Effect = (ctx: EffectContext_keydown, payload?: any) => any;
/**
 * @param {HTMLElement} formatEl - Format element
 * @returns {Node}
 */
export function LineDelete_next(formatEl: HTMLElement): Node;
/**
 * @param {HTMLElement} formatEl - Format element
 * @returns {{focusNode: Node, focusOffset: number}}
 */
export function LineDelete_prev(formatEl: HTMLElement): {
	focusNode: Node;
	focusOffset: number;
};
