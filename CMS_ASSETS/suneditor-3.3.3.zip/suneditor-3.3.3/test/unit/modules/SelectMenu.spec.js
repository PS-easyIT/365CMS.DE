/**
 * @fileoverview Unit tests for modules/SelectMenu.js
 */

import SelectMenu from '../../../src/modules/ui/SelectMenu.js';
import { createMockEditor } from '../../../test/__mocks__/editorMock.js';

// Mock dependencies

jest.mock('../../../src/helper', () => ({
	dom: {
		check: {
			isElement: jest.fn().mockReturnValue(true),
			isInputElement: jest.fn().mockReturnValue(false)
		},
		utils: {
			addClass: jest.fn(),
			removeClass: jest.fn(),
			toggleClass: jest.fn(),
			hasClass: jest.fn().mockReturnValue(false),
			createElement: jest.fn().mockImplementation((tag, attrs, innerHTML) => {
				const el = global.document.createElement(tag || 'div');
				if (attrs) {
					Object.keys(attrs).forEach((attr) => {
						el.setAttribute(attr, attrs[attr]);
					});
				}
				if (innerHTML) {
					el.innerHTML = innerHTML;
				}
				return el;
			}),
			getClientSize: jest.fn().mockReturnValue({ w: 1024, h: 768 })
		},
		query: {
			getEventTarget: jest.fn((e) => e.target),
			getParentElement: jest.fn((el) => el.parentElement)
		}
	},
	env: { _w: { innerWidth: 1024, innerHeight: 768, scrollX: 0, scrollY: 0 }, isGecko: false },
	keyCodeMap: { isEsc: jest.fn((code) => code === 'Escape') }
}));

describe('Modules - SelectMenu', () => {
	let mockInst;
	let mockEditor;
	let openSelectMenus;

	beforeEach(() => {
		jest.clearAllMocks();
		openSelectMenus = new Set();

		// Use createMockEditor for the $ deps bag pattern
		const kernel = createMockEditor();
		mockEditor = kernel;

		// Override with custom mocks as needed
		mockEditor.$ = {
			...kernel.$,
			ui: {
				showSelectMenu: jest.fn(),
				hideSelectMenu: jest.fn(),
				// mirrors `UIManager`: derived from the open instances, not a last-writer-wins boolean
				setSelectMenuOpen: jest.fn((instance, open) => {
					if (open) openSelectMenus.add(instance);
					else openSelectMenus.delete(instance);
				}),
				get selectMenuOn() {
					return openSelectMenus.size > 0;
				}
			},
			selection: { getRangeElement: jest.fn(), ...kernel.$.selection },
			offset: {
				get: jest.fn(() => ({ left: 100, top: 50 })),
				getGlobal: jest.fn(() => ({ left: 100, top: 50 })),
				...kernel.$.offset
			},
			eventManager: {
				addGlobalEvent: jest.fn(() => 'mock-event-id'),
				removeGlobalEvent: jest.fn(),
				_injectActiveEvent: jest.fn(),
				...kernel.$.eventManager
			}
		};
		mockEditor.frameContext = new Map([['_ww', document.createElement('div')]]);
		mockEditor.options = new Map([['_rtl', false]]);

		mockInst = {
			editor: mockEditor,
			constructor: {
				key: 'testSelectMenu',
				name: 'TestSelectMenu'
			}
		};
	});

	describe('Constructor', () => {
		it('should initialize with checkList parameter', () => {
			const params = { position: 'top-center', checkList: true };
			const selectMenu = new SelectMenu(mockEditor.$, params);
			expect(selectMenu.checkList).toBe(true);
		});

		it('should initialize with splitNum for horizontal layout', () => {
			const params = { position: 'top-center', splitNum: 5 };
			const selectMenu = new SelectMenu(mockEditor.$, params);
			expect(selectMenu.splitNum).toBe(5);
			expect(selectMenu.horizontal).toBe(true);
		});

		it('should initialize with dir parameter', () => {
			const params = { position: 'top-center', dir: 'rtl' };
			const selectMenu = new SelectMenu(mockEditor.$, params);
			expect(selectMenu).toBeDefined();
		});

		it('should initialize with openMethod and closeMethod', () => {
			const openMethod = jest.fn();
			const closeMethod = jest.fn();
			const params = { position: 'top-center', openMethod, closeMethod };
			const selectMenu = new SelectMenu(mockEditor.$, params);
			expect(selectMenu.openMethod).toBe(openMethod);
			expect(selectMenu.closeMethod).toBe(closeMethod);
		});

		it('should initialize isOpen to false', () => {
			const params = { position: 'top-center' };
			const selectMenu = new SelectMenu(mockEditor.$, params);
			expect(selectMenu.isOpen).toBe(false);
		});

		it('should initialize index to -1', () => {
			const params = { position: 'top-center' };
			const selectMenu = new SelectMenu(mockEditor.$, params);
			expect(selectMenu.index).toBe(-1);
		});
	});

	describe('on method', () => {
		let selectMenu;
		let referElement;

		beforeEach(() => {
			const params = { position: 'top-center' };
			selectMenu = new SelectMenu(mockEditor.$, params);

			// Create a proper DOM structure
			const parent = document.createElement('div');
			referElement = document.createElement('button');
			parent.appendChild(referElement);
		});

		it('should initialize select menu and attach to reference element', () => {
			const selectMethod = jest.fn();
			const attr = { class: 'custom-class', style: 'color: red;' };

			selectMenu.on(referElement, selectMethod, attr);

			expect(selectMenu.form).toBeDefined();
			expect(selectMenu.form.parentNode).toBe(referElement.parentNode);
		});

		it('should handle empty attr parameter', () => {
			const selectMethod = jest.fn();

			expect(() => {
				selectMenu.on(referElement, selectMethod);
			}).not.toThrow();
		});
	});

	describe('create method', () => {
		let selectMenu;
		let referElement;

		beforeEach(() => {
			const params = { position: 'top-center' };
			selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			referElement = document.createElement('button');
			parent.appendChild(referElement);

			const selectMethod = jest.fn();
			selectMenu.on(referElement, selectMethod);
		});

		it('should create menu items from string array', () => {
			const items = ['Item 1', 'Item 2', 'Item 3'];
			selectMenu.create(items);

			expect(selectMenu.items).toEqual(items);
			expect(selectMenu.menuLen).toBe(3);
			expect(selectMenu.menus).toBeDefined();
			expect(selectMenu.menus.length).toBe(3);
		});

		it('should create menu items with separate menu display', () => {
			const items = ['cmd1', 'cmd2', 'cmd3'];
			const menus = ['<b>Display 1</b>', '<b>Display 2</b>', '<b>Display 3</b>'];
			selectMenu.create(items, menus);

			expect(selectMenu.items).toEqual(items);
			expect(selectMenu.menuLen).toBe(3);
		});

		it('should handle horizontal layout with splitNum', () => {
			const params = { position: 'top-center', splitNum: 2 };
			const horizontalMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			horizontalMenu.on(ref, jest.fn());

			const items = ['Item 1', 'Item 2', 'Item 3', 'Item 4'];
			horizontalMenu.create(items);

			expect(horizontalMenu.items).toEqual(items);
			expect(horizontalMenu.menuLen).toBe(4);
		});

		it('should clear previous menu items', () => {
			const items1 = ['Item 1', 'Item 2'];
			selectMenu.create(items1);
			expect(selectMenu.menuLen).toBe(2);

			const items2 = ['New 1', 'New 2', 'New 3'];
			selectMenu.create(items2);
			expect(selectMenu.menuLen).toBe(3);
			expect(selectMenu.items).toEqual(items2);
		});
	});

	describe('getItem and setItem methods', () => {
		let selectMenu;

		beforeEach(() => {
			const params = { position: 'top-center' };
			selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const referElement = document.createElement('button');
			parent.appendChild(referElement);

			selectMenu.on(referElement, jest.fn());

			const items = ['Item 1', 'Item 2', 'Item 3'];
			selectMenu.create(items);
		});

		it('should get item by index', () => {
			expect(selectMenu.getItem(0)).toBe('Item 1');
			expect(selectMenu.getItem(1)).toBe('Item 2');
			expect(selectMenu.getItem(2)).toBe('Item 3');
		});

		it('should set item by index', () => {
			selectMenu.setItem(1);
			expect(selectMenu.index).toBe(1);
			expect(selectMenu.item).toBe('Item 2');
		});

		it('should handle out of range index', () => {
			expect(selectMenu.getItem(10)).toBeUndefined();
		});
	});

	describe('open method', () => {
		let selectMenu;
		let referElement;

		beforeEach(() => {
			const params = { position: 'top-center' };
			selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			parent.style.position = 'relative';
			referElement = document.createElement('button');
			referElement.style.width = '100px';
			referElement.style.height = '30px';
			Object.defineProperty(referElement, 'offsetWidth', { value: 100 });
			Object.defineProperty(referElement, 'offsetHeight', { value: 30 });
			Object.defineProperty(referElement, 'offsetTop', { value: 100 });
			Object.defineProperty(referElement, 'offsetLeft', { value: 50 });
			parent.appendChild(referElement);
			document.body.appendChild(parent);

			selectMenu.on(referElement, jest.fn());

			const items = ['Item 1', 'Item 2', 'Item 3'];
			selectMenu.create(items);

			// Mock form dimensions
			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 150, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });
		});

		afterEach(() => {
			document.body.innerHTML = '';
		});

		it('should open select menu', () => {
			selectMenu.open();

			expect(mockEditor.$.ui.selectMenuOn).toBe(true);
			expect(selectMenu.isOpen).toBe(true);
			expect(mockEditor.eventManager.addGlobalEvent).toHaveBeenCalled();
		});

		it('should call openMethod if provided', () => {
			const openMethod = jest.fn();
			const params = { position: 'top-center', openMethod };
			const menuWithCallback = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			menuWithCallback.on(ref, jest.fn());
			menuWithCallback.create(['Item 1']);

			menuWithCallback.open();

			expect(openMethod).toHaveBeenCalled();
		});

		it('should handle position parameter', () => {
			selectMenu.open('bottom-left');
			expect(selectMenu.isOpen).toBe(true);
		});

		it('should handle onItemQuerySelector parameter', () => {
			selectMenu.open('top-center', '.se-select-item[data-index="1"]');
			expect(selectMenu.isOpen).toBe(true);
		});
	});

	describe('close method', () => {
		let selectMenu;

		beforeEach(() => {
			const params = { position: 'top-center' };
			selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const referElement = document.createElement('button');
			parent.appendChild(referElement);

			selectMenu.on(referElement, jest.fn());
			selectMenu.create(['Item 1', 'Item 2']);
		});

		it('should close select menu', () => {
			selectMenu.open();
			expect(selectMenu.isOpen).toBe(true);

			selectMenu.close();
			expect(mockEditor.$.ui.selectMenuOn).toBe(false);
			expect(selectMenu.isOpen).toBe(false);
			expect(selectMenu.index).toBe(-1);
			expect(selectMenu.item).toBeNull();
		});

		it('should call closeMethod if provided', () => {
			const closeMethod = jest.fn();
			const params = { position: 'top-center', closeMethod };
			const menuWithCallback = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			menuWithCallback.on(ref, jest.fn());
			menuWithCallback.create(['Item 1']);

			menuWithCallback.open();
			menuWithCallback.close();

			expect(closeMethod).toHaveBeenCalled();
		});

		it('should handle close when not open', () => {
			expect(() => {
				selectMenu.close();
			}).not.toThrow();
		});

		it('should reset index and item', () => {
			selectMenu.setItem(1);
			expect(selectMenu.index).toBe(1);

			selectMenu.close();
			expect(selectMenu.index).toBe(-1);
			expect(selectMenu.item).toBeNull();
		});
	});

	describe('Event handling', () => {
		let selectMenu;
		let referElement;
		let selectMethod;

		beforeEach(() => {
			const params = { position: 'top-center' };
			selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			referElement = document.createElement('button');
			Object.defineProperty(referElement, 'offsetWidth', { value: 100 });
			Object.defineProperty(referElement, 'offsetHeight', { value: 30 });
			Object.defineProperty(referElement, 'offsetTop', { value: 100 });
			Object.defineProperty(referElement, 'offsetLeft', { value: 50 });
			parent.appendChild(referElement);
			document.body.appendChild(parent);

			selectMethod = jest.fn();
			selectMenu.on(referElement, selectMethod);
			selectMenu.create(['Item 1', 'Item 2', 'Item 3']);

			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 150, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });
		});

		afterEach(() => {
			document.body.innerHTML = '';
		});

		it('should handle keyboard navigation - ArrowDown', () => {
			selectMenu.open();
			expect(selectMenu.index).toBe(-1);

			const event = new KeyboardEvent('keydown', { code: 'ArrowDown', bubbles: true });
			Object.defineProperty(event, 'preventDefault', { value: jest.fn() });
			Object.defineProperty(event, 'stopPropagation', { value: jest.fn() });

			selectMenu.form.dispatchEvent(event);

			// Since we can't directly test private methods, we just verify the menu is open
			expect(selectMenu.isOpen).toBe(true);
		});

		it('should handle keyboard navigation - Escape', () => {
			selectMenu.open();
			expect(selectMenu.isOpen).toBe(true);

			// Simulate global Escape key
			const event = { code: 'Escape' };
			const { keyCodeMap } = require('../../../src/helper');
			keyCodeMap.isEsc.mockReturnValue(true);

			// Manually trigger close (simulating what the event handler would do)
			if (keyCodeMap.isEsc(event.code)) {
				selectMenu.close();
			}

			expect(selectMenu.isOpen).toBe(false);
		});
	});


	describe('Edge cases', () => {
		it('should handle different position combinations', () => {
			const positions = ['top-center', 'top-left', 'top-right', 'bottom-center', 'bottom-left', 'bottom-right', 'left-middle', 'right-middle'];

			positions.forEach((pos) => {
				expect(() => {
					const params = { position: pos };
					new SelectMenu(mockEditor.$, params);
				}).not.toThrow();
			});
		});

		it('should handle zero items', () => {
			const params = { position: 'top-center' };
			const selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			selectMenu.on(ref, jest.fn());

			selectMenu.create([]);
			expect(selectMenu.menuLen).toBe(0);
		});

		it('should handle checkList toggle', () => {
			const params = { position: 'top-center', checkList: true };
			const selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			selectMenu.on(ref, jest.fn());
			selectMenu.create(['Item 1', 'Item 2']);

			expect(selectMenu.checkList).toBe(true);
		});

		it('should handle left position', () => {
			const params = { position: 'left-middle' };
			const selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			Object.defineProperty(ref, 'offsetWidth', { value: 100 });
			Object.defineProperty(ref, 'offsetHeight', { value: 30 });
			Object.defineProperty(ref, 'offsetTop', { value: 100 });
			Object.defineProperty(ref, 'offsetLeft', { value: 200 });
			parent.appendChild(ref);
			document.body.appendChild(parent);

			selectMenu.on(ref, jest.fn());
			selectMenu.create(['Item 1', 'Item 2']);

			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 150, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });

			expect(() => {
				selectMenu.open();
			}).not.toThrow();

			document.body.innerHTML = '';
		});

		it('should handle right position', () => {
			const params = { position: 'right-middle' };
			const selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			Object.defineProperty(ref, 'offsetWidth', { value: 100 });
			Object.defineProperty(ref, 'offsetHeight', { value: 30 });
			Object.defineProperty(ref, 'offsetTop', { value: 100 });
			Object.defineProperty(ref, 'offsetLeft', { value: 200 });
			parent.appendChild(ref);
			document.body.appendChild(parent);

			selectMenu.on(ref, jest.fn());
			selectMenu.create(['Item 1', 'Item 2']);

			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 150, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });

			expect(() => {
				selectMenu.open();
			}).not.toThrow();

			document.body.innerHTML = '';
		});

		it('should handle bottom-right position', () => {
			const params = { position: 'bottom-right' };
			const selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			Object.defineProperty(ref, 'offsetWidth', { value: 100 });
			Object.defineProperty(ref, 'offsetHeight', { value: 30 });
			Object.defineProperty(ref, 'offsetTop', { value: 100 });
			Object.defineProperty(ref, 'offsetLeft', { value: 50 });
			parent.appendChild(ref);
			document.body.appendChild(parent);

			selectMenu.on(ref, jest.fn());
			selectMenu.create(['Item 1', 'Item 2']);

			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 150, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });

			expect(() => {
				selectMenu.open();
			}).not.toThrow();

			document.body.innerHTML = '';
		});
	});

	describe('Keyboard navigation', () => {
		let selectMenu;
		let referElement;
		let selectMethod;
		let keydownTarget;

		beforeEach(() => {
			const params = { position: 'top-center' };
			selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			referElement = document.createElement('button');
			Object.defineProperty(referElement, 'offsetWidth', { value: 100 });
			Object.defineProperty(referElement, 'offsetHeight', { value: 30 });
			Object.defineProperty(referElement, 'offsetTop', { value: 100 });
			Object.defineProperty(referElement, 'offsetLeft', { value: 50 });
			parent.appendChild(referElement);
			document.body.appendChild(parent);

			selectMethod = jest.fn();
			selectMenu.on(referElement, selectMethod);
			selectMenu.create(['Item 1', 'Item 2', 'Item 3']);

			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 150, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });

			keydownTarget = selectMenu.form.previousElementSibling || mockEditor.frameContext.get('_ww');
		});

		afterEach(() => {
			document.body.innerHTML = '';
		});

		it('should navigate with ArrowUp key', () => {
			selectMenu.open();
			selectMenu.setItem(1);

			const event = new KeyboardEvent('keydown', { code: 'ArrowUp', bubbles: true });
			Object.defineProperty(event, 'preventDefault', { value: jest.fn() });
			Object.defineProperty(event, 'stopPropagation', { value: jest.fn() });

			mockEditor.frameContext.get('_ww').dispatchEvent(event);
			expect(selectMenu.isOpen).toBe(true);
		});

		it('should navigate with ArrowLeft key', () => {
			selectMenu.open();
			selectMenu.setItem(1);

			const event = new KeyboardEvent('keydown', { code: 'ArrowLeft', bubbles: true });
			Object.defineProperty(event, 'preventDefault', { value: jest.fn() });
			Object.defineProperty(event, 'stopPropagation', { value: jest.fn() });

			mockEditor.frameContext.get('_ww').dispatchEvent(event);
			expect(selectMenu.isOpen).toBe(true);
		});

		it('should navigate with ArrowRight key', () => {
			selectMenu.open();
			selectMenu.setItem(1);

			const event = new KeyboardEvent('keydown', { code: 'ArrowRight', bubbles: true });
			Object.defineProperty(event, 'preventDefault', { value: jest.fn() });
			Object.defineProperty(event, 'stopPropagation', { value: jest.fn() });

			mockEditor.frameContext.get('_ww').dispatchEvent(event);
			expect(selectMenu.isOpen).toBe(true);
		});

		it('should select item with Enter key', () => {
			selectMenu.open();
			selectMenu.setItem(1);

			const event = new KeyboardEvent('keydown', { code: 'Enter', bubbles: true });
			Object.defineProperty(event, 'preventDefault', { value: jest.fn() });
			Object.defineProperty(event, 'stopPropagation', { value: jest.fn() });

			mockEditor.frameContext.get('_ww').dispatchEvent(event);
			expect(selectMenu.isOpen).toBe(true);
		});

		it('Space is not an activation key and is left to the document', () => {
			selectMenu.open();
			selectMenu.setItem(1);

			const event = new KeyboardEvent('keydown', { code: 'Space', bubbles: true, cancelable: true });
			const prevent = jest.fn();
			Object.defineProperty(event, 'preventDefault', { value: prevent });
			Object.defineProperty(event, 'stopPropagation', { value: jest.fn() });

			mockEditor.frameContext.get('_ww').dispatchEvent(event);

			// An IME makes `preventDefault()` a no-op, so a swallowed Space still typed a space and
			// SlashCommand read it as "query ended". The menu never claims the key now.
			expect(prevent).not.toHaveBeenCalled();
			expect(selectMenu.isOpen).toBe(true);
		});

		it('Enter with no item focused (index -1) does NOT close the menu', () => {
			for (const code of ['Enter']) {
				selectMenu.open();
				expect(selectMenu.index).toBe(-1);

				const event = new KeyboardEvent('keydown', { code, bubbles: true });
				Object.defineProperty(event, 'preventDefault', { value: jest.fn() });
				Object.defineProperty(event, 'stopPropagation', { value: jest.fn() });

				mockEditor.frameContext.get('_ww').dispatchEvent(event);
				expect(selectMenu.isOpen).toBe(true); // stays open (previously closed)
				expect(selectMenu.index).toBe(-1);
			}
		});

		it('hasOpenSubmenu reflects native submenu state', () => {
			const menu = new SelectMenu(mockEditor.$, { position: 'top-center' });
			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			document.body.appendChild(parent);
			menu.on(ref, jest.fn());
			menu.create(['a', 'b']);
			menu.open();
			expect(menu.hasOpenSubmenu()).toBe(false);
		});
	});

	describe('Scroll into view (maxHeight list)', () => {
		const ROW_H = 30;
		const VIEW_H = 90; // 3 rows visible out of 6

		let selectMenu;
		let inner;
		let scrollTop;

		/**
		 * jsdom has no layout: give the scroll container and every row a fake geometry
		 * driven by the current `scrollTop`, so the rects move like a real scrolled list.
		 */
		function layout() {
			inner.getBoundingClientRect = () => ({ top: 0, bottom: VIEW_H, left: 0, right: 100, width: 100, height: VIEW_H });
			selectMenu.menus.forEach((li, i) => {
				li.getBoundingClientRect = () => ({
					top: i * ROW_H - scrollTop,
					bottom: (i + 1) * ROW_H - scrollTop,
					left: 0,
					right: 100,
					width: 100,
					height: ROW_H
				});
			});
		}

		beforeEach(() => {
			selectMenu = new SelectMenu(mockEditor.$, { position: 'bottom-left', maxHeight: VIEW_H + 'px' });

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			document.body.appendChild(parent);

			selectMenu.on(ref, jest.fn());
			selectMenu.create(['1', '2', '3', '4', '5', '6']);

			inner = selectMenu.form.firstElementChild;
			scrollTop = 0;
			Object.defineProperty(inner, 'scrollTop', {
				configurable: true,
				get: () => scrollTop,
				set: (v) => {
					scrollTop = v;
				}
			});
			Object.defineProperty(inner, 'scrollHeight', { configurable: true, value: ROW_H * 6 });
			Object.defineProperty(inner, 'clientHeight', { configurable: true, value: VIEW_H });
			Object.defineProperty(inner, 'clientTop', { configurable: true, value: 0 });
			layout();
		});

		afterEach(() => {
			document.body.innerHTML = '';
		});

		it('scrolls down when the cursor moves onto a row below the visible area', () => {
			selectMenu.setItem(2); // last fully visible row
			expect(scrollTop).toBe(0);

			selectMenu.setItem(3);
			expect(scrollTop).toBe(ROW_H); // moved by exactly one row

			selectMenu.setItem(5); // last row
			expect(scrollTop).toBe(ROW_H * 3);
		});

		it('scrolls up when the cursor moves onto a row above the visible area', () => {
			selectMenu.setItem(5);
			expect(scrollTop).toBe(ROW_H * 3);

			selectMenu.setItem(0); // wrap to the top
			expect(scrollTop).toBe(0);
		});

		it('does not scroll when the row is already fully visible', () => {
			selectMenu.setItem(3);
			const before = scrollTop;

			selectMenu.setItem(2);
			expect(scrollTop).toBe(before);
		});

		it('scrolls a viewport-clamped list that has no `maxHeight` param', () => {
			const clamped = new SelectMenu(mockEditor.$, { position: 'bottom-left' });
			const ref = document.createElement('button');
			document.createElement('div').appendChild(ref);
			document.body.appendChild(ref.parentElement);
			clamped.on(ref, jest.fn());
			clamped.create(['1', '2', '3', '4', '5', '6']);

			// what `#clampHeight` leaves behind when the menu doesn't fit the viewport
			const list = clamped.form.firstElementChild;
			list.style.maxHeight = VIEW_H + 'px';
			list.style.overflowY = 'auto';

			let clampedScrollTop = 0;
			Object.defineProperty(list, 'scrollTop', {
				configurable: true,
				get: () => clampedScrollTop,
				set: (v) => {
					clampedScrollTop = v;
				}
			});
			Object.defineProperty(list, 'clientHeight', { configurable: true, value: VIEW_H });
			Object.defineProperty(list, 'clientTop', { configurable: true, value: 0 });
			list.getBoundingClientRect = () => ({ top: 0, bottom: VIEW_H, left: 0, right: 100, width: 100, height: VIEW_H });
			clamped.menus.forEach((li, i) => {
				li.getBoundingClientRect = () => ({
					top: i * ROW_H - clampedScrollTop,
					bottom: (i + 1) * ROW_H - clampedScrollTop,
					left: 0,
					right: 100,
					width: 100,
					height: ROW_H
				});
			});

			clamped.setItem(5);
			expect(clampedScrollTop).toBe(ROW_H * 3);
		});

		it('does nothing for a menu that neither has `maxHeight` nor was clamped', () => {
			const plain = new SelectMenu(mockEditor.$, { position: 'bottom-left' });
			const ref = document.createElement('button');
			document.createElement('div').appendChild(ref);
			document.body.appendChild(ref.parentElement);
			plain.on(ref, jest.fn());
			plain.create(['1', '2', '3', '4', '5', '6']);

			let plainScrollTop = 0;
			Object.defineProperty(plain.form.firstElementChild, 'scrollTop', {
				configurable: true,
				get: () => plainScrollTop,
				set: (v) => {
					plainScrollTop = v;
				}
			});

			plain.setItem(5);
			expect(plainScrollTop).toBe(0);
		});
	});

	describe('Horizontal navigation', () => {
		let selectMenu;

		beforeEach(() => {
			const params = { position: 'top-center', splitNum: 2 };
			selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			Object.defineProperty(ref, 'offsetWidth', { value: 100 });
			Object.defineProperty(ref, 'offsetHeight', { value: 30 });
			Object.defineProperty(ref, 'offsetTop', { value: 100 });
			Object.defineProperty(ref, 'offsetLeft', { value: 50 });
			parent.appendChild(ref);
			document.body.appendChild(parent);

			selectMenu.on(ref, jest.fn());
			selectMenu.create(['Item 1', 'Item 2', 'Item 3', 'Item 4']);

			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 200, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });
		});

		afterEach(() => {
			document.body.innerHTML = '';
		});

		it('should navigate horizontally with ArrowUp', () => {
			selectMenu.open();
			selectMenu.setItem(2);

			const event = new KeyboardEvent('keydown', { code: 'ArrowUp', bubbles: true });
			Object.defineProperty(event, 'preventDefault', { value: jest.fn() });
			Object.defineProperty(event, 'stopPropagation', { value: jest.fn() });

			mockEditor.frameContext.get('_ww').dispatchEvent(event);
			expect(selectMenu.horizontal).toBe(true);
		});

		it('should navigate horizontally with ArrowDown', () => {
			selectMenu.open();
			selectMenu.setItem(1);

			const event = new KeyboardEvent('keydown', { code: 'ArrowDown', bubbles: true });
			Object.defineProperty(event, 'preventDefault', { value: jest.fn() });
			Object.defineProperty(event, 'stopPropagation', { value: jest.fn() });

			mockEditor.frameContext.get('_ww').dispatchEvent(event);
			expect(selectMenu.horizontal).toBe(true);
		});
	});

	describe('CheckList functionality', () => {
		let selectMenu;
		let selectMethod;

		beforeEach(() => {
			const params = { position: 'top-center', checkList: true };
			selectMenu = new SelectMenu(mockEditor.$, params);

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			Object.defineProperty(ref, 'offsetWidth', { value: 100 });
			Object.defineProperty(ref, 'offsetHeight', { value: 30 });
			Object.defineProperty(ref, 'offsetTop', { value: 100 });
			Object.defineProperty(ref, 'offsetLeft', { value: 50 });
			parent.appendChild(ref);
			document.body.appendChild(parent);

			selectMethod = jest.fn();
			selectMenu.on(ref, selectMethod);
			selectMenu.create(['Item 1', 'Item 2', 'Item 3']);

			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 150, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });
		});

		afterEach(() => {
			document.body.innerHTML = '';
		});

		it('should toggle check class on item click', () => {
			const { dom } = require('../../../src/helper');
			selectMenu.open();

			const menuItem = selectMenu.menus[0];
			menuItem.setAttribute('data-index', '0');

			const event = { target: menuItem };
			const { query } = require('../../../src/helper').dom;
			query.getEventTarget.mockReturnValue(menuItem);

			selectMenu.form.dispatchEvent(new MouseEvent('click', { bubbles: true }));

			expect(dom.utils.toggleClass).toHaveBeenCalled();
		});
	});

	describe('Submenu support', () => {
		let selectMenu;
		let referElement;

		beforeEach(() => {
			// Provide an icon used by the parent row arrow
			mockEditor.$.icons = { menu_arrow_right: '<svg></svg>' };

			selectMenu = new SelectMenu(mockEditor.$, { position: 'right-middle' });

			const parent = document.createElement('div');
			referElement = document.createElement('button');
			parent.appendChild(referElement);
			document.body.appendChild(parent);

			selectMenu.on(referElement, jest.fn());
		});

		afterEach(() => {
			document.body.innerHTML = '';
		});

		it('creates parent row with submenu element for items that have children', () => {
			selectMenu.create([
				{ children: ['ul', 'ol'], childMenus: ['<i>Bulleted</i>', '<i>Numbered</i>'] },
				'plain item'
			]);

			// Two top-level rows
			expect(selectMenu.menuLen).toBe(2);

			// First row marks itself as having a submenu and gets the arrow icon
			const parentRow = selectMenu.menus[0];
			expect(parentRow.className).toContain('se-has-submenu');
			expect(parentRow.innerHTML).toContain('se-submenu-arrow');

			// Submenu element appended to the form (outside the inner list)
			const submenu = selectMenu.form.querySelector('.se-select-submenu[data-parent-index="0"]');
			expect(submenu).not.toBeNull();
			expect(submenu.getAttribute('popover')).toBe('manual');

			// Child rows: one per `childMenus` entry, all carrying parent/child indexes
			const childRows = submenu.querySelectorAll('li.se-select-item');
			expect(childRows.length).toBe(2);
			expect(childRows[0].getAttribute('data-parent-index')).toBe('0');
			expect(childRows[0].getAttribute('data-child-index')).toBe('0');
			expect(childRows[0].innerHTML).toContain('Bulleted');
		});

		it('falls back to children as display content when childMenus is omitted', () => {
			selectMenu.create([{ children: ['A', 'B'] }]);

			const childRows = selectMenu.form.querySelectorAll('.se-select-submenu li.se-select-item');
			expect(childRows.length).toBe(2);
			expect(childRows[0].textContent).toBe('A');
			expect(childRows[1].textContent).toBe('B');
		});

		it('clears existing submenu elements when create is called again', () => {
			selectMenu.create([{ children: ['x'] }]);
			expect(selectMenu.form.querySelectorAll('.se-select-submenu').length).toBe(1);

			selectMenu.create(['plain']);
			expect(selectMenu.form.querySelectorAll('.se-select-submenu').length).toBe(0);
		});

		it('ESC closes only the open submenu and returns the cursor to its trigger row (menu stays open)', () => {
			const { dom, keyCodeMap } = require('../../../src/helper');
			keyCodeMap.isEsc.mockImplementation((code) => code === 'Escape');
			// This suite stubs dom.utils class helpers as no-ops; make them real so submenu/cursor
			// class state is observable, then restore the suite defaults afterwards.
			dom.utils.hasClass.mockImplementation((el, cls) => !!el?.classList?.contains(cls));
			dom.utils.addClass.mockImplementation((el, cls) => el?.classList?.add(cls));
			dom.utils.removeClass.mockImplementation((els, cls) => {
				const list = !els ? [] : els.nodeType ? [els] : Array.from(els);
				list.forEach((e) => e.classList?.remove(cls));
			});

			try {
				selectMenu.create([{ children: ['ul', 'ol'], childMenus: ['<i>Bulleted</i>', '<i>Numbered</i>'] }, 'plain']);
				selectMenu.open();

				// Open the submenu on the first (trigger) row via keyboard nav (call the registered handler).
				const kdCall = mockEditor.$.eventManager.addEvent.mock.calls.find((c) => c[1] === 'keydown');
				expect(kdCall).toBeTruthy();
				const keydownHandler = kdCall[2];
				const key = (code) => keydownHandler({ code, preventDefault: jest.fn(), stopPropagation: jest.fn() });
				key('ArrowDown'); // cursor → row 0
				key('Enter'); // open submenu of row 0
				const parentRow = selectMenu.menus[0];
				expect(parentRow.classList.contains('se-submenu-open')).toBe(true);

				// Retrieve the ESC (global keydown) handler and fire Escape.
				const escCall = mockEditor.$.eventManager.addGlobalEvent.mock.calls.find((c) => c[0] === 'keydown');
				expect(escCall).toBeTruthy();
				const escHandler = escCall[1];
				const escEvent = { code: 'Escape', preventDefault: jest.fn(), stopPropagation: jest.fn() };
				escHandler(escEvent);

				// Only the submenu closed; the menu itself stays open.
				expect(selectMenu.isOpen).toBe(true);
				expect(parentRow.classList.contains('se-submenu-open')).toBe(false);
				// Cursor/focus returned to the trigger row.
				expect(parentRow.classList.contains('se-select-cursor')).toBe(true);
				expect(selectMenu.index).toBe(0);
				// ESC was consumed (did not bubble to close the whole menu / editor).
				expect(escEvent.stopPropagation).toHaveBeenCalled();
			} finally {
				dom.utils.hasClass.mockReset();
				dom.utils.hasClass.mockReturnValue(false);
				dom.utils.addClass.mockReset();
				dom.utils.removeClass.mockReset();
			}
		});

		it.each(['ArrowLeft', 'ArrowRight'])('%s closes an open submenu and keeps the menu up', (code) => {
			const { dom } = require('../../../src/helper');
			dom.utils.hasClass.mockImplementation((el, cls) => !!el?.classList?.contains(cls));
			dom.utils.addClass.mockImplementation((el, cls) => el?.classList?.add(cls));
			dom.utils.removeClass.mockImplementation((els, cls) => {
				const list = !els ? [] : els.nodeType ? [els] : Array.from(els);
				list.forEach((e) => e.classList?.remove(cls));
			});

			try {
				selectMenu.create([{ children: ['ul', 'ol'], childMenus: ['<i>Bulleted</i>', '<i>Numbered</i>'] }, 'plain']);
				selectMenu.open();

				const kdCall = mockEditor.$.eventManager.addEvent.mock.calls.find((c) => c[1] === 'keydown');
				const keydownHandler = kdCall[2];
				const key = (c) => keydownHandler({ code: c, preventDefault: jest.fn(), stopPropagation: jest.fn() });

				key('ArrowDown');
				key('Enter');
				const parentRow = selectMenu.menus[0];
				expect(parentRow.classList.contains('se-submenu-open')).toBe(true);

				// Either direction leaves the submenu, so LTR and RTL need no separate mapping.
				key(code);

				expect(parentRow.classList.contains('se-submenu-open')).toBe(false);
				expect(selectMenu.isOpen).toBe(true);
			} finally {
				dom.utils.hasClass.mockReset();
				dom.utils.hasClass.mockReturnValue(false);
				dom.utils.addClass.mockReset();
				dom.utils.removeClass.mockReset();
			}
		});

		it.each(['ArrowLeft', 'ArrowRight'])('%s opens the submenu on the cursor row', (code) => {
			const { dom } = require('../../../src/helper');
			dom.utils.hasClass.mockImplementation((el, cls) => !!el?.classList?.contains(cls));
			dom.utils.addClass.mockImplementation((el, cls) => el?.classList?.add(cls));
			dom.utils.removeClass.mockImplementation((els, cls) => {
				const list = !els ? [] : els.nodeType ? [els] : Array.from(els);
				list.forEach((e) => e.classList?.remove(cls));
			});

			try {
				selectMenu.create([{ children: ['ul', 'ol'], childMenus: ['<i>Bulleted</i>', '<i>Numbered</i>'] }, 'plain']);
				selectMenu.open();

				const kdCall = mockEditor.$.eventManager.addEvent.mock.calls.find((c) => c[1] === 'keydown');
				const keydownHandler = kdCall[2];
				const key = (c) => keydownHandler({ code: c, preventDefault: jest.fn(), stopPropagation: jest.fn() });

				key('ArrowDown'); // cursor → row 0
				key(code);

				// either direction opens, so LTR and RTL need no separate mapping
				expect(selectMenu.menus[0].classList.contains('se-submenu-open')).toBe(true);
				// the cursor did not walk off the trigger row
				expect(selectMenu.index).toBe(0);
			} finally {
				dom.utils.hasClass.mockReset();
				dom.utils.hasClass.mockReturnValue(false);
				dom.utils.addClass.mockReset();
				dom.utils.removeClass.mockReset();
			}
		});

		it('a horizontal arrow does not move the cursor in a vertical list', () => {
			selectMenu.create(['a', 'b', 'c']);
			selectMenu.open();

			const kdCall = mockEditor.$.eventManager.addEvent.mock.calls.find((c) => c[1] === 'keydown');
			const key = (c) => kdCall[2]({ code: c, preventDefault: jest.fn(), stopPropagation: jest.fn() });

			key('ArrowDown'); // cursor → row 0
			key('ArrowRight');

			// moving between rows is up/down's job
			expect(selectMenu.index).toBe(0);
		});

		it('a horizontal arrow still moves within a grid menu (splitNum)', () => {
			const menu = new SelectMenu(mockEditor.$, { position: 'bottom-center', splitNum: 3 });
			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			document.body.appendChild(parent);
			menu.on(ref, jest.fn());
			menu.create(['a', 'b', 'c', 'd', 'e', 'f']);
			menu.open();

			const kdCall = mockEditor.$.eventManager.addEvent.mock.calls.find((c) => c[1] === 'keydown');
			const key = (c) => kdCall[2]({ code: c, preventDefault: jest.fn(), stopPropagation: jest.fn() });

			menu.setItem(0);
			key('ArrowRight');

			// a grid needs this axis to reach every cell
			expect(menu.index).toBe(1);
		});

		it('a horizontal arrow selects an owner-managed sub-panel row through the select path', () => {
			const selectMethod = jest.fn();
			const subCheckMethod = jest.fn((index) => index === 0); // row 0 owns a flyout
			const menu = new SelectMenu(mockEditor.$, { position: 'right-middle', subCheckMethod });
			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			document.body.appendChild(parent);
			menu.on(ref, selectMethod);
			menu.create(['flyout-row', 'plain']);
			menu.open();

			const kdCall = mockEditor.$.eventManager.addEvent.mock.calls.find((c) => c[1] === 'keydown');
			const key = (c) => kdCall[2]({ code: c, preventDefault: jest.fn(), stopPropagation: jest.fn() });

			key('ArrowDown'); // cursor → row 0
			key('ArrowRight');

			// dispatched through `#select`, so the owner's pre-dispatch runs; the cursor stayed put
			expect(selectMethod).toHaveBeenCalledWith('flyout-row');
			expect(menu.index).toBe(0);
		});

		it('a horizontal arrow is inert on a row the owner does not claim', () => {
			const selectMethod = jest.fn();
			const subCheckMethod = jest.fn(() => false);
			const menu = new SelectMenu(mockEditor.$, { position: 'right-middle', subCheckMethod });
			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			document.body.appendChild(parent);
			menu.on(ref, selectMethod);
			menu.create(['a', 'b']);
			menu.open();

			const kdCall = mockEditor.$.eventManager.addEvent.mock.calls.find((c) => c[1] === 'keydown');
			const key = (c) => kdCall[2]({ code: c, preventDefault: jest.fn(), stopPropagation: jest.fn() });

			key('ArrowDown');
			key('ArrowRight');

			expect(subCheckMethod).toHaveBeenCalledWith(0);
			expect(menu.index).toBe(0); // no move
			expect(selectMethod).not.toHaveBeenCalled(); // and no accidental activation
		});

		function openMenuWith(subEscMethod, items) {
			const menu = new SelectMenu(mockEditor.$, { position: 'right-middle', subEscMethod });
			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			document.body.appendChild(parent);
			menu.on(ref, jest.fn());
			menu.create(items);
			menu.open();
			return menu;
		}

		it('ESC delegates to subEscMethod (owner flyout) and keeps the menu open when it returns true', () => {
			const { keyCodeMap } = require('../../../src/helper');
			keyCodeMap.isEsc.mockImplementation((code) => code === 'Escape');

			const subEscMethod = jest.fn(() => true); // owner dismissed its own sub-panel (e.g. flyout)
			const menu = openMenuWith(subEscMethod, ['a', 'b']);

			const escHandler = mockEditor.$.eventManager.addGlobalEvent.mock.calls.find((c) => c[0] === 'keydown')[1];
			const escEvent = { code: 'Escape', preventDefault: jest.fn(), stopPropagation: jest.fn() };
			escHandler(escEvent);

			expect(subEscMethod).toHaveBeenCalled();
			expect(menu.isOpen).toBe(true); // menu stays open
			expect(escEvent.stopPropagation).toHaveBeenCalled();
		});

		it('ESC closes the menu when subEscMethod returns false (no sub-panel open)', () => {
			const { keyCodeMap } = require('../../../src/helper');
			keyCodeMap.isEsc.mockImplementation((code) => code === 'Escape');

			const subEscMethod = jest.fn(() => false);
			const menu = openMenuWith(subEscMethod, ['a']);

			const escHandler = mockEditor.$.eventManager.addGlobalEvent.mock.calls.find((c) => c[0] === 'keydown')[1];
			escHandler({ code: 'Escape', preventDefault: jest.fn(), stopPropagation: jest.fn() });

			expect(subEscMethod).toHaveBeenCalled();
			expect(menu.isOpen).toBe(false); // no sub-panel — whole menu closes
		});
	});

	describe('reposition method', () => {
		let selectMenu;

		beforeEach(() => {
			selectMenu = new SelectMenu(mockEditor.$, { position: 'top-center' });
			const parent = document.createElement('div');
			const ref = document.createElement('button');
			Object.defineProperty(ref, 'offsetWidth', { value: 100 });
			Object.defineProperty(ref, 'offsetHeight', { value: 30 });
			parent.appendChild(ref);
			document.body.appendChild(parent);
			selectMenu.on(ref, jest.fn());
			selectMenu.create(['Item 1']);
			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 150, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });
		});

		afterEach(() => {
			document.body.innerHTML = '';
		});

		it('no-op when menu is not open', () => {
			expect(() => selectMenu.reposition()).not.toThrow();
			expect(selectMenu.isOpen).toBe(false);
		});

		it('re-applies positioning when menu is open', () => {
			selectMenu.open('bottom-left');
			// Wipe any inline style so we can detect that reposition re-sets it
			selectMenu.form.removeAttribute('style');
			selectMenu.reposition();
			// `_setPosition` writes `display`/`top`/`left` (or right) onto the form
			expect(selectMenu.form.getAttribute('style')).not.toBeNull();
			expect(selectMenu.form.style.display).not.toBe('');
		});
	});

	describe('setHidden method', () => {
		let selectMenu;

		beforeEach(() => {
			selectMenu = new SelectMenu(mockEditor.$, { position: 'top-center' });
			const parent = document.createElement('div');
			const ref = document.createElement('button');
			Object.defineProperty(ref, 'offsetWidth', { value: 100 });
			Object.defineProperty(ref, 'offsetHeight', { value: 30 });
			parent.appendChild(ref);
			document.body.appendChild(parent);
			selectMenu.on(ref, jest.fn());
			selectMenu.create(['Item 1']);
			Object.defineProperty(selectMenu.form, 'offsetWidth', { value: 150, configurable: true });
			Object.defineProperty(selectMenu.form, 'offsetHeight', { value: 100, configurable: true });
		});

		afterEach(() => {
			document.body.innerHTML = '';
		});

		it('no-op when menu is not open', () => {
			selectMenu.setHidden(true);
			// Should not toggle open state nor throw
			expect(selectMenu.isOpen).toBe(false);
		});

		it('soft-hides the form without closing', () => {
			selectMenu.open();
			expect(selectMenu.isOpen).toBe(true);

			selectMenu.setHidden(true);
			expect(selectMenu.form.style.display).toBe('none');
			// Still considered open — close listeners stay active
			expect(selectMenu.isOpen).toBe(true);
		});

		it('re-shows the form via reposition', () => {
			selectMenu.open();
			selectMenu.setHidden(true);
			expect(selectMenu.form.style.display).toBe('none');

			selectMenu.setHidden(false);
			expect(selectMenu.form.style.display).not.toBe('none');
		});
	});

	describe('keydownTarget override', () => {
		it('uses provided target for keydown listener instead of frameContext _ww', () => {
			const customTarget = document.createElement('div');
			customTarget.addEventListener = jest.fn();

			const selectMenu = new SelectMenu(mockEditor.$, { position: 'top-center', keydownTarget: customTarget });

			const parent = document.createElement('div');
			const ref = document.createElement('button');
			parent.appendChild(ref);
			selectMenu.on(ref, jest.fn());
			selectMenu.create(['Item 1']);
			selectMenu.open();

			// addEvent on the kernel's eventManager is called with the keydown target;
			// when keydownTarget is set the override wins over the iframe contentWindow.
			const calls = mockEditor.$.eventManager.addEvent?.mock?.calls || [];
			const keydownCall = calls.find((c) => c[1] === 'keydown' && c[0] === customTarget);
			// Either the addEvent path captured it, or the underlying addEventListener was called.
			expect(keydownCall || customTarget.addEventListener.mock.calls.length > 0).toBeTruthy();
		});
	});
});
