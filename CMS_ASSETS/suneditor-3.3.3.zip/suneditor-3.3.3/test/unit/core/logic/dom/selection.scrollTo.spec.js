/**
 * @jest-environment jsdom
 */

/**
 * @fileoverview Numerical verification tests for Selection.scrollTo.
 *
 * These tests mock layout values (getBoundingClientRect, offsetWidth/Height,
 * scrollTop, etc.) to verify that scrollTo correctly calculates scroll
 * positions, especially for deeply nested elements like nested lists.
 */

import { createMockEditor } from '../../../../__mocks__/editorMock';
import Selection from '../../../../../src/core/logic/dom/selection';

/*============================================================================
 * Layout Constants
 *============================================================================*/
const LAYOUT = {
	wwFrame: {
		rect: { top: 100, left: 20, right: 820, bottom: 500, width: 800, height: 400 },
		offsetWidth: 800,
		offsetHeight: 400,
		scrollTop: 0,
	},
	toolbar: { offsetHeight: 40 },
	viewportHeight: 768,
	scrollY: 0,
};

/*============================================================================
 * Helpers
 *============================================================================*/
function mockRect(el, rect) {
	el.getBoundingClientRect = jest.fn(() => ({
		top: rect.top, left: rect.left, right: rect.right, bottom: rect.bottom,
		width: rect.width ?? (rect.right - rect.left),
		height: rect.height ?? (rect.bottom - rect.top),
		x: rect.left, y: rect.top,
	}));
}

function mockSize(el, w, h) {
	Object.defineProperty(el, 'offsetWidth', { value: w, configurable: true, writable: true });
	Object.defineProperty(el, 'offsetHeight', { value: h, configurable: true, writable: true });
}

function setProp(el, key, value) {
	Object.defineProperty(el, key, { value, configurable: true, writable: true });
}

/*============================================================================
 * Tests
 *============================================================================*/
describe('Selection - scrollTo', () => {
	let kernel, selection, wysiwyg, wwFrame, scrollToSpy;

	beforeEach(() => {
		kernel = createMockEditor();
		const fc = kernel.$.frameContext;
		wysiwyg = fc.get('wysiwyg');
		wwFrame = fc.get('wysiwygFrame');

		// Mock toolbar
		const toolbarMain = document.createElement('div');
		mockSize(toolbarMain, 800, LAYOUT.toolbar.offsetHeight);
		kernel.$.context.get = jest.fn((key) => {
			if (key === 'toolbar_main') return toolbarMain;
			return document.createElement('div');
		});

		// Mock toolbar.isSticky
		kernel.$.toolbar.isSticky = false;

		// Mock store
		kernel.store.get = jest.fn((key) => {
			if (key === 'isScrollable') return () => true; // not auto-height
			if (key === 'currentViewportHeight') return LAYOUT.viewportHeight;
			return undefined;
		});

		// Mock offset.getGlobal — editor fully visible in viewport
		kernel.$.offset.getGlobal = jest.fn(() => ({
			top: LAYOUT.wwFrame.rect.top,
			left: LAYOUT.wwFrame.rect.left,
			fixedTop: LAYOUT.wwFrame.rect.top,
			fixedLeft: LAYOUT.wwFrame.rect.left,
			width: LAYOUT.wwFrame.offsetWidth,
			height: LAYOUT.wwFrame.offsetHeight,
		}));

		// Mock wwFrame layout
		mockRect(wwFrame, LAYOUT.wwFrame.rect);
		mockSize(wwFrame, LAYOUT.wwFrame.offsetWidth, LAYOUT.wwFrame.offsetHeight);
		setProp(wwFrame, 'scrollTop', 0);
		wwFrame.scrollTo = jest.fn();
		scrollToSpy = wwFrame.scrollTo;

		// Mock window
		Object.defineProperty(window, 'scrollY', { value: LAYOUT.scrollY, configurable: true, writable: true });
		window.scrollTo = jest.fn();

		// Ensure wysiwyg is in document
		if (!document.body.contains(wysiwyg)) {
			document.body.appendChild(wwFrame);
			wwFrame.appendChild(wysiwyg);
		}

		// Create Selection instance
		selection = new Selection(kernel);
	});

	afterEach(() => {
		jest.restoreAllMocks();
	});

	/**
	 * Build a nested list structure inside wysiwyg:
	 * <ul><li>top<ul><li>mid<ul><li>deep</li></ul></li></ul></li></ul>
	 * Returns the deepest text node.
	 */
	function buildNestedList() {
		wysiwyg.innerHTML = `
			<ul><li>top
				<ul><li>mid
					<ul><li>deep target text</li></ul>
				</li></ul>
			</li></ul>`;
		// Find the deepest <li>
		const allLi = wysiwyg.querySelectorAll('li');
		const deepLi = allLi[allLi.length - 1];
		return { deepLi, textNode: deepLi.firstChild };
	}

	function createRangeForNode(textNode) {
		const range = document.createRange();
		range.setStart(textNode, 0);
		range.setEnd(textNode, textNode.textContent.length);
		return range;
	}

	describe('nested list scroll position', () => {
		it('should scroll down to a nested list item below the visible area', () => {
			const { deepLi, textNode } = buildNestedList();

			// Element is below visible area: top=450 relative to frame top=100 → innerTop=350
			// viewHeight=400, so 350 + PADDING(40) > 400 → needs scroll down
			mockRect(deepLi, { top: 550, left: 40, right: 200, bottom: 570 });
			mockSize(deepLi, 160, 20);

			const range = createRangeForNode(textNode);
			selection.scrollTo(range);

			expect(scrollToSpy).toHaveBeenCalled();
			const scrollArg = scrollToSpy.mock.calls[0][0];
			expect(scrollArg.top).toBeGreaterThan(0); // scroll down
		});

		it('should scroll up to a nested list item above the visible area', () => {
			const { deepLi, textNode } = buildNestedList();
			setProp(wwFrame, 'scrollTop', 300);

			// Element is above the frame: frame top=100, el top=80 → innerTop = -20
			mockRect(deepLi, { top: 80, left: 40, right: 200, bottom: 100 });
			mockSize(deepLi, 160, 20);

			const range = createRangeForNode(textNode);
			selection.scrollTo(range);

			expect(scrollToSpy).toHaveBeenCalled();
			const scrollArg = scrollToSpy.mock.calls[0][0];
			expect(scrollArg.top).toBeLessThan(300); // scroll up from current 300
		});

		it('should not scroll when nested list item is already visible', () => {
			const { deepLi, textNode } = buildNestedList();

			// Element is in the middle of the frame: frame top=100, el top=300 → innerTop=200
			// viewHeight=400, PADDING=40: 200 - 40 > 0 && 200 + 40 <= 400 → visible
			mockRect(deepLi, { top: 300, left: 40, right: 200, bottom: 320 });
			mockSize(deepLi, 160, 20);

			const range = createRangeForNode(textNode);
			selection.scrollTo(range);

			expect(scrollToSpy).not.toHaveBeenCalled();
		});
	});

	describe('outer li with nested children (offsetHeight mismatch)', () => {
		/**
		 * Build a nested list and return the OUTER <li> and its text node.
		 * The outer <li> has a large offsetHeight (includes nested sub-lists),
		 * but the actual text line is only ~20px tall.
		 */
		function buildOuterNestedList() {
			wysiwyg.innerHTML = `<ul><li>outer text<ul><li>inner1</li><li>inner2</li><li>inner3</li></ul></li></ul>`;
			const outerLi = wysiwyg.querySelector('li');
			// outerLi.firstChild is the "outer text" text node
			return { outerLi, textNode: outerLi.firstChild };
		}

		it('should use range rect height, not el.offsetHeight for scroll calculation', () => {
			const { outerLi, textNode } = buildOuterNestedList();

			// Outer <li> has large offsetHeight (entire nested structure)
			mockSize(outerLi, 780, 200);
			// But the outer <li> top is at the right place
			mockRect(outerLi, { top: 80, left: 20, right: 800, bottom: 280 });

			const range = createRangeForNode(textNode);
			// Mock range rect — actual text line is 20px tall
			range.getBoundingClientRect = jest.fn(() => ({
				top: 80, left: 20, right: 200, bottom: 100,
				width: 180, height: 20, x: 20, y: 80,
			}));

			setProp(wwFrame, 'scrollTop', 300);
			selection.scrollTo(range);

			expect(scrollToSpy).toHaveBeenCalled();
			const scrollArg = scrollToSpy.mock.calls[0][0];

			// With elH=20 (range height): newScrollTop = 300 + (-20 - (0 + 20)) = 260
			// With elH=200 (wrong el.offsetHeight): newScrollTop = 300 + (-20 - (0 + 200)) = 80
			// The correct scroll should be closer to 260, not 80
			expect(scrollArg.top).toBeGreaterThan(200);
		});

		it('should not overshoot when scrolling up to outer li text', () => {
			const { outerLi, textNode } = buildOuterNestedList();

			mockSize(outerLi, 780, 300); // large height from nested children
			mockRect(outerLi, { top: 60, left: 20, right: 800, bottom: 360 });

			const range = createRangeForNode(textNode);
			range.getBoundingClientRect = jest.fn(() => ({
				top: 60, left: 20, right: 200, bottom: 80,
				width: 180, height: 20, x: 20, y: 60,
			}));

			setProp(wwFrame, 'scrollTop', 500);
			selection.scrollTo(range);

			expect(scrollToSpy).toHaveBeenCalled();
			const scrollArg = scrollToSpy.mock.calls[0][0];

			// Should scroll to show the text line (top=60), not overshoot
			// With correct elH=20: 500 + (-40 - (0 + 20)) = 440
			// With wrong elH=300: 500 + (-40 - (0 + 300)) = 160 ← huge overshoot
			expect(scrollArg.top).toBeGreaterThan(400);
		});
	});

	describe('coordinate system consistency', () => {
		it('should use editor-frame-relative coordinates, not viewport-relative', () => {
			const { deepLi, textNode } = buildNestedList();

			// Frame is at viewport top=100
			// Element is at viewport top=200 → frame-relative = 100
			// If code incorrectly uses viewport-relative (200), it would miscalculate
			mockRect(deepLi, { top: 200, left: 40, right: 200, bottom: 220 });
			mockSize(deepLi, 160, 20);

			const range = createRangeForNode(textNode);
			selection.scrollTo(range);

			// innerTop = 200 - 100 = 100, which is within view → no scroll
			expect(scrollToSpy).not.toHaveBeenCalled();
		});

		it('should calculate correctly when editor frame is not at viewport top', () => {
			const { deepLi, textNode } = buildNestedList();

			// Frame is far down the page at viewport top=400
			mockRect(wwFrame, { top: 400, left: 20, right: 820, bottom: 800, width: 800, height: 400 });

			// Element at viewport 850 → frame-relative = 450, exceeds viewHeight(400)
			mockRect(deepLi, { top: 850, left: 40, right: 200, bottom: 870 });
			mockSize(deepLi, 160, 20);

			const range = createRangeForNode(textNode);
			selection.scrollTo(range);

			// innerTop = 850 - 400 = 450 > viewHeight(400) → needs scroll down
			expect(scrollToSpy).toHaveBeenCalled();
			const scrollArg = scrollToSpy.mock.calls[0][0];
			expect(scrollArg.top).toBeGreaterThan(0);
		});
	});

	describe('simple element scroll', () => {
		it('should scroll to a paragraph below visible area', () => {
			wysiwyg.innerHTML = '<p>line1</p><p>line2</p><p>target</p>';
			const targetP = wysiwyg.querySelectorAll('p')[2];
			const textNode = targetP.firstChild;

			// Below visible area
			mockRect(targetP, { top: 600, left: 20, right: 800, bottom: 620 });
			mockSize(targetP, 780, 20);

			const range = createRangeForNode(textNode);
			selection.scrollTo(range);

			expect(scrollToSpy).toHaveBeenCalled();
		});

		it('should handle node input (not just Range)', () => {
			wysiwyg.innerHTML = '<p>test</p>';
			const p = wysiwyg.querySelector('p');

			mockRect(p, { top: 600, left: 20, right: 800, bottom: 620 });
			mockSize(p, 780, 20);

			selection.scrollTo(p);

			expect(scrollToSpy).toHaveBeenCalled();
		});

		// Regression: a caret already visible in the top comfort band (elH < innerTop <= PADDING)
		// must NOT scroll the frame down. Previously `keepLocalScroll` required innerTop > PADDING, so
		// a caret at innerTop 20~40 got pushed to `toolbarHeight + elH`, scrolling the frame DOWN — and
		// repeated Enter near the top drifted the scroll down while the caret stayed pinned at the top.
		it('should not scroll down when the caret sits in the top comfort band', () => {
			kernel._eventOrchestrator.scrollparents = [];
			selection.__init(); // #scrollMargin(PADDING) = 40, #hasScrollParents = false
			setProp(wwFrame, 'scrollTop', 500);

			wysiwyg.innerHTML = '<p>near top</p>';
			const p = wysiwyg.querySelector('p');
			// innerTop = 130 - 100 = 30, which is in the band (elH=20 < 30 <= PADDING=40)
			mockRect(p, { top: 130, left: 20, right: 800, bottom: 150 });
			mockSize(p, 780, 20);

			selection.scrollTo(createRangeForNode(p.firstChild), { behavior: 'auto' });

			// No downward scroll: either not called, or not scrolled past the current 500.
			if (scrollToSpy.mock.calls.length) {
				expect(scrollToSpy.mock.calls[0][0].top).toBeLessThanOrEqual(500);
			}
		});
	});

	describe('brLine (PRE) caret-based scroll', () => {
		function buildPre() {
			// childNodes: [0]"line1" [1]BR [2]"caret line" [3]BR [4]"line3"
			wysiwyg.innerHTML = '<pre>line1<br>caret line<br>line3</pre>';
			const pre = wysiwyg.querySelector('pre');
			return { pre, textNode: pre.childNodes[2] };
		}

		function caretRange(textNode, rect) {
			const range = document.createRange();
			range.setStart(textNode, 0);
			range.setEnd(textNode, 1);
			range.getBoundingClientRect = jest.fn(() => ({
				top: rect.top, left: rect.left, right: rect.right, bottom: rect.bottom,
				width: rect.right - rect.left, height: rect.bottom - rect.top, x: rect.left, y: rect.top,
			}));
			return range;
		}

		it('auto-height: scrolls to the caret row, not the whole PRE top', () => {
			// auto-height editor (no internal scroll), non-iframe
			kernel.store.get = jest.fn((key) => {
				if (key === 'isScrollable') return () => false; // auto-height
				if (key === 'currentViewportHeight') return LAYOUT.viewportHeight; // 768
				return undefined;
			});
			// el (PRE) is reported near the top & in view — the OLD el-based code would NOT scroll at all.
			kernel.$.offset.getGlobal = jest.fn(() => ({
				top: 100, left: 20, fixedTop: 100, fixedLeft: 20, width: 800, height: 400,
			}));

			const { textNode } = buildPre();
			// caret row is far below the viewport (top=1000) → must scroll down to reveal it
			const range = caretRange(textNode, { top: 1000, left: 20, right: 120, bottom: 1020 });

			selection.scrollTo(range, { behavior: 'auto' });

			// caret-based: window scrolled down (old behavior: getGlobal(PRE).top=100 → in view → no scroll)
			expect(window.scrollTo).toHaveBeenCalled();
			expect(window.scrollTo.mock.calls[0][0].top).toBeGreaterThan(0);
		});

		it('scroll-parent: scrolls the caret row into the scroll container, not el.scrollIntoView', () => {
			// editor embedded in an external scroll container
			const container = document.createElement('div');
			container.scrollBy = jest.fn();
			window.scrollBy = jest.fn();
			mockRect(container, { top: 100, left: 0, right: 800, bottom: 500, width: 800, height: 400 });
			kernel._eventOrchestrator.scrollparents = [container];
			selection.__init(); // picks up #hasScrollParents = true

			kernel.$.format.isBrLine.mockReturnValue(true);

			const { pre, textNode } = buildPre();
			pre.scrollIntoView = jest.fn();
			// caret row sits below the container's visible bottom (500), at top=600
			const range = caretRange(textNode, { top: 600, left: 20, right: 120, bottom: 620 });

			selection.scrollTo(range);

			// caret-based: scroll the container by (caret.bottom 620 - container.bottom 500) = 120, never el.scrollIntoView
			expect(pre.scrollIntoView).not.toHaveBeenCalled();
			expect(container.scrollBy).toHaveBeenCalled();
			expect(container.scrollBy.mock.calls[0][0].top).toBe(120);
		});

		it('scroll-parent: normal (non-brLine) line still uses el.scrollIntoView', () => {
			const container = document.createElement('div');
			container.scrollBy = jest.fn();
			mockRect(container, { top: 100, left: 0, right: 800, bottom: 500, width: 800, height: 400 });
			kernel._eventOrchestrator.scrollparents = [container];
			selection.__init();

			// isBrLine stays false (mock default) → regression guard for normal lines
			wysiwyg.innerHTML = '<p>normal line</p>';
			const p = wysiwyg.querySelector('p');
			p.scrollIntoView = jest.fn();
			const range = createRangeForNode(p.firstChild);

			selection.scrollTo(range);

			expect(p.scrollIntoView).toHaveBeenCalled();
			expect(container.scrollBy).not.toHaveBeenCalled();
		});
	});

	describe('edge cases', () => {
		it('should handle null ref gracefully', () => {
			expect(() => selection.scrollTo(null)).not.toThrow();
			expect(scrollToSpy).not.toHaveBeenCalled();
		});

		it('should handle element at exact boundary', () => {
			const { deepLi, textNode } = buildNestedList();

			// Element exactly at bottom boundary: innerTop = 400 - 100 = 300
			// viewHeight = 400, PADDING = 40: 300 + 40 = 340 <= 400 → visible
			mockRect(deepLi, { top: 400, left: 40, right: 200, bottom: 420 });
			mockSize(deepLi, 160, 20);

			const range = createRangeForNode(textNode);
			selection.scrollTo(range);

			expect(scrollToSpy).not.toHaveBeenCalled();
		});
	});

	// Regression: a top sticky toolbar occupies the viewport band [0, positionToolbarHeight] (sticky offset +
	// toolbar height). In the scroll-parent branch, `scrollIntoView` / `#scrollCaretIntoView` are unaware of that
	// overlay, so a caret that renders just under the toolbar (e.g. after Backspace merges a line and the browser
	// considers it "already visible") was never nudged clear — the old compensation only ran when the window
	// itself scrolled. The nudge measures the CARET rect (not the block) and only acts when the caret sits inside
	// the band `0 <= top < positionToolbarHeight`, so it is bounded by the toolbar height and never over-scrolls.
	describe('sticky top toolbar (scroll-parent branch)', () => {
		let container;

		// positionToolbarHeight = (isSticky ? toolbar.offsetHeight(40) : 0) + _toolbar_sticky
		function setupSticky({ stickyOffset = 60, isSticky = true } = {}) {
			kernel.$.toolbar.isSticky = isSticky;
			kernel.$.options.set('_toolbar_sticky', stickyOffset);

			container = document.createElement('div');
			container.scrollBy = jest.fn();
			mockRect(container, { top: 0, left: 0, right: 800, bottom: 500, width: 800, height: 500 });
			kernel._eventOrchestrator.scrollparents = [container];
			selection.__init(); // #hasScrollParents = true

			window.scrollBy = jest.fn();
		}

		// The nudge reads the CARET (range) rect, not the element rect — mock it explicitly.
		function caretRangeAt(textNode, top, height = 20) {
			const range = document.createRange();
			range.setStart(textNode, 0);
			range.setEnd(textNode, 1);
			range.getBoundingClientRect = jest.fn(() => ({
				top, left: 20, right: 120, bottom: top + height, width: 100, height, x: 20, y: top,
			}));
			return range;
		}

		it('nudges the caret down when it renders under the sticky toolbar (window did not scroll)', () => {
			setupSticky({ stickyOffset: 60 }); // positionToolbarHeight = 40 + 60 = 100

			wysiwyg.innerHTML = '<p>merged line</p>';
			const p = wysiwyg.querySelector('p');
			p.scrollIntoView = jest.fn(); // no-op (jsdom + browser treats it as "already visible")

			// caret line at viewport top=90 → inside the toolbar band [0, 100]
			selection.scrollTo(caretRangeAt(p.firstChild, 90), { behavior: 'auto' });

			// overlap = positionToolbarHeight(100) - top(90) = 10 → scroll window up by 10 so the caret clears it
			expect(window.scrollBy).toHaveBeenCalledWith(0, -10);
		});

		it('does not scroll when the caret already sits below the sticky toolbar', () => {
			setupSticky({ stickyOffset: 60 }); // positionToolbarHeight = 100

			wysiwyg.innerHTML = '<p>safe line</p>';
			const p = wysiwyg.querySelector('p');
			p.scrollIntoView = jest.fn();

			// caret line at viewport top=200, well below the toolbar band → no overlap
			selection.scrollTo(caretRangeAt(p.firstChild, 200), { behavior: 'auto' });

			expect(window.scrollBy).not.toHaveBeenCalled();
		});

		it('does not nudge when the toolbar is not sticky (no overlay to clear)', () => {
			setupSticky({ stickyOffset: 60, isSticky: false }); // positionToolbarHeight = 0

			wysiwyg.innerHTML = '<p>line</p>';
			const p = wysiwyg.querySelector('p');
			p.scrollIntoView = jest.fn();

			selection.scrollTo(caretRangeAt(p.firstChild, 90), { behavior: 'auto' });

			expect(window.scrollBy).not.toHaveBeenCalled();
		});

		// Guard: use the CARET rect, not the block. A tall wrapped paragraph's top can sit far above the caret;
		// measuring the block would compute a huge overlap and scroll the caret off the BOTTOM of the viewport.
		it('does not over-scroll a tall block whose caret is already below the toolbar', () => {
			setupSticky({ stickyOffset: 60 }); // positionToolbarHeight = 100

			wysiwyg.innerHTML = '<p>tall wrapped paragraph</p>';
			const p = wysiwyg.querySelector('p');
			p.scrollIntoView = jest.fn();
			// Block spans far above the viewport (top=-300), but the caret's visual line is at top=250 (below band).
			mockRect(p, { top: -300, left: 20, right: 780, bottom: 260 });
			mockSize(p, 760, 560);

			selection.scrollTo(caretRangeAt(p.firstChild, 250), { behavior: 'auto' });

			expect(window.scrollBy).not.toHaveBeenCalled();
		});

		// Guard: skip an off-screen / mid-animation caret rect (top < 0). `behavior:'auto'` obeys the page's CSS
		// `scroll-behavior`; under `smooth` the scroll above is async and the rect can be stale/negative. Nudging
		// on a negative top would jump the viewport by more than the toolbar height.
		it('does not nudge when the caret rect is above the viewport (stale/off-screen)', () => {
			setupSticky({ stickyOffset: 60 }); // positionToolbarHeight = 100

			wysiwyg.innerHTML = '<p>line</p>';
			const p = wysiwyg.querySelector('p');
			p.scrollIntoView = jest.fn();

			selection.scrollTo(caretRangeAt(p.firstChild, -40), { behavior: 'auto' });

			expect(window.scrollBy).not.toHaveBeenCalled();
		});

		// Guard: a collapsed range can return an all-zero rect (top:0, height:0). `height > 0` skips it, otherwise
		// top=0 would trigger a spurious full-toolbar-height scroll.
		it('does not nudge on a zero-height (collapsed/degenerate) caret rect', () => {
			setupSticky({ stickyOffset: 60 }); // positionToolbarHeight = 100

			wysiwyg.innerHTML = '<p>line</p>';
			const p = wysiwyg.querySelector('p');
			p.scrollIntoView = jest.fn();

			selection.scrollTo(caretRangeAt(p.firstChild, 0, 0), { behavior: 'auto' });

			expect(window.scrollBy).not.toHaveBeenCalled();
		});

		it('nudges the brLine caret row clear of the sticky toolbar', () => {
			setupSticky({ stickyOffset: 60 }); // positionToolbarHeight = 100
			kernel.$.format.isBrLine.mockReturnValue(true);

			wysiwyg.innerHTML = '<pre>line1<br>caret line<br>line3</pre>';
			const pre = wysiwyg.querySelector('pre');
			pre.scrollIntoView = jest.fn();

			// caret row at viewport top=85 → within the container [0,500] & window view (so #scrollCaretIntoView is
			// a no-op), but inside the toolbar band [0, 100]
			const range = caretRangeAt(pre.childNodes[2], 85);
			selection.scrollTo(range, { behavior: 'auto' });

			// #scrollCaretIntoView leaves the caret at top=85; nudge by overlap = 100 - 85 = 15
			expect(container.scrollBy).not.toHaveBeenCalled(); // already within the container view
			expect(window.scrollBy).toHaveBeenCalledWith(0, -15);
		});
	});

	// Regression: in the auto-height (page-scroll) non-iframe branch, the top-clearance check added PADDING on
	// top of the sticky toolbar height. That pulled a still-visible caret downward on Backspace-up (it had to sit
	// PADDING below the toolbar to avoid a scroll), while Enter-down felt fine. The caret only needs to clear the
	// toolbar (caretTop >= topToolbarH); no extra PADDING gap.
	describe('sticky top toolbar (auto-height, non-iframe)', () => {
		function setupAutoHeightSticky({ stickyOffset = 20 } = {}) {
			kernel.store.get = jest.fn((key) => {
				if (key === 'isScrollable') return () => false; // auto-height (page scrolls, not the frame)
				if (key === 'currentViewportHeight') return 768;
				return undefined;
			});
			kernel.$.toolbar.isSticky = true;
			kernel.$.options.set('_toolbar_sticky', stickyOffset); // positionToolbarHeight = 40 + offset
			kernel._eventOrchestrator.scrollparents = [];
			selection.__init(); // #hasScrollParents = false, #scrollMargin (PADDING) = 40
			window.scrollTo = jest.fn();
			Object.defineProperty(window, 'scrollY', { value: 0, configurable: true, writable: true });
		}

		function caretRangeAt(textNode, top, height = 20) {
			const range = document.createRange();
			range.setStart(textNode, 0);
			range.setEnd(textNode, 1);
			range.getBoundingClientRect = jest.fn(() => ({
				top, left: 20, right: 120, bottom: top + height, width: 100, height, x: 20, y: top,
			}));
			return range;
		}

		it('does not pull a visible caret that already clears the sticky toolbar (Backspace-up)', () => {
			setupAutoHeightSticky({ stickyOffset: 20 }); // topToolbarH = 40 + 20 = 60

			wysiwyg.innerHTML = '<p>near top line</p>';
			const p = wysiwyg.querySelector('p');
			// caret top=70 → just below the toolbar band bottom (60); fully visible.
			// Old check: vBot(90) > PADDING(40) + topToolbarH(60) = 100 → false → scrolled down (the "pull").
			// Fixed: caretTop(70) >= topToolbarH(60) → clear → no scroll.
			selection.scrollTo(caretRangeAt(p.firstChild, 70), { behavior: 'auto' });

			expect(window.scrollTo).not.toHaveBeenCalled();
		});

		it('still scrolls to reveal a caret hidden under the sticky toolbar', () => {
			setupAutoHeightSticky({ stickyOffset: 20 }); // topToolbarH = 60

			wysiwyg.innerHTML = '<p>hidden line</p>';
			const p = wysiwyg.querySelector('p');
			// caret top=30 → inside the toolbar band [0, 60] → must scroll down to reveal it
			selection.scrollTo(caretRangeAt(p.firstChild, 30), { behavior: 'auto' });

			expect(window.scrollTo).toHaveBeenCalled();
		});

		// Regression (Backspace-up, sticky top): a caret entering the toolbar band needs only a small,
		// net-DOWNWARD correction (newScrollTop >= scrollY). The old `newScrollTop < scrollY` gate skipped the
		// `- topToolbarH` clearance there, so the caret landed a sticky-offset short — still under the toolbar —
		// and only cleared it once further Backspace pushed it off the top (a clear upward scroll). The actual
		// `_w.scrollTo` destination must include the toolbar offset regardless of the net scroll direction.
		it('clears the toolbar on a net-downward correction while the caret is under it', () => {
			setupAutoHeightSticky({ stickyOffset: 20 }); // topToolbarH = 40 + 20 = 60, PADDING = 40
			Object.defineProperty(window, 'scrollY', { value: 200, configurable: true, writable: true });

			wysiwyg.innerHTML = '<p>merged line</p>';
			const p = wysiwyg.querySelector('p');
			// caret viewport top=50 -> inside the band [20, 60]; rectTop = 50 + scrollY(200) = 250.
			// scrollMargin large -> branch B; newScrollTop = rectTop - PADDING = 210 >= scrollY(200), so the old
			// direction gate skipped the toolbar offset and left the caret viewport at 40 (still under the band).
			selection.scrollTo(caretRangeAt(p.firstChild, 50), { behavior: 'auto' });

			expect(window.scrollTo).toHaveBeenCalled();
			const dest = window.scrollTo.mock.calls[0][0].top;
			// caret's resulting viewport position must clear the toolbar band (>= topToolbarH), not sit under it
			const caretViewportTop = 250 - dest; // rectTop - scrollDest
			expect(caretViewportTop).toBeGreaterThanOrEqual(60);
			expect(dest).toBe(150); // 210 - topToolbarH(60) -> caret at 60 + PADDING(40) = 100
		});

		// The top-clearance change (caretTop >= topToolbarH) is only the SECOND operand of the early-return; the
		// bottom PADDING check `scrollMargin - PADDING > 0` is independent and still applies with a sticky toolbar.
		// So Enter-down overshoot past the viewport bottom still scrolls, honoring the bottom PADDING.
		it('still honors the bottom PADDING when the caret overshoots below the viewport (Enter-down)', () => {
			setupAutoHeightSticky({ stickyOffset: 20 }); // topToolbarH = 60, viewHeight = 768, PADDING = 40

			wysiwyg.innerHTML = '<p>bottom line</p>';
			const p = wysiwyg.querySelector('p');
			// caret top=750 → vBot=770, past the bottom PADDING band (viewHeight - PADDING = 728). caretTop(750)
			// clears the toolbar, but the bottom check fails → must scroll DOWN to keep the PADDING gap.
			selection.scrollTo(caretRangeAt(p.firstChild, 750), { behavior: 'auto' });

			expect(window.scrollTo).toHaveBeenCalled();
			expect(window.scrollTo.mock.calls[0][0].top).toBeGreaterThan(0); // scrolled down
		});

		it('is unchanged when the toolbar is not sticky (topToolbarH === 0 keeps the PADDING comfort margin)', () => {
			setupAutoHeightSticky({ stickyOffset: 20 });
			kernel.$.toolbar.isSticky = false; // topToolbarH = 0 → original PADDING-based top check

			wysiwyg.innerHTML = '<p>line</p>';
			const p = wysiwyg.querySelector('p');
			// caret top=10 → within the top PADDING(40) band, no toolbar → original behavior scrolls it clear
			selection.scrollTo(caretRangeAt(p.firstChild, 10), { behavior: 'auto' });

			expect(window.scrollTo).toHaveBeenCalled();
		});
	});
});
