/**
 * @fileoverview Unit tests for plugins/dropdown/hr.js
 */

import HR from '../../../../src/plugins/dropdown/hr.js';
import { createMockEditor } from '../../../../test/__mocks__/editorMock.js';

// Mock helper
jest.mock('../../../../src/helper', () => ({
	dom: {
		utils: {
			createElement: jest.fn().mockImplementation((tag, attrs, content) => {
				const element = {
					tagName: tag.toUpperCase(),
					className: attrs?.class || '',
					innerHTML: content || '',
					style: {},
					querySelectorAll: jest.fn().mockReturnValue([
						{
							tagName: 'BUTTON',
							getAttribute: jest.fn().mockReturnValue('hr'),
							firstElementChild: { className: '__se__solid' },
						},
						{
							tagName: 'BUTTON',
							getAttribute: jest.fn().mockReturnValue('hr'),
							firstElementChild: { className: '__se__dashed' },
						},
						{
							tagName: 'BUTTON',
							getAttribute: jest.fn().mockReturnValue('hr'),
							firstElementChild: { className: '__se__dotted' },
						},
					]),
					getAttribute: jest.fn(),
					setAttribute: jest.fn(),
				};
				if (attrs) {
					Object.keys(attrs).forEach((key) => {
						if (key === 'class') element.className = attrs[key];
						else element.setAttribute(key, attrs[key]);
					});
				}
				return element;
			}),
			addClass: jest.fn(),
			removeClass: jest.fn(),
			removeItem: jest.fn(),
		},
	},
}));

describe('Plugins - Dropdown - HR', () => {
	let kernel;
	let hr;
	let pluginOptions;

	beforeEach(() => {
		jest.clearAllMocks();

		kernel = createMockEditor();
		kernel.$.menu.initDropdownTarget = jest.fn().mockImplementation(() => {
			const { dom } = require('../../../../src/helper');
			return dom.utils.createElement('DIV', {}, '');
		});
		kernel.$.lang.horizontalLine = 'Horizontal Line';
		kernel.$.lang.hr_solid = 'Solid';
		kernel.$.lang.hr_dashed = 'Dashed';
		kernel.$.lang.hr_dotted = 'Dotted';

		pluginOptions = {
			items: [
				{ name: 'Custom Solid', class: '__se__custom-solid' },
				{ name: 'Custom Dashed', class: '__se__custom-dashed', style: 'border-top: 2px dashed red;' },
			],
		};

		hr = new HR(kernel, pluginOptions);
	});

	describe('Static component method', () => {
		it('should return HR node when node is HR element', () => {
			const hrNode = { nodeName: 'HR' };
			const result = HR.component(hrNode);
			expect(result).toBe(hrNode);
		});

		it('should return HR node when node is hr element (lowercase)', () => {
			const hrNode = { nodeName: 'hr' };
			const result = HR.component(hrNode);
			expect(result).toBe(hrNode);
		});

		it('should return null for non-HR elements', () => {
			const divNode = { nodeName: 'DIV' };
			const result = HR.component(divNode);
			expect(result).toBeNull();
		});

		it('should return null for null/undefined node', () => {
			expect(HR.component(null)).toBeNull();
			expect(HR.component(undefined)).toBeNull();
		});

		it('should return null for node without nodeName', () => {
			const invalidNode = {};
			const result = HR.component(invalidNode);
			expect(result).toBeNull();
		});
	});

	describe('Constructor', () => {
		it('should create HR instance with required properties', () => {
			expect(hr).toBeInstanceOf(HR);
			expect(hr.title).toBe('Horizontal Line');
			expect(hr.icon).toBe('horizontal_line');
			expect(hr.list).toBeDefined();
		});

		it('should initialize dropdown menu with items and options', () => {
			expect(kernel.$.menu.initDropdownTarget).toHaveBeenCalledWith(HR, expect.any(Array), expect.any(Object));
		});

		it('should initialize list from menu', () => {
			expect(hr.list).toHaveLength(3);
		});

		it('should use default items when none provided', () => {
			const defaultHR = new HR(kernel, {});
			expect(defaultHR.list).toBeDefined();
		});
	});

	describe('componentSelect method', () => {
		it('should add "on" class to target element', () => {
			const mockTarget = document.createElement('hr');
			const { dom } = require('../../../../src/helper');

			hr.componentSelect(mockTarget);

			expect(dom.utils.addClass).toHaveBeenCalledWith(mockTarget, 'on');
		});

		it('should handle null target gracefully', () => {
			const { dom } = require('../../../../src/helper');

			expect(() => {
				hr.componentSelect(null);
			}).not.toThrow();

			expect(dom.utils.addClass).toHaveBeenCalledWith(null, 'on');
		});
	});

	describe('deselect method', () => {
		it('should remove "on" class from target element', () => {
			const mockTarget = document.createElement('hr');
			const { dom } = require('../../../../src/helper');

			hr.componentDeselect(mockTarget);

			expect(dom.utils.removeClass).toHaveBeenCalledWith(mockTarget, 'on');
		});

		it('should handle null element gracefully', () => {
			const { dom } = require('../../../../src/helper');

			expect(() => {
				hr.componentDeselect(null);
			}).not.toThrow();

			expect(dom.utils.removeClass).toHaveBeenCalledWith(null, 'on');
		});
	});

	describe('destroy method', () => {
		let mockTarget;

		beforeEach(() => {
			mockTarget = {
				previousElementSibling: document.createElement('p'),
				nextElementSibling: document.createElement('p'),
			};
		});

		it('should remove target and focus previous sibling', () => {
			const { dom } = require('../../../../src/helper');

			hr.componentDestroy(mockTarget);

			expect(dom.utils.removeItem).toHaveBeenCalledWith(mockTarget);
			expect(kernel.$.focusManager.focusEdge).toHaveBeenCalledWith(mockTarget.previousElementSibling);
			expect(kernel.$.history.push).toHaveBeenCalledWith(false);
		});

		it('should focus next sibling when no previous sibling', () => {
			mockTarget.previousElementSibling = null;

			hr.componentDestroy(mockTarget);

			expect(kernel.$.focusManager.focusEdge).toHaveBeenCalledWith(mockTarget.nextElementSibling);
		});

		it('should handle null target gracefully', () => {
			expect(() => {
				hr.componentDestroy(null);
			}).not.toThrow();

			const { dom } = require('../../../../src/helper');
			expect(dom.utils.removeItem).not.toHaveBeenCalled();
			expect(kernel.$.focusManager.focusEdge).not.toHaveBeenCalled();
			expect(kernel.$.history.push).not.toHaveBeenCalled();
		});

		it('should handle target with no siblings', () => {
			mockTarget.previousElementSibling = null;
			mockTarget.nextElementSibling = null;

			hr.componentDestroy(mockTarget);

			expect(kernel.$.focusManager.focusEdge).toHaveBeenCalledWith(null);
		});

		it('should always push history when target exists', () => {
			hr.componentDestroy(mockTarget);

			expect(kernel.$.history.push).toHaveBeenCalledWith(false);
		});
	});

	describe('action method', () => {
		let mockTarget;

		beforeEach(() => {
			mockTarget = {
				firstElementChild: { className: '__se__solid' },
			};
		});

		it('should create HR with correct class and insert it', () => {
			const mockLine = document.createElement('p');
			kernel.$.format.addLine.mockReturnValue(mockLine);

			hr.action(mockTarget);

			// Check that submit was called with correct className
			expect(kernel.component.insert).toHaveBeenCalled();
			expect(kernel.$.format.addLine).toHaveBeenCalled();
			expect(kernel.$.selection.setRange).toHaveBeenCalledWith(mockLine, 1, mockLine, 1);
			expect(kernel.$.menu.dropdownOff).toHaveBeenCalled();
		});

		it('should handle different HR classes', () => {
			mockTarget.firstElementChild.className = '__se__dashed';

			hr.action(mockTarget);

			expect(kernel.component.insert).toHaveBeenCalled();
		});

		it('should handle empty className', () => {
			mockTarget.firstElementChild.className = '';

			hr.action(mockTarget);

			expect(kernel.component.insert).toHaveBeenCalled();
		});

		it('should handle missing firstElementChild', () => {
			mockTarget.firstElementChild = null;

			expect(() => {
				hr.action(mockTarget);
			}).toThrow();
		});
	});

	describe('shortcut method', () => {
		let mockParams;

		beforeEach(() => {
			mockParams = {
				line: document.createElement('p'),
				range: {
					endContainer: document.createElement('span'),
					endOffset: 1,
				},
			};
		});

		it('should split range and insert solid HR', () => {
			const mockNewLine = document.createElement('p');
			kernel.nodeTransform.split.mockReturnValue(mockNewLine);

			hr.shortcut(mockParams);

			expect(kernel.nodeTransform.split).toHaveBeenCalledWith(mockParams.range.endContainer, mockParams.range.endOffset, 0);
			expect(kernel.component.insert).toHaveBeenCalled();
			const { dom } = require('../../../../src/helper');
			expect(dom.utils.removeItem).toHaveBeenCalledWith(mockParams.line);
			expect(kernel.$.selection.setRange).toHaveBeenCalledWith(mockNewLine, 0, mockNewLine, 0);
		});

		it('should always use solid HR class in shortcut', () => {
			hr.shortcut(mockParams);

			// Verify that submit was called with '__se__solid'
			expect(kernel.component.insert).toHaveBeenCalled();
		});

		it('should handle null range gracefully', () => {
			mockParams.range = null;

			expect(() => {
				hr.shortcut(mockParams);
			}).toThrow();
		});
	});

	describe('submit method', () => {
		it('should create HR element with correct class and insert it', () => {
			const className = '__se__custom';
			const { dom } = require('../../../../src/helper');

			const result = hr.submit(className);

			expect(dom.utils.createElement).toHaveBeenCalledWith('hr', { class: className });
			expect(kernel.$.focusManager.focus).toHaveBeenCalled();
			expect(kernel.component.insert).toHaveBeenCalledWith(expect.any(Object), { insertBehavior: 'line' });
			expect(result).toBeDefined();
		});

		it('should handle empty className', () => {
			const result = hr.submit('');

			expect(result).toBeDefined();
			expect(kernel.component.insert).toHaveBeenCalled();
		});

		it('should handle null className', () => {
			const result = hr.submit(null);

			expect(result).toBeDefined();
		});

		it('should always focus editor before inserting', () => {
			hr.submit('__se__solid');

			expect(kernel.$.focusManager.focus).toHaveBeenCalled();
		});

		it('should use line insertion behavior', () => {
			hr.submit('__se__solid');

			expect(kernel.component.insert).toHaveBeenCalledWith(expect.any(Object), { insertBehavior: 'line' });
		});
	});

	describe('CreateItems function', () => {
		it('should pass correct items to initDropdownTarget', () => {
			const items = kernel.$.menu.initDropdownTarget.mock.calls[0][1];

			expect(items).toBeInstanceOf(Array);
			expect(items.length).toBe(2);
			expect(items[0].command).toBe('hr');
			expect(items[1].command).toBe('hr');
			expect(items[0].title).toBe('Custom Solid');
			expect(items[1].title).toBe('Custom Dashed');
			expect(items[0].innerHTML).toContain('__se__custom-solid');
			expect(items[1].innerHTML).toContain('__se__custom-dashed');
		});

		it('should include default HR styles when no items provided', () => {
			kernel.$.menu.initDropdownTarget.mockClear();

			const defaultHR = new HR(kernel, {});

			const items = kernel.$.menu.initDropdownTarget.mock.calls[0][1];
			const titles = items.map(item => item.title);

			expect(titles).toContain('Solid');
			expect(titles).toContain('Dashed');
			expect(titles).toContain('Dotted');

			const htmls = items.map(item => item.innerHTML);
			expect(htmls.some(h => h.includes('__se__solid'))).toBe(true);
			expect(htmls.some(h => h.includes('__se__dashed'))).toBe(true);
			expect(htmls.some(h => h.includes('__se__dotted'))).toBe(true);
		});

		it('should handle items with style attribute', () => {
			const items = kernel.$.menu.initDropdownTarget.mock.calls[0][1];

			expect(items[1].innerHTML).toContain('border-top: 2px dashed red;');
		});

		it('should handle items without class', () => {
			kernel.$.menu.initDropdownTarget.mockClear();

			const noClassHR = new HR(kernel, {
				items: [{ name: 'No Class HR' }],
			});

			const items = kernel.$.menu.initDropdownTarget.mock.calls[0][1];

			expect(items).toHaveLength(1);
			expect(items[0].title).toBe('No Class HR');
			expect(items[0].innerHTML).toContain('<hr/>');
		});

		it('should handle items without style', () => {
			kernel.$.menu.initDropdownTarget.mockClear();

			const noStyleHR = new HR(kernel, {
				items: [{ name: 'No Style HR', class: '__se__no-style' }],
			});

			const items = kernel.$.menu.initDropdownTarget.mock.calls[0][1];

			expect(items).toHaveLength(1);
			expect(items[0].title).toBe('No Style HR');
			expect(items[0].innerHTML).toContain('__se__no-style');
			expect(items[0].innerHTML).not.toContain('style=');
		});

		it('should handle empty items array', () => {
			kernel.$.menu.initDropdownTarget.mockClear();

			const emptyItemsHR = new HR(kernel, { items: [] });

			const items = kernel.$.menu.initDropdownTarget.mock.calls[0][1];

			// Empty items should fall back to defaults
			expect(items).toBeInstanceOf(Array);
		});
	});

	describe('Integration', () => {
		it('should work with editor component module', () => {
			const mockTarget = {
				firstElementChild: { className: '__se__solid' },
			};

			expect(() => {
				hr.action(mockTarget);
			}).not.toThrow();

			expect(kernel.component.insert).toHaveBeenCalled();
		});

		it('should work with editor format module', () => {
			const mockTarget = {
				firstElementChild: { className: '__se__solid' },
			};

			hr.action(mockTarget);

			expect(kernel.$.format.addLine).toHaveBeenCalled();
		});

		it('should work with editor selection module', () => {
			const mockTarget = {
				firstElementChild: { className: '__se__solid' },
			};

			hr.action(mockTarget);

			expect(kernel.$.selection.setRange).toHaveBeenCalled();
		});

		it('should work with node transformation', () => {
			const mockParams = {
				line: document.createElement('p'),
				range: {
					endContainer: document.createElement('span'),
					endOffset: 1,
				},
			};

			hr.shortcut(mockParams);

			expect(kernel.nodeTransform.split).toHaveBeenCalled();
		});
	});

	describe('Error handling', () => {
		it('should handle missing editor modules gracefully', () => {
			kernel.component = undefined;

			expect(() => {
				new HR(kernel, {});
			}).not.toThrow();
		});

		it('should handle missing list gracefully', () => {
			hr.list = [];

			expect(() => {
				hr.componentSelect(document.createElement('hr'));
			}).not.toThrow();
		});

		it('should handle malformed target in action method', () => {
			const mockTarget = {};

			expect(() => {
				hr.action(mockTarget);
			}).toThrow();
		});

		it('should handle missing plugin options', () => {
			expect(() => {
				new HR(kernel, {});
			}).not.toThrow();
		});

		it('should handle null plugin options', () => {
			expect(() => {
				new HR(kernel, null);
			}).toThrow(); // Will throw when accessing null.items
		});

		it('should handle items with missing properties', () => {
			const incompleteItems = [
				{ name: 'Test' }, // missing class - should still work
				{}, // missing name and class - should still work
			];

			expect(() => {
				new HR(kernel, { items: incompleteItems });
			}).not.toThrow();
		});

		it('should handle undefined firstElementChild gracefully', () => {
			const mockTarget = { firstElementChild: undefined };

			expect(() => {
				hr.action(mockTarget);
			}).toThrow();
		});
	});
});
