/**
 * @fileoverview Unit tests for plugins/dropdown/layout.js
 */

import Layout from '../../../../src/plugins/dropdown/layout.js';
import { createMockEditor } from '../../../../test/__mocks__/editorMock.js';

// Mock helper
jest.mock('../../../../src/helper', () => ({
    dom: {
        utils: {
            createElement: jest.fn().mockImplementation((tag, attrs, content) => {
                const element = {
                    tagName: tag.toUpperCase(),
                    className: attrs?.class || '',
                    innerHTML: content || '',
                    style: {},
                    getAttribute: jest.fn(),
                    setAttribute: jest.fn(),
                    querySelectorAll: jest.fn().mockReturnValue([
                        { className: 'se-layout-item', getAttribute: jest.fn().mockReturnValue('layout1') },
                        { className: 'se-layout-item', getAttribute: jest.fn().mockReturnValue('layout2') },
                        { className: 'se-layout-item', getAttribute: jest.fn().mockReturnValue('layout3') }
                    ])
                };
                if (attrs) {
                    Object.keys(attrs).forEach(key => {
                        if (key === 'class') element.className = attrs[key];
                        else element.setAttribute(key, attrs[key]);
                    });
                }
                return element;
            }),
            addClass: jest.fn(),
            removeClass: jest.fn()
        }
    }
}));

describe('Plugins - Dropdown - Layout', () => {
    let kernel;
    let layout;

    beforeEach(() => {
        jest.clearAllMocks();

        kernel = createMockEditor();

        const { dom } = require('../../../../src/helper');
        kernel.$.menu.initDropdownTarget = jest.fn().mockImplementation(() => dom.utils.createElement('DIV', {}, ''));

        const pluginOptions = {
            items: [
                { name: 'Layout 1', html: '<div class="layout-1"><p>Layout 1 content</p></div>' },
                { name: 'Layout 2', html: '<div class="layout-2"><p>Layout 2 content</p></div>' },
                { name: 'Layout 3', html: '<div class="layout-3"><p>Layout 3 content</p></div>' }
            ]
        };

        layout = new Layout(kernel, pluginOptions);
    });


    describe('Constructor', () => {

        it('should initialize dropdown menu', () => {
            expect(kernel.$.menu.initDropdownTarget).toHaveBeenCalledWith(Layout, expect.any(Array));
        });

        it('should create layout items with correct structure', () => {
            expect(layout.items).toBeDefined();
            expect(layout.items).toHaveLength(3);
            expect(layout.items[0]).toEqual({ name: 'Layout 1', html: '<div class="layout-1"><p>Layout 1 content</p></div>' });
        });
    });

    describe('action method', () => {
        let mockTarget;

        beforeEach(() => {
            mockTarget = {
                getAttribute: jest.fn().mockReturnValue('1')
            };
        });

        it('should set HTML content from selected layout item', () => {
            layout.action(mockTarget);

            expect(mockTarget.getAttribute).toHaveBeenCalledWith('data-value');
            expect(kernel.$.html.set).toHaveBeenCalledWith('<div class="layout-2"><p>Layout 2 content</p></div>');
            expect(layout.selectedIndex).toBe(1);
            expect(kernel.$.menu.dropdownOff).toHaveBeenCalled();
        });

        it('should handle first layout item (index 0)', () => {
            mockTarget.getAttribute.mockReturnValue('0');

            layout.action(mockTarget);

            expect(kernel.$.html.set).toHaveBeenCalledWith('<div class="layout-1"><p>Layout 1 content</p></div>');
            expect(layout.selectedIndex).toBe(0);
        });

        it('should handle last layout item (index 2)', () => {
            mockTarget.getAttribute.mockReturnValue('2');

            layout.action(mockTarget);

            expect(kernel.$.html.set).toHaveBeenCalledWith('<div class="layout-3"><p>Layout 3 content</p></div>');
            expect(layout.selectedIndex).toBe(2);
        });

        it('should throw error when layout item has no html property', () => {
            layout.items[1] = { name: 'Layout 2' }; // missing html property
            mockTarget.getAttribute.mockReturnValue('1');

            expect(() => {
                layout.action(mockTarget);
            }).toThrow('[SUNEDITOR.layout.fail] cause : "layouts[i].html not found"');

            expect(kernel.$.menu.dropdownOff).toHaveBeenCalled();
        });

        it('should handle invalid index gracefully', () => {
            mockTarget.getAttribute.mockReturnValue('99');

            expect(() => {
                layout.action(mockTarget);
            }).toThrow();
        });
    });

    describe('CreateItems function', () => {
        it('should pass correct items to initDropdownTarget for layout items', () => {
            const items = kernel.$.menu.initDropdownTarget.mock.calls[0][1];

            expect(items).toHaveLength(3);
            expect(items[0]).toMatchObject({ command: 'layout', title: 'Layout 1', innerHTML: 'Layout 1', value: '0' });
            expect(items[1]).toMatchObject({ command: 'layout', title: 'Layout 2', innerHTML: 'Layout 2', value: '1' });
            expect(items[2]).toMatchObject({ command: 'layout', title: 'Layout 3', innerHTML: 'Layout 3', value: '2' });
        });

        it('should warn when no layout items provided', () => {
            const consoleSpy = jest.spyOn(console, 'warn').mockImplementation();

            new Layout(kernel, { items: [] });

            expect(consoleSpy).toHaveBeenCalledWith('[SUNEDITOR.plugins.layout.warn] To use the "layout" plugin, please define the "layouts" option.');

            consoleSpy.mockRestore();
        });
    });

    describe('Integration', () => {
        it('should work with editor html module', () => {
            const mockTarget = {
                getAttribute: jest.fn().mockReturnValue('0')
            };

            expect(() => {
                layout.action(mockTarget);
            }).not.toThrow();

            expect(kernel.$.html.set).toHaveBeenCalledWith('<div class="layout-1"><p>Layout 1 content</p></div>');
        });

        it('should handle different layout templates', () => {
            const mockTargets = [
                { getAttribute: jest.fn().mockReturnValue('0') },
                { getAttribute: jest.fn().mockReturnValue('1') },
                { getAttribute: jest.fn().mockReturnValue('2') }
            ];

            mockTargets.forEach((target, index) => {
                layout.action(target);
                expect(layout.selectedIndex).toBe(index);
                expect(kernel.$.html.set).toHaveBeenCalledWith(layout.items[index].html);
            });
        });
    });

    describe('Error handling', () => {
        it('should handle missing items array', () => {
            layout.items = undefined;

            const mockTarget = {
                getAttribute: jest.fn().mockReturnValue('0')
            };

            expect(() => {
                layout.action(mockTarget);
            }).toThrow();
        });

        it('should handle missing editor dependencies gracefully', () => {
            const incompleteEditor = {
                lang: { layout: 'Layout' }
            };

            expect(() => {
                new Layout(incompleteEditor, { items: [] });
            }).toThrow();
        });
    });
});