import Env from './env';
import Unicode from './unicode';
import Converter from './converter';
import Dom from './dom';
import Numbers from './numbers';
import KeyCodeMap from './keyCodeMap';
import Clipboard from './clipboard';
import Markdown from './markdown';
import MSOffice from './msOffice';
import GoogleDocs from './googleDocs';

export const env = Env;
export const unicode = Unicode;
export const converter = Converter;
export const dom = Dom;
export const numbers = Numbers;
export const keyCodeMap = KeyCodeMap;
export const clipboard = Clipboard;
export const markdown = Markdown;
export const msOffice = MSOffice;
export const googleDocs = GoogleDocs;

export default {
	env,
	unicode,
	converter,
	dom,
	numbers,
	keyCodeMap,
	clipboard,
	markdown,
	msOffice,
	googleDocs,
};
