// command
import blockquote from './command/blockquote';
import codeBlock from './command/codeBlock';
import exportPDF from './command/exportPDF';
import fileUpload from './command/fileUpload';
import list_bulleted from './command/list_bulleted';
import list_numbered from './command/list_numbered';

// field
import autocomplete from './field/autocomplete';
import slashCommand from './field/slashCommand';

// dropdown
import align from './dropdown/align';
import font from './dropdown/font';
import fontColor from './dropdown/fontColor';
import backgroundColor from './dropdown/backgroundColor';
import hr from './dropdown/hr';
import list from './dropdown/list';
import table from './dropdown/table';
import blockStyle from './dropdown/blockStyle';
import layout from './dropdown/layout';
import lineHeight from './dropdown/lineHeight';
import template from './dropdown/template';
import paragraphStyle from './dropdown/paragraphStyle';
import textStyle from './dropdown/textStyle';

// modal
import link from './modal/link';
import image from './modal/image';
import video from './modal/video';
import audio from './modal/audio';
import embed from './modal/embed';
import math from './modal/math';
import drawing from './modal/drawing';

// file browser
import imageGallery from './browser/imageGallery';
import videoGallery from './browser/videoGallery';
import audioGallery from './browser/audioGallery';
import fileGallery from './browser/fileGallery';
import fileBrowser from './browser/fileBrowser';

// input
import fontSize from './input/fontSize';
import pageNavigator from './input/pageNavigator';

// popup
import anchor from './popup/anchor';

export {
	blockquote,
	codeBlock,
	exportPDF,
	fileUpload,
	list_bulleted,
	list_numbered,
	autocomplete,
	slashCommand,
	align,
	font,
	fontColor,
	backgroundColor,
	list,
	table,
	blockStyle,
	hr,
	layout,
	lineHeight,
	template,
	paragraphStyle,
	textStyle,
	link,
	image,
	video,
	audio,
	embed,
	math,
	drawing,
	imageGallery,
	videoGallery,
	audioGallery,
	fileGallery,
	fileBrowser,
	fontSize,
	pageNavigator,
	anchor,
};
export default {
	blockquote,
	codeBlock,
	exportPDF,
	fileUpload,
	list_bulleted,
	list_numbered,
	autocomplete,
	slashCommand,
	align,
	font,
	fontColor,
	backgroundColor,
	list,
	table,
	blockStyle,
	hr,
	layout,
	lineHeight,
	template,
	paragraphStyle,
	textStyle,
	link,
	image,
	video,
	audio,
	embed,
	math,
	drawing,
	imageGallery,
	videoGallery,
	audioGallery,
	fileGallery,
	fileBrowser,
	fontSize,
	pageNavigator,
	anchor,
};
