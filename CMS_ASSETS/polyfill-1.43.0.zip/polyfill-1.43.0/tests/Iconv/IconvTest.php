<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Polyfill\Tests\Iconv;

use PHPUnit\Framework\TestCase;
use Symfony\Polyfill\Iconv\Iconv as p;

/**
 * @author Nicolas Grekas <p@tchwork.com>
 *
 * @covers \Symfony\Polyfill\Iconv\Iconv::<!public>
 */
class IconvTest extends TestCase
{
    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv
     */
    public function testIconv()
    {
        $this->assertFalse(@iconv('UTF-8', 'ISO-8859-1', 'nœud'));
        $this->assertSame('nud', iconv('UTF-8', 'ISO-8859-1//IGNORE', 'nœud'));

        $this->assertSame(mb_convert_encoding('déjà', 'ISO-8859-1', 'UTF-8'), iconv('CP1252', 'ISO-8859-1', mb_convert_encoding('déjà', 'ISO-8859-1', 'UTF-8')));
        $this->assertSame('deja noeud', p::iconv('UTF-8//ignore//IGNORE', 'US-ASCII//TRANSLIT//IGNORE//translit', 'déjà nœud'));

        $this->assertSame('4', iconv('UTF-8', 'UTF-8', 4));
        $this->assertSame('aa', p::iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', "a\xC2\x96a"));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv
     */
    public function testIconvTranslitToBaseLetter()
    {
        $this->assertSame('u c K A', p::iconv('UTF-8', 'ASCII//TRANSLIT', "\u{01D6} \u{1E09} \u{212A} \u{212B}"));
        $this->assertFalse(@p::iconv('UTF-8', 'ASCII//TRANSLIT', "\u{2126}"));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_strlen
     */
    public function testIconvStrlen()
    {
        $this->assertSame(4, iconv_strlen('déjà', 'UTF-8'));
        $this->assertSame(3, iconv_strlen('한국어', 'UTF-8'));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_strpos
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_strrpos
     */
    public function testIconvStrPos()
    {
        $this->assertSame(1, iconv_strpos('11--', '1-', 0, 'UTF-8'));
        $this->assertSame(2, iconv_strpos('-11--', '1-', 0, 'UTF-8'));
        $this->assertFalse(iconv_strrpos('한국어', '', 'UTF-8'));
        $this->assertSame(1, iconv_strrpos('한국어', '국', 'UTF-8'));
        $this->assertSame(0, iconv_strrpos('한국어', '한', 'UTF-8'));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_substr
     */
    public function testIconvSubstr()
    {
        $this->assertSame('x', iconv_substr('x', 0, 1, 'UTF-8'));
        $this->assertSame('éj', iconv_substr('déjà', 1, 2, 'utf-8'));
        $this->assertFalse(@iconv_substr("d\xE9j\xE0", 1, 2, 'UTF-8'));

        $this->assertSame("\xE9j", iconv_substr("d\xE9j\xE0", 1, 2, 'ISO-8859-1'));
        $this->assertSame("\xE9j", iconv_substr("d\xE9j\xE0", -3, 2, 'iso-8859-1'));
        $this->assertSame("\xE9j", iconv_substr("d\xE9j\xE0", 1, -1, 'ISO-8859-1'));
        $this->assertSame("\x80", iconv_substr("d\xE9j\xE0 \x80", -1, 1, 'Windows-1252'));
        $this->assertSame("j\xE0 \x80", iconv_substr("d\xE9j\xE0 \x80", 2, 10, 'windows-1252'));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_substr
     *
     * @requires PHP 8
     */
    public function testIconvSubstrWithNullLength()
    {
        $this->assertSame('éjà', iconv_substr('déjà', 1));
        $this->assertSame('jà', iconv_substr('déjà', -2, null, 'UTF-8'));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_substr
     *
     * @requires PHP < 8
     */
    public function testIconvSubstrReturnsFalsePrePHP8()
    {
        $c = 'déjà';
        $this->assertFalse(iconv_substr($c, 42, 1, 'UTF-8'));
        $this->assertFalse(iconv_substr($c, -42, 1));
        $this->assertFalse(iconv_substr($c, 42, 26));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_substr
     *
     * @requires PHP < 8
     */
    public function testIconvSubstrWithNullLengthPrePHP8()
    {
        $this->assertSame('', iconv_substr('déjà', 1, null));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_substr
     *
     * @requires PHP 8
     */
    public function testIconvSubstrReturnsEmptyPostPHP8()
    {
        $c = 'déjà';
        $this->assertSame('', iconv_substr($c, 42, 1, 'UTF-8'));
        $this->assertSame('d', iconv_substr($c, -42, 1));
        $this->assertSame('', iconv_substr($c, 42, 26));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_mime_encode
     */
    public function testIconvMimeEncode()
    {
        $text = "\xE3\x83\x86\xE3\x82\xB9\xE3\x83\x88\xE3\x83\x86\xE3\x82\xB9\xE3\x83\x88";
        $options = [
            'scheme' => 'Q',
            'input-charset' => 'UTF-8',
            'output-charset' => 'UTF-8',
            'line-length' => 30,
        ];

        $this->assertSame(
            "Subject: =?UTF-8?Q?=E3=83=86?=\r\n =?UTF-8?Q?=E3=82=B9?=\r\n =?UTF-8?Q?=E3=83=88?=\r\n =?UTF-8?Q?=E3=83=86?=\r\n =?UTF-8?Q?=E3=82=B9?=\r\n =?UTF-8?Q?=E3=83=88?=",
            iconv_mime_encode('Subject', $text, $options)
        );
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_mime_decode
     */
    public function testIconvMimeDecode()
    {
        $this->assertSame('Legal encoded-word: * .', iconv_mime_decode('Legal encoded-word: =?utf-8?B?Kg==?= .'));
        $this->assertSame('Legal encoded-word: * .', iconv_mime_decode('Legal encoded-word: =?utf-8?Q?*?= .'));
        if ('\\' !== \DIRECTORY_SEPARATOR) {
            $this->assertSame('Illegal encoded-word:  .', iconv_mime_decode('Illegal encoded-word: =?utf-8?Q??= .', \ICONV_MIME_DECODE_CONTINUE_ON_ERROR));
            $this->assertSame('Illegal encoded-word: .', iconv_mime_decode('Illegal encoded-word: =?utf-8?Q?'.\chr(0xA1).'?= .', \ICONV_MIME_DECODE_CONTINUE_ON_ERROR));
        }
        $this->assertSame(\sprintf('Test: %s', 'проверка'), iconv_mime_decode('Test: =?windows-1251?B?7/Du4uXw6uA=?=', 0, 'UTF-8'));
        $this->assertSame(\sprintf('Test: %s', base64_decode('7/Du4uXw6uA=')), iconv_mime_decode('Test: =?windows-1251?B?7/Du4uXw6uA=?=', 0, 'windows-1251'));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_mime_decode
     */
    public function testIconvMimeDecodeIllegal()
    {
        iconv_mime_decode('Legal encoded-word: =?utf-8?Q?*?= .');
        $this->expectNotice();
        $this->expectNoticeMessage('Detected an illegal character in input string');
        iconv_mime_decode('Illegal encoded-word: =?utf-8?Q?'.\chr(0xA1).'?= .');
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_mime_decode_headers
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_mime_decode
     */
    public function testIconvMimeDecodeHeaders()
    {
        $headers = <<<HEADERS
From: =?UTF-8?B?PGZvb0BleGFtcGxlLmNvbT4=?=
Subject: =?ks_c_5601-1987?B?UkU6odk=?= Foo
X-Bar: =?cp949?B?UkU6odk=?= Foo
X-Bar: =?cp949?B?UkU6odk=?= =?UTF-8?Q?Bar?=
To: <test@example.com>
HEADERS;

        $result = [
            'From' => '<foo@example.com>',
            'Subject' => '=?ks_c_5601-1987?B?UkU6odk=?= Foo',
            'X-Bar' => [
                'RE:☆ Foo',
                'RE:☆Bar',
            ],
            'To' => '<test@example.com>',
        ];

        $this->assertSame($result, iconv_mime_decode_headers($headers, \ICONV_MIME_DECODE_CONTINUE_ON_ERROR, 'UTF-8'));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_get_encoding
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_set_encoding
     *
     * @group legacy
     */
    public function testIconvGetEncoding()
    {
        $a = [
            'input_encoding' => 'UTF-8',
            'output_encoding' => 'UTF-8',
            'internal_encoding' => 'UTF-8',
        ];

        foreach ($a as $t => $e) {
            $this->assertTrue(@iconv_set_encoding($t, $e));
            $this->assertSame($e, iconv_get_encoding($t));
        }

        $this->assertSame($a, iconv_get_encoding('all'));

        $this->assertFalse(@iconv_set_encoding('foo', 'UTF-8'));
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_mime_decode
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv_mime_decode_headers
     */
    public function testCharsetCannotLeaveTheMapDirectory()
    {
        // Lets the traversal resolve on a regular filesystem, as it does in a PHAR
        $dir = __DIR__.'/../../src/Iconv/Resources/charset/from.test';

        if (!is_dir($dir) && !@mkdir($dir)) {
            $this->markTestSkipped('Cannot create a directory next to the charset maps.');
        }

        try {
            foreach (['test/../from.windows-1252', 'test\..\from.windows-1252'] as $charset) {
                $this->assertFalse(@p::iconv($charset, 'UTF-8', "\x80"));
                $this->assertFalse(@p::iconv('UTF-8', $charset, '€'));
                $this->assertSame('', @p::iconv_mime_decode("=?{$charset}?Q?=80?="));
                $this->assertSame(['Subject' => "=?{$charset}?Q?=80?="], p::iconv_mime_decode_headers("Subject: =?{$charset}?Q?=80?=", \ICONV_MIME_DECODE_CONTINUE_ON_ERROR));
            }
        } finally {
            rmdir($dir);
        }
    }

    /**
     * @covers \Symfony\Polyfill\Iconv\Iconv::iconv
     */
    public function testShippedCharsetMapsLoad()
    {
        $this->assertNotEmpty($files = glob(__DIR__.'/../../src/Iconv/Resources/charset/from.*.php'));

        foreach ($files as $file) {
            $map = require $file;
            $charset = substr(basename($file, '.php'), 5);

            $this->assertSame(current($map), p::iconv($charset, 'UTF-8', (string) key($map)), $charset);
        }

        $this->assertSame('K', p::iconv('UTF-8', 'US-ASCII//TRANSLIT', "\u{212A}"));
    }
}
