<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Polyfill\Tests\Php85;

use PHPUnit\Framework\TestCase;

class Php85Test extends TestCase
{
    /**
     * @dataProvider provideHandler
     */
    public function testGetErrorHandler($expected, $handler)
    {
        set_error_handler($handler);
        try {
            $result = get_error_handler();
        } finally {
            restore_error_handler();
        }

        $this->assertSame($expected, $result);
    }

    public function testErrorStableReturnValue()
    {
        $this->assertSame(get_error_handler(), get_error_handler());
    }

    /**
     * @dataProvider provideHandler
     */
    public function testGetExceptionHandler($expected, $handler)
    {
        set_exception_handler($handler);
        try {
            $result = get_exception_handler();
        } finally {
            restore_exception_handler();
        }

        $this->assertSame($expected, $result);
    }

    public function testExceptionStableReturnValue()
    {
        $this->assertSame(get_exception_handler(), get_exception_handler());
    }

    public static function provideHandler()
    {
        // String handler
        yield ['var_dump', 'var_dump'];

        // Null handler
        yield [null, null];

        // Static method array handler
        yield [[TestHandler::class, 'handleStatic'], [TestHandler::class, 'handleStatic']];

        // Static method string handler
        yield ['Symfony\Polyfill\Tests\Php85\TestHandler::handleStatic', 'Symfony\Polyfill\Tests\Php85\TestHandler::handleStatic'];

        // Instance method array
        $handler = new TestHandler();
        yield [[$handler, 'handle'], [$handler, 'handle']];

        // Invokable object
        $handler = new TestHandlerInvokable();
        yield [$handler, $handler];
    }

    public function testArrayFirstArrayLast()
    {
        $this->assertNull(array_first([]));
        $this->assertNull(array_last([]));

        $array = [1, 2, 3];
        unset($array[0], $array[1], $array[2]);

        $this->assertNull(array_first([]));
        $this->assertNull(array_last([]));

        $this->assertSame('single element', array_first(['single element']));
        $this->assertSame('single element', array_last(['single element']));

        $str = 'hello world';
        $this->assertSame($str, array_first([&$str, 1]));
        $this->assertSame(1, array_last([&$str, 1]));

        $this->assertSame(1, array_first([1, &$str]));
        $this->assertSame($str, array_last([1, &$str]));

        $this->assertSame(1, array_first([1 => 1, 0 => 0, 3 => 3, 2 => 2]));
        $this->assertSame(2, array_last([1 => 1, 0 => 0, 3 => 3, 2 => 2]));

        $this->assertSame('a1', array_first(['a' => 'a1', 'b' => 'b1', 'c' => 'c1']));
        $this->assertSame('c1', array_last(['a' => 'a1', 'b' => 'b1', 'c' => 'c1']));

        $this->assertSame([], array_first([100 => []]));
        $this->assertSame([], array_last([100 => []]));

        $this->assertEquals(new \stdClass(), array_first([new \stdClass(), false]));
        $this->assertFalse(array_last([new \stdClass(), false]));

        $this->assertTrue(array_first([true, new \stdClass()]));
        $this->assertEquals(new \stdClass(), array_last([true, new \stdClass()]));
    }

    public function testFilterExceptionClassesExist()
    {
        $this->assertTrue(class_exists(\Filter\FilterException::class));
        $this->assertTrue(class_exists(\Filter\FilterFailedException::class));
    }

    /**
     * @requires extension intl
     */
    public function testLocaleIsRightToLeft()
    {
        $this->assertTrue(locale_is_right_to_left('ar'));
        $this->assertTrue(locale_is_right_to_left('he'));
        $this->assertTrue(locale_is_right_to_left('fa'));
        $this->assertTrue(locale_is_right_to_left('ur'));
        $this->assertTrue(locale_is_right_to_left('ps'));
        $this->assertTrue(locale_is_right_to_left('sd'));
        $this->assertTrue(locale_is_right_to_left('ug'));
        $this->assertTrue(locale_is_right_to_left('ckb'));
        $this->assertTrue(locale_is_right_to_left('yi'));
        $this->assertTrue(locale_is_right_to_left('dv'));
        $this->assertTrue(locale_is_right_to_left('nqo'));
        $this->assertTrue(locale_is_right_to_left('ks'));
        $this->assertTrue(locale_is_right_to_left('syr'));

        // Explicit RTL script subtag
        $this->assertTrue(locale_is_right_to_left('ku_Arab'));
        $this->assertTrue(locale_is_right_to_left('ku-arab'));
        $this->assertTrue(locale_is_right_to_left('ar-EG'));
        $this->assertTrue(locale_is_right_to_left('und-Hung'));

        // Explicit LTR script subtag overrides language default
        $this->assertFalse(locale_is_right_to_left('ar-Latn'));
        $this->assertFalse(locale_is_right_to_left('he-Latn'));

        // Only the subtag that follows the language can be a script
        $this->assertFalse(locale_is_right_to_left('en-US-Arab'));
        $this->assertFalse(locale_is_right_to_left('en-u-ca-hebr'));
        $this->assertFalse(locale_is_right_to_left('en-x-hebr'));
        $this->assertTrue(locale_is_right_to_left('ar-x-latn'));

        // Keywords and charsets are not subtags
        $this->assertTrue(locale_is_right_to_left('ar@calendar=islamic'));
        $this->assertTrue(locale_is_right_to_left('ar.UTF-8'));
        $this->assertFalse(locale_is_right_to_left('ar-Latn@calendar=gregorian'));

        // LTR locales
        $this->assertFalse(locale_is_right_to_left('en'));
        $this->assertFalse(locale_is_right_to_left('fr'));
        $this->assertFalse(locale_is_right_to_left('de'));
        $this->assertFalse(locale_is_right_to_left('zh'));
        $this->assertFalse(locale_is_right_to_left('ku'));
    }

    /**
     * @requires extension intl
     */
    public function testLocaleIsRightToLeftUsesDefaultLocaleWhenEmpty()
    {
        $default = \Locale::getDefault();

        try {
            \Locale::setDefault('ar');
            $this->assertTrue(locale_is_right_to_left(''));

            \Locale::setDefault('en');
            $this->assertFalse(locale_is_right_to_left(''));
        } finally {
            \Locale::setDefault($default);
        }
    }

    /**
     * @requires extension intl
     */
    public function testGraphemeLevenshtein()
    {
        $this->assertSame(3, grapheme_levenshtein('kitten', 'sitting'));
        $this->assertSame(1, grapheme_levenshtein('한국어', '한국'));
        $this->assertSame(10, grapheme_levenshtein('a', 'abc', 5, 2, 3));
        $this->assertSame(6, grapheme_levenshtein('abc', 'a', 5, 2, 3));
        $this->assertFalse(grapheme_levenshtein("\xFF", 'a'));
    }

    /**
     * @requires extension intl
     */
    public function testGraphemeLevenshteinCanonicalEquivalence()
    {
        $this->assertSame(0, grapheme_levenshtein('é', "e\u{0301}"));
        $this->assertSame(0, grapheme_levenshtein("\u{212B}", "\u{00C5}"));
        $this->assertSame(1, grapheme_levenshtein('café', "cafe\u{0301}s", 1, 1, 1, 'en'));
        $this->assertSame(1, grapheme_levenshtein('a', 'A'));
    }

    /**
     * @requires extension intl
     */
    public function testGraphemeLevenshteinInvalidLocale()
    {
        $this->assertFalse(grapheme_levenshtein('a', 'b', 1, 1, 1, 'defaaaaaaaaaaaaaaaaaaaaaaaaaaaa'));
        $this->assertSame(3, grapheme_levenshtein('', 'abc', 1, 1, 1, 'defaaaaaaaaaaaaaaaaaaaaaaaaaaaa'));
    }

    /**
     * @requires extension intl
     */
    public function testGraphemeLevenshteinNegativeCost()
    {
        $this->expectException(\ValueError::class);

        grapheme_levenshtein('a', 'b', -1);
    }

    /**
     * @requires extension intl
     */
    public function testGraphemeLevenshteinZeroCost()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('grapheme_levenshtein(): Argument #3 ($insertion_cost) must be greater than 0 and less than or equal to 1073741823');

        grapheme_levenshtein('a', 'b', 0);
    }

    /**
     * @requires extension intl
     */
    public function testGraphemeLevenshteinCostTooHigh()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('grapheme_levenshtein(): Argument #5 ($deletion_cost) must be greater than 0 and less than or equal to 1073741823');

        grapheme_levenshtein('a', 'b', 1, 1, 1073741824);
    }

    /**
     * @requires extension intl
     */
    public function testGraphemeLevenshteinInvalidCostAndInvalidUtf8()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('grapheme_levenshtein(): Argument #3 ($insertion_cost) must be greater than 0 and less than or equal to 1073741823');

        grapheme_levenshtein("\xFF", 'a', 0);
    }

    /**
     * @requires extension intl
     *
     * @group legacy
     */
    public function testGraphemeLevenshteinNullCost()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('grapheme_levenshtein(): Argument #4 ($replacement_cost) must be greater than 0 and less than or equal to 1073741823');

        @grapheme_levenshtein('a', 'b', 1, null);
    }
}

class TestHandler
{
    public static function handleStatic()
    {
    }

    public function handle()
    {
    }
}

class TestHandlerInvokable
{
    public function __invoke()
    {
    }
}
