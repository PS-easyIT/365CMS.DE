<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Polyfill\Tests\Uuid;

use PHPUnit\Framework\TestCase;
use Symfony\Bridge\PhpUnit\ClockMock;
use Symfony\Polyfill\Util\TestListenerTrait;
use Symfony\Polyfill\Uuid\Uuid;

class UuidTest extends TestCase
{
    public function testCreate()
    {
        $this->assertMatchesRegularExpression('{^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$}', uuid_create());
    }

    public function testCreateTime()
    {
        $this->assertMatchesRegularExpression('{^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$}', uuid_create(\UUID_TYPE_TIME));
    }

    public function testCreateWithInvalidType()
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_create(): Argument #1 ($uuid_type) Unknown/invalid UUID type \'99\'');
        }

        $this->assertMatchesRegularExpression('{^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$}', @uuid_create(99));
    }

    public function testCreateTimeV6()
    {
        $this->skipIfNativeCannotCreate(Uuid::UUID_TYPE_TIME_V6);

        $this->assertMatchesRegularExpression('{^[0-9a-f]{8}-[0-9a-f]{4}-6[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$}', $uuid = uuid_create(Uuid::UUID_TYPE_TIME_V6));
        $this->assertSame(Uuid::UUID_TYPE_TIME_V6, uuid_type($uuid));
    }

    public function testCreateTimeV7()
    {
        $this->skipIfNativeCannotCreate(Uuid::UUID_TYPE_TIME_V7);

        $before = floor(microtime(true) * 1000);
        $uuid = uuid_create(Uuid::UUID_TYPE_TIME_V7);
        $after = floor(microtime(true) * 1000);

        $this->assertMatchesRegularExpression('{^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$}', $uuid);
        $this->assertSame(Uuid::UUID_TYPE_TIME_V7, uuid_type($uuid));

        $time = hexdec(substr(str_replace('-', '', $uuid), 0, 12));
        $this->assertGreaterThanOrEqual($before, $time);
        $this->assertLessThanOrEqual($after, $time);
    }

    public function testGenerateMd5()
    {
        $uuidNs = uuid_create();

        $this->assertMatchesRegularExpression('{^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$}', $a = uuid_generate_md5($uuidNs, 'foo'));
        $this->assertMatchesRegularExpression('{^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$}', $b = uuid_generate_md5($uuidNs, 'bar'));
        $this->assertNotSame($a, $b);
        $this->assertSame(\UUID_TYPE_MD5, uuid_type($a));
        $this->assertSame(\UUID_TYPE_MD5, uuid_type($b));

        $this->assertSame('828658e4-5ae7-39fc-820b-d01a789b1a4d', uuid_generate_md5('ec07aa88-f84e-47b9-a581-1c6b30a2f484', 'the name'));
    }

    public function testGenerateMd5WithInvalidUuid()
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_generate_md5(): Argument #1 ($uuid_ns) UUID expected');
        }

        $this->assertFalse(@uuid_generate_md5('not a uuid', 'foo'));
    }

    public function testGenerateSha1()
    {
        $uuidNs = uuid_create();

        $this->assertMatchesRegularExpression('{^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$}', $a = uuid_generate_sha1($uuidNs, 'foo'));
        $this->assertMatchesRegularExpression('{^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$}', $b = uuid_generate_sha1($uuidNs, 'bar'));
        $this->assertNotSame($a, $b);
        $this->assertSame(\UUID_TYPE_SHA1, uuid_type($a));
        $this->assertSame(\UUID_TYPE_SHA1, uuid_type($b));

        if ('851def0c-b9c7-55aa-8991-130e769ec0a9' === uuid_generate_sha1('ec07aa88-f84e-47b9-a581-1c6b30a2f484', 'the name') && '851def0c-b9c7-55aa-8991-130e769ec0a9' === uuid_generate_sha1('ec07aa88-f84e-47b9-a581-1c6b30a2f484', 'the name')) {
            $this->markTestSkipped('Buggy libuuid.');
        }

        $this->assertSame('851def0c-b9c7-55aa-a991-130e769ec0a9', uuid_generate_sha1('ec07aa88-f84e-47b9-a581-1c6b30a2f484', 'the name'));
    }

    public function testGenerateSha1WithInvalidUuid()
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_generate_sha1(): Argument #1 ($uuid_ns) UUID expected');
        }

        $this->assertFalse(@uuid_generate_sha1('not a uuid', 'foo'));
    }

    public static function provideCreateNoOverlapTests(): array
    {
        return [
            [Uuid::UUID_TYPE_RANDOM],
            [Uuid::UUID_TYPE_TIME],
            [Uuid::UUID_TYPE_TIME_V6],
            [Uuid::UUID_TYPE_TIME_V7],
        ];
    }

    /** @dataProvider provideCreateNoOverlapTests */
    public function testCreateNoOverlap(int $type)
    {
        $this->skipIfNativeCannotCreate($type);

        $uuids = [];
        $count = 100000;
        for ($i = 0; $i < $count; ++$i) {
            $uuids[] = uuid_create($type);
        }

        $uuids = array_unique($uuids);

        $this->assertCount($count, $uuids);
    }

    public static function setUpBeforeClass(): void
    {
        // before any call to Uuid::uuid_create(), or its microtime() call site binds to the global one
        ClockMock::register(Uuid::class);
    }

    public static function provideCreateTimeNoOverlapWithinOneMicrosecondTests(): array
    {
        return [
            [Uuid::UUID_TYPE_TIME],
            [Uuid::UUID_TYPE_TIME_V6],
        ];
    }

    /**
     * @group time-sensitive
     *
     * @dataProvider provideCreateTimeNoOverlapWithinOneMicrosecondTests
     */
    public function testCreateTimeNoOverlapWithinOneMicrosecond(int $type)
    {
        ClockMock::withClockMock(1758000000.123456);

        try {
            $uuids = [];
            for ($i = 0; $i < 10000; ++$i) {
                $uuids[] = Uuid::uuid_create($type);
            }
        } finally {
            ClockMock::withClockMock(false);
        }

        $this->assertCount(10000, array_unique($uuids));

        $timestamps = array_map(function ($uuid) { return substr($uuid, 0, 18); }, $uuids);

        if (self::sharesTimestampThroughApcu()) {
            // the timestamp shared through APCu moves forward even when the clock does not
            $this->assertCount(10000, array_unique($timestamps));
        } else {
            // the clock did not move, so all of them share the timestamp and only the clock sequence varies
            $this->assertCount(1, array_unique($timestamps));
        }
    }

    /**
     * @group time-sensitive
     */
    public function testCreateTimeLayout()
    {
        ClockMock::withClockMock(1758000000.123456);

        try {
            // the timestamp shared through APCu would otherwise move forward from the last one used
            self::forgetSharedTimestamp();
            $v1 = Uuid::uuid_create(Uuid::UUID_TYPE_TIME);
            self::forgetSharedTimestamp();
            $v6 = Uuid::uuid_create(Uuid::UUID_TYPE_TIME_V6);
            $v7 = Uuid::uuid_create(Uuid::UUID_TYPE_TIME_V7);
        } finally {
            ClockMock::withClockMock(false);
        }

        // libuuid generates the same timestamp fields at that time
        $this->assertStringStartsWith('cabad680-92bc-11f0-', $v1);
        $this->assertStringStartsWith('1f092bcc-abad-6680-', $v6);
        $this->assertStringStartsWith('019950f7-2c7b-7', $v7);
    }

    /**
     * @group time-sensitive
     *
     * @dataProvider provideCreateTimeNoOverlapWithinOneMicrosecondTests
     */
    public function testCreateTimeFollowsTheTimestampSharedThroughApcu(int $type)
    {
        if (!self::sharesTimestampThroughApcu()) {
            $this->markTestSkipped('The timestamp is shared through APCu only when APCu is enabled on 64-bit PHP.');
        }

        // another process that shares the node already used a timestamp one second ahead of the clock
        $shared = 17580000001234560 + Uuid::TIME_OFFSET_INT + 10000000;
        apcu_store('__symfony_uuid_time', $shared);
        ClockMock::withClockMock(1758000000.123456);

        try {
            $uuid = Uuid::uuid_create($type);
        } finally {
            ClockMock::withClockMock(false);
        }

        if (Uuid::UUID_TYPE_TIME === $type) {
            $time = substr($uuid, 15, 3).substr($uuid, 9, 4).substr($uuid, 0, 8);
        } else {
            $time = substr($uuid, 0, 8).substr($uuid, 9, 4).substr($uuid, 15, 3);
        }

        $this->assertSame($shared + 1, hexdec($time));
        $this->assertSame($shared + 1, apcu_fetch('__symfony_uuid_time'));
    }

    public static function provideIsValidTest(): array
    {
        return [
            [true, '00000000-0000-0000-0000-000000000000'],
            [true, 'fa83b381-328c-46b8-8c90-4e9ba47dfa4b'],
            [true, 'FA83B381-328C-46B8-8C90-4E9BA47DFA4B'],
            [false, 'fa83b381-328c-ZZZZ-8c90-4e9ba47dfa4b'],
            [false, 'fa83b381328c46b88c904e9ba47dfa4b'],
            [false, 'foobar'],
        ];
    }

    /** @dataProvider provideIsValidTest */
    public function testIsValid(bool $expected, string $uuid)
    {
        $this->assertSame($expected, uuid_is_valid($uuid));
    }

    public static function provideCompareTest(): array
    {
        return [
            [-1, 'fa83b381-328c-46b8-8c90-4e9ba47dfa4b', 'fa83b381-328c-46b8-8c90-4e9ba47dfa4c'],
            [0, 'fa83b381-328c-46b8-8c90-4e9ba47dfa4b', 'fa83b381-328c-46b8-8c90-4e9ba47dfa4b'],
            [1, 'fa83b381-328c-46b8-8c90-4e9ba47dfa4d', 'fa83b381-328c-46b8-8c90-4e9ba47dfa4c'],
        ];
    }

    /** @dataProvider provideCompareTest */
    public function testCompare(int $expected, string $uuid1, string $uuid2)
    {
        $result = @uuid_compare($uuid1, $uuid2);

        // When only the node differs, native returns the memcmp() result of the libc, which is not limited to -1 and 1
        if (0 !== $result) {
            $result /= abs($result);
        }

        $this->assertSame($expected, $result);
    }

    public function testCompareTimeFields()
    {
        $this->assertSame(-1, uuid_compare('00000000-0000-0000-0000-000000000000', 'ffffffff-ffff-ffff-ffff-ffffffffffff'));
        $this->assertSame(1, uuid_compare('6ba7b810-9dad-11d1-80b4-00c04fd430c8', '1ee9c9a6-2b52-6e1c-8d2a-0242ac120002'));
        $this->assertSame(0, uuid_compare('6BA7B810-9DAD-11D1-80B4-00C04FD430C8', '6ba7b810-9dad-11d1-80b4-00c04fd430c8'));
    }

    public function testCompareWithInvalidUuidLeft()
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_compare(): Argument #1 ($uuid1) UUID expected');
        }

        $this->assertFalse(@uuid_compare('foobar', 'fa83b381-328c-46b8-8c90-4e9ba47dfa4b'));
    }

    public function testCompareWithInvalidUuidRight()
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_compare(): Argument #2 ($uuid2) UUID expected');
        }

        $this->assertFalse(@uuid_compare('fa83b381-328c-46b8-8c90-4e9ba47dfa4b', 'foobar'));
    }

    public static function provideIsNullTest(): array
    {
        return [
            [true, '00000000-0000-0000-0000-000000000000'],
            [false, '00000000-0000-0000-0000-000000000001'],
            [false, 'fa83b381-328c-46b8-8c90-4e9ba47dfa4b'],
        ];
    }

    /** @dataProvider provideIsNullTest */
    public function testIsNull(bool $expected, string $uuid)
    {
        $this->assertSame($expected, @uuid_is_null($uuid));
    }

    public function testIsNullWithInvalidUuid()
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_is_null(): Argument #1 ($uuid) UUID expected');
        }

        $this->assertFalse(@uuid_is_null('foobar'));
    }

    public static function provideTypeTest(): array
    {
        return [
            [Uuid::UUID_TYPE_NULL, '00000000-0000-0000-0000-000000000000'],
            [Uuid::UUID_TYPE_RANDOM, 'fa83b381-328c-46b8-8c90-4e9ba47dfa4b'],
            [Uuid::UUID_TYPE_TIME, 'dbc6260f-e9cc-11e9-8dac-9cb6d0897f07'],
            [Uuid::UUID_TYPE_TIME, '6fec1e70-fb1f-11e9-81dc-b52d3e41ad26'],
            [Uuid::UUID_TYPE_SECURITY, '000003e8-cbb9-21ea-b201-00045a86c8a1'],
            [Uuid::UUID_TYPE_TIME_V6, '1ee9c9a6-2b52-6e1c-8d2a-0242ac120002'],
            [Uuid::UUID_TYPE_TIME_V7, '01890a5d-ac96-774b-bcce-b302099a8057'],
            [Uuid::UUID_TYPE_VENDOR, '01890a5d-ac96-874b-bcce-b302099a8057'],
        ];
    }

    /** @dataProvider provideTypeTest */
    public function testType(int $expected, string $uuid)
    {
        $this->assertSame($expected, @uuid_type($uuid));
    }

    public function testTypeSecurity()
    {
        $this->assertSame(\UUID_TYPE_SECURITY, uuid_type('000003e8-cbb9-21ea-b201-00045a86c8a1'));
    }

    public function testTypeWithInvalidUuid()
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_type(): Argument #1 ($uuid) UUID expected');
        }

        $this->assertFalse(@uuid_type('foobar'));
    }

    public static function provideVariantTest(): array
    {
        return [
            [Uuid::UUID_TYPE_NULL, '00000000-0000-0000-0000-000000000000'],
            [Uuid::UUID_VARIANT_DCE, 'fa83b381-328c-46b8-8c90-4e9ba47dfa4b'],
            [Uuid::UUID_VARIANT_DCE, '6fec1e70-fb1f-11e9-81dc-b52d3e41ad26'],
        ];
    }

    /** @dataProvider provideVariantTest */
    public function testVariant(int $expected, string $uuid)
    {
        $this->assertSame($expected, @uuid_variant($uuid));
    }

    public function testVariantWithInvalidUuid()
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_variant(): Argument #1 ($uuid) UUID expected');
        }

        $this->assertFalse(@uuid_variant('foobar'));
    }

    public static function provideTimeTest(): array
    {
        return [
            [1572444805, '6fec1e70-fb1f-11e9-81dc-b52d3e41ad26'],
            [1572445677, '77ffc38a-fb21-11e9-b46a-3c7de2fa99cb'],
        ];
    }

    /** @dataProvider provideTimeTest */
    public function testTime(int $expected, string $uuid)
    {
        $this->assertSame($expected, @uuid_time($uuid));
    }

    public function testTimeBeforeUnixEpoch()
    {
        if (\PHP_INT_SIZE < 8) {
            $this->markTestSkipped('Timestamps before the Unix epoch need 64-bit integers.');
        }
        if (\extension_loaded('uuid') && 0 < \uuid_time('00000000-0000-1000-8000-000000000000')) {
            $this->markTestSkipped('libuuid < 2.42 wraps timestamps before the Unix epoch.');
        }

        $this->assertSame(-12219292800, uuid_time('00000000-0000-1000-8000-000000000000'));
        $this->assertSame(-6254595519, uuid_time('123e4567-e89b-10d3-a456-426614174000'));
        $this->assertSame(-1, uuid_time('12e8a980-1dd2-11b2-8000-000000000000'));
        $this->assertSame(0, uuid_time('13813fff-1dd2-11b2-8000-000000000000'));
    }

    public static function provideInvalidTimeTest(): array
    {
        return [
            ['foobar'],
            ['00000000-0000-0000-0000-000000000000'],
            ['fa83b381-328c-46b8-8c90-4e9ba47dfa4b'],
            ['123e4567-e89b-12d3-4a56-426614174000'],
            ['123e4567-e89b-12d3-c456-426614174000'],
            ['123e4567-e89b-12d3-e456-426614174000'],
            ['1ee9c9a6-2b52-6e1c-8d2a-0242ac120002'],
            ['01890a5d-ac96-774b-bcce-b302099a8057'],
            ['01890a5d-ac96-874b-bcce-b302099a8057'],
        ];
    }

    /**
     * @dataProvider provideInvalidTimeTest
     */
    public function testTimeWithInvalidUuid(string $uuid)
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_time(): Argument #1 ($uuid) UUID DCE TIME expected');
        }

        $this->assertFalse(@uuid_time($uuid));
    }

    public static function provideMacTest(): array
    {
        return [
            ['b52d3e41ad26', '6fec1e70-fb1f-11e9-81dc-b52d3e41ad26'],
            ['3c7de2fa99cb', '77ffc38a-fb21-11e9-b46a-3c7de2fa99CB'],
        ];
    }

    /** @dataProvider provideMacTest */
    public function testMac(string $expected, string $uuid)
    {
        $this->assertSame($expected, @uuid_mac($uuid));
    }

    public static function provideInvalidMacTest(): array
    {
        return [
            ['foobar'],
            ['00000000-0000-0000-0000-000000000000'],
            ['fa83b381-328c-46b8-8c90-4e9ba47dfa4b'],
            ['123e4567-e89b-12d3-4a56-426614174000'],
            ['123e4567-e89b-12d3-c456-426614174000'],
            ['123e4567-e89b-12d3-e456-426614174000'],
            ['1ee9c9a6-2b52-6e1c-8d2a-0242ac120002'],
            ['01890a5d-ac96-774b-bcce-b302099a8057'],
            ['01890a5d-ac96-874b-bcce-b302099a8057'],
        ];
    }

    /**
     * @dataProvider provideInvalidMacTest
     */
    public function testMacWithInvalidUuid(string $uuid)
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_mac(): Argument #1 ($uuid) UUID DCE TIME expected');
        }

        $this->assertFalse(@uuid_mac($uuid));
    }

    public static function provideParseTest(): array
    {
        return [
            ['00000000000000000000000000000000', '00000000-0000-0000-0000-000000000000'],
            ['fa83b381328c46b88c904e9ba47dfa4b', 'fa83b381-328c-46b8-8c90-4e9ba47dfa4b'],
            ['77ffc38afb2111e9b46a3c7de2fa99cb', '77ffc38a-fb21-11e9-b46a-3c7de2fa99cb'],
        ];
    }

    /** @dataProvider provideParseTest */
    public function testParse(string $expected, string $uuid)
    {
        $out = bin2hex(@uuid_parse($uuid));

        $this->assertSame($expected, $out);
    }

    public function testParseWithInvalidUuid()
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_parse(): Argument #1 ($uuid) UUID expected');
        }

        $this->assertFalse(@uuid_parse('foobar'));
    }

    public static function provideUnparseTest(): array
    {
        return [
            ['00000000-0000-0000-0000-000000000000', pack('H*', '00000000000000000000000000000000')],
            ['fa83b381-328c-46b8-8c90-4e9ba47dfa4b', pack('H*', 'fa83b381328c46b88c904e9ba47dfa4b')],
            ['77ffc38a-fb21-11e9-b46a-3c7de2fa99cb', pack('H*', '77ffc38afb2111e9b46a3c7de2fa99cb')],
        ];
    }

    /** @dataProvider provideUnparseTest */
    public function testUnparse(string $expected, string $uuid)
    {
        $this->assertSame($expected, @uuid_unparse($uuid));
    }

    public static function provideInvalidUnparseTest(): array
    {
        return [
            ['foobar'],
            [pack('h*', '46b8')],
        ];
    }

    /**
     * @dataProvider provideInvalidUnparseTest
     */
    public function testUnparseWithInvalidUuid(string $uuid)
    {
        if (80000 <= \PHP_VERSION_ID) {
            $this->expectException(\ValueError::class);
            $this->expectExceptionMessage('uuid_unparse(): Argument #1 ($uuid) UUID expected');
        }

        $this->assertFalse(@uuid_unparse($uuid));
    }

    public function testDeprecatedTypeDce()
    {
        $this->assertSame(4, $this->captureDeprecation(static function() { return \UUID_TYPE_DCE; }, 'UUID_TYPE_DCE'));
    }

    public function testDeprecatedTypeName()
    {
        $this->assertSame(1, $this->captureDeprecation(static function() { return \UUID_TYPE_NAME; }, 'UUID_TYPE_NAME'));
    }

    private function captureDeprecation(\Closure $access, string $name)
    {
        if (\PHP_VERSION_ID < 80500) {
            $this->markTestSkipped('The Deprecated attribute applies to global constants since PHP 8.5.');
        }
        if (extension_loaded('uuid')) {
            $this->markTestSkipped('ext-uuid is loaded, the polyfill is not in use.');
        }

        $deprecation = null;
        set_error_handler(static function ($type, $message) use (&$deprecation) {
            $deprecation = $message;

            return true;
        }, \E_USER_DEPRECATED | \E_DEPRECATED);

        try {
            $value = $access();
        } finally {
            restore_error_handler();
        }

        $this->assertNotNull($deprecation, sprintf('Using %s should trigger a deprecation.', $name));
        $this->assertStringContainsString($name, $deprecation);

        return $value;
    }

    private function skipIfNativeCannotCreate(int $type): void
    {
        if (TestListenerTrait::$enabledPolyfills || !\extension_loaded('uuid')) {
            return;
        }

        // The extension creates v6 and v7 UUIDs only when built against util-linux >= 2.41
        try {
            $supported = $type === uuid_type(@uuid_create($type));
        } catch (\ValueError $e) {
            $supported = false;
        }

        if (!$supported) {
            $this->markTestSkipped(\sprintf('The uuid extension cannot create UUIDs of type %d.', $type));
        }
    }

    private static function sharesTimestampThroughApcu(): bool
    {
        return \PHP_INT_SIZE >= 8 && \function_exists('apcu_enabled') && apcu_enabled();
    }

    private static function forgetSharedTimestamp(): void
    {
        if (self::sharesTimestampThroughApcu()) {
            apcu_delete('__symfony_uuid_time');
        }
    }
}
