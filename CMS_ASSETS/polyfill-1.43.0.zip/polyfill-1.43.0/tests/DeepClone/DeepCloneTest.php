<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Polyfill\Tests\DeepClone;

use PHPUnit\Framework\TestCase;
use Symfony\Polyfill\Util\TestListenerTrait;

if (\PHP_VERSION_ID >= 80100) {
    require __DIR__.'/fixtures.php';
}
if (\PHP_VERSION_ID >= 80500) {
    require __DIR__.'/fixtures85.php';
}

/**
 * @requires PHP 8.1
 */
class DeepCloneTest extends TestCase
{
    public function testToArrayIntIsStatic()
    {
        $this->assertSame(['value' => 42], deepclone_to_array(42));
    }

    public function testToArrayStringIsStatic()
    {
        $this->assertSame(['value' => 'hello'], deepclone_to_array('hello'));
    }

    public function testToArrayTrueIsStatic()
    {
        $this->assertSame(['value' => true], deepclone_to_array(true));
    }

    public function testToArrayFalseIsStatic()
    {
        $this->assertSame(['value' => false], deepclone_to_array(false));
    }

    public function testToArrayNullIsStatic()
    {
        $this->assertSame(['value' => null], deepclone_to_array(null));
    }

    public function testToArrayFloatIsStatic()
    {
        $this->assertSame(['value' => 3.14], deepclone_to_array(3.14));
    }

    public function testToArrayEmptyArrayIsStatic()
    {
        $this->assertSame(['value' => []], deepclone_to_array([]));
    }

    public function testToArraySimpleStdClassWireFormat()
    {
        $o = new \stdClass();
        $o->foo = 'bar';
        $o->num = 42;
        $d = deepclone_to_array($o);

        $this->assertSame('stdClass', $d['classes']);
        $this->assertSame(1, $d['objectMeta']);
        $this->assertSame(0, $d['prepared']);
        $this->assertSame([0 => 'bar'], $d['properties']['stdClass']['foo']);
        $this->assertSame([0 => 42], $d['properties']['stdClass']['num']);
    }

    public function testToArrayNestedObjectsWireFormat()
    {
        $o = new \stdClass();
        $o->child = new \stdClass();
        $o->child->val = 'inner';
        $d = deepclone_to_array($o);

        $this->assertSame(2, $d['objectMeta']);
        $this->assertSame([1 => 'inner'], $d['properties']['stdClass']['val']);
        $this->assertSame([0 => true], $d['resolve']['stdClass']['child']);
    }

    public function testToArraySharedObjectReferenceWireFormat()
    {
        $child = new \stdClass();
        $child->x = 1;
        $o = new \stdClass();
        $o->a = $child;
        $o->b = $child;
        $d = deepclone_to_array($o);

        $this->assertSame($d['properties']['stdClass']['a'][0], $d['properties']['stdClass']['b'][0]);
    }

    public function testToArrayCircularReferenceWireFormat()
    {
        $a = new \stdClass();
        $b = new \stdClass();
        $a->ref = $b;
        $b->ref = $a;
        $d = deepclone_to_array($a);

        $this->assertSame(2, $d['objectMeta']);
        $this->assertTrue($d['resolve']['stdClass']['ref'][0]);
        $this->assertTrue($d['resolve']['stdClass']['ref'][1]);
    }

    public function testToArrayScalarHardRefsWireFormat()
    {
        $v = [1];
        $v[] = &$v[0];
        $d = deepclone_to_array($v);

        $this->assertSame([-1, -1], $d['prepared']);
        $this->assertSame([false, false], $d['mask']);
        $this->assertArrayHasKey(1, $d['refs']);
    }

    public function testToArrayRecursiveHardRefWireFormat()
    {
        $v = [];
        $v[0] = &$v;
        $d = deepclone_to_array($v);

        $this->assertSame([-1], $d['prepared']);
        $this->assertSame([false], $d['mask']);
        $this->assertArrayHasKey(1, $d['refs']);
        $this->assertArrayHasKey(1, $d['refMasks']);
    }

    public function testToArrayUnsharedReferenceBecomesStatic()
    {
        $x = [123];
        $d = deepclone_to_array([&$x]);

        $this->assertArrayHasKey('value', $d);
        $this->assertSame([[123]], $d['value']);
    }

    public function testToArrayNamedClosureGlobalFunctionWireFormat()
    {
        $d = deepclone_to_array(\Closure::fromCallable('strlen'), null, true);

        $this->assertSame([null, 'strlen'], $d['prepared']);
        $this->assertSame(0, $d['mask']);
    }

    public function testToArrayLargeStringCowPreservation()
    {
        $big = str_repeat('x', 10000);
        $o = new \stdClass();
        $o->data = $big;
        $d = deepclone_to_array($o);

        $this->assertSame($big, $d['properties']['stdClass']['data'][0]);
    }

    public function testFromArrayScalarInt()
    {
        $this->assertSame(42, deepclone_from_array(['value' => 42]));
    }

    public function testFromArrayScalarString()
    {
        $this->assertSame('hello', deepclone_from_array(['value' => 'hello']));
    }

    public function testFromArrayScalarNull()
    {
        $this->assertNull(deepclone_from_array(['value' => null]));
    }

    public function testFromArrayScalarBool()
    {
        $this->assertTrue(deepclone_from_array(['value' => true]));
    }

    public function testFromArrayScalarArray()
    {
        $this->assertSame([1, 2], deepclone_from_array(['value' => [1, 2]]));
    }

    public function testRoundTripSimpleStdClass()
    {
        $o = new \stdClass();
        $o->foo = 'bar';
        $o->num = 42;
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertInstanceOf(\stdClass::class, $clone);
        $this->assertSame('bar', $clone->foo);
        $this->assertSame(42, $clone->num);
        $this->assertNotSame($o, $clone);
    }

    public function testRoundTripNestedObjects()
    {
        $o = new \stdClass();
        $o->child = new \stdClass();
        $o->child->val = 'inner';
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertInstanceOf(\stdClass::class, $clone->child);
        $this->assertSame('inner', $clone->child->val);
        $this->assertNotSame($o->child, $clone->child);
    }

    public function testRoundTripObjectsInArrayProperty()
    {
        $o = new DeepCloneRefHolder();
        $o->a = [new \stdClass(), 'k' => [new DeepCloneRefHolder()]];
        $o->a[] = $o->a[0];
        $o->b = 'b';
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertInstanceOf(\stdClass::class, $clone->a[0]);
        $this->assertNotSame($o->a[0], $clone->a[0]);
        $this->assertSame($clone->a[0], $clone->a[1]);
        $this->assertInstanceOf(DeepCloneRefHolder::class, $clone->a['k'][0]);
        $this->assertSame('b', $clone->b);
    }

    public function testRoundTripSharedObjectReference()
    {
        $child = new \stdClass();
        $child->x = 1;
        $o = new \stdClass();
        $o->a = $child;
        $o->b = $child;
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertSame($clone->a, $clone->b);
        $this->assertNotSame($child, $clone->a);
        $this->assertSame(1, $clone->a->x);
    }

    public function testRoundTripCircularReference()
    {
        $a = new \stdClass();
        $b = new \stdClass();
        $a->ref = $b;
        $b->ref = $a;
        $clone = deepclone_from_array(deepclone_to_array($a));

        $this->assertSame($clone, $clone->ref->ref);
    }

    public function testRoundTripScalarHardReference()
    {
        $v = [1];
        $v[] = &$v[0];
        $clone = deepclone_from_array(deepclone_to_array($v));

        $this->assertSame(1, $clone[0]);
        $clone[0] = 999;
        $this->assertSame(999, $clone[1]);
    }

    public function testRoundTripRecursiveHardReference()
    {
        $v = [];
        $v[0] = &$v;
        $clone = deepclone_from_array(deepclone_to_array($v));

        $this->assertSame($clone, $clone[0]);
    }

    public function testRoundTripHardReferencesNextToObjects()
    {
        // Shared reference to an array of objects
        $x = [new \stdClass()];
        $clone = deepclone_from_array(deepclone_to_array([&$x, &$x]));
        $this->assertInstanceOf(\stdClass::class, $clone[0][0]);
        $this->assertNotSame($x[0], $clone[0][0]);
        $clone[0] = 'replaced';
        $this->assertSame('replaced', $clone[1]);

        // Unshared reference to an object: exported as its id, then cloned
        $y = new \stdClass();
        $data = deepclone_to_array([&$y, 1]);
        $this->assertSame([0, 1], $data['prepared']);
        $this->assertNotSame($y, deepclone_from_array($data)[0]);

        // Nested references next to objects
        $z = 1;
        $clone = deepclone_from_array(deepclone_to_array(['k' => [&$z], 'o' => new \stdClass()]));
        $this->assertSame([1], $clone['k']);

        $w = 1;
        $clone = deepclone_from_array(deepclone_to_array(['k' => [&$w, &$w, new \stdClass()]]));
        $this->assertInstanceOf(\stdClass::class, $clone['k'][2]);
        $clone['k'][0] = 42;
        $this->assertSame(42, $clone['k'][1]);

        // Shared reference holding null
        $v = [null];
        $v[] = &$v[0];
        $clone = deepclone_from_array(deepclone_to_array($v));
        $clone[0] = 42;
        $this->assertSame(42, $clone[1]);
    }

    public function testRoundTripNestedHardReferencesInPropertiesAndStates()
    {
        $x = 1;
        $o = new DeepCloneRefHolder();
        $o->a = [&$x, new \stdClass()];
        $clone = deepclone_from_array(deepclone_to_array($o));
        $this->assertSame(1, $clone->a[0]);
        $this->assertInstanceOf(\stdClass::class, $clone->a[1]);

        $o = new DeepCloneRefHolder();
        $o->a = [1, new \stdClass()];
        $o->a[] = &$o->a[0];
        $clone = deepclone_from_array(deepclone_to_array($o));
        $this->assertInstanceOf(\stdClass::class, $clone->a[1]);
        $clone->a[0] = 42;
        $this->assertSame(42, $clone->a[2]);

        $y = 1;
        $s = new DeepCloneStateRefs();
        $s->data = ['k' => [&$y, new \stdClass()]];
        $clone = deepclone_from_array(deepclone_to_array($s));
        $this->assertSame(1, $clone->data['k'][0]);
        $this->assertInstanceOf(\stdClass::class, $clone->data['k'][1]);
    }

    public function testRoundTripPropertyHardReferences()
    {
        $this->skipIfExtensionDropsPropertyReferences();

        // Between declared properties, also once the property table is built
        $o = new DeepCloneRefHolder();
        $o->a = 1;
        $o->b = &$o->a;
        $clone = deepclone_from_array(deepclone_to_array($o));
        $clone->a = 42;
        $this->assertSame(42, $clone->b);

        foreach ($o as $v) {
        }
        $clone = deepclone_from_array(deepclone_to_array($o));
        $clone->a = 42;
        $this->assertSame(42, $clone->b);

        // Also when the properties hold their default value
        $o = new DeepCloneRefHolder();
        $o->b = &$o->a;
        $clone = deepclone_from_array(deepclone_to_array($o));
        $clone->a = 42;
        $this->assertSame(42, $clone->b);

        // Between a parent's private property and a child's public one
        $o = new DeepCloneRefChild();
        $o->bind();
        $clone = deepclone_from_array(deepclone_to_array($o));
        $clone->q = 42;
        $this->assertSame(42, $clone->getP());

        // Across objects and with array elements, holding an object
        $o1 = new DeepCloneRefHolder();
        $o2 = new DeepCloneRefHolder();
        $o2->b = new \stdClass();
        $o1->a = &$o2->b;
        $arr = [&$o2->b];
        [$c1, $c2, $carr] = deepclone_from_array(deepclone_to_array([$o1, $o2, $arr]));
        $this->assertSame($c2->b, $c1->a);
        $c1->a = 'replaced';
        $this->assertSame('replaced', $c2->b);
        $this->assertSame('replaced', $carr[0]);

        // With __sleep()
        $o = new DeepCloneSleepRefs();
        $o->y = &$o->x;
        $clone = deepclone_from_array(deepclone_to_array($o));
        $clone->x = 42;
        $this->assertSame(42, $clone->y);

        // Bound to a variable outside the graph, a property gets a plain value
        $o = new DeepCloneRefHolder();
        $o->a = 1;
        $x = &$o->a;
        $o->other = [str_repeat('x', 3)];
        $data = deepclone_to_array($o);
        $this->assertSame([1], $data['properties']['stdClass']['a']);
        $this->assertArrayNotHasKey('refs', $data);
        $this->assertSame(1, deepclone_from_array($data)->a);
    }

    public function testRoundTripTypedPropertyHardReferences()
    {
        $this->skipIfExtensionDropsPropertyReferences();

        $o = new DeepCloneTypedRefs();
        $o->b = &$o->a;
        $arr = [&$o->a];
        [$clone, $carr] = deepclone_from_array(deepclone_to_array([$o, $arr]));

        $clone->a = 5;
        $this->assertSame(5, $clone->b);
        $this->assertSame(5, $carr[0]);

        // The reference keeps being type-checked
        try {
            $carr[0] = 'x';
            $this->fail('TypeError expected');
        } catch (\TypeError $e) {
            $this->assertSame(5, $clone->a);
        }

        $this->assertSame(1, $o->a);
    }

    public function testRoundTripDynamicPropertyHardReferences()
    {
        $this->skipIfExtensionDropsPropertyReferences();

        $o = new DeepCloneDynamicRefs();
        $o->a = 1;
        $o->b = &$o->a;
        $o->declared = 2;
        $o->c = &$o->declared;
        $clone = deepclone_from_array(deepclone_to_array($o));
        $clone->a = 42;
        $clone->declared = 43;
        $this->assertSame(42, $clone->b);
        $this->assertSame(43, $clone->c);

        $o = new \stdClass();
        $o->{'1'} = 1;
        $o->{'2'} = &$o->{'1'};
        $clone = deepclone_from_array(deepclone_to_array($o));
        $clone->{'1'} = 42;
        $this->assertSame(42, $clone->{'2'});

        // On a closure-bearing node, which the extension creates as a lazy ghost
        $o = new DeepCloneDynamicRefs();
        $o->cb = \Closure::fromCallable('strlen');
        $o->a = 1;
        $o->b = &$o->a;
        $clone = deepclone_from_array(deepclone_to_array($o, null, true), null, true);
        $clone->a = 42;
        $this->assertSame(42, $clone->b);
        $this->assertSame(3, ($clone->cb)('abc'));
    }

    public function testCodeRunByToArrayReadsTheValuesOfHardReferences()
    {
        $x = 1;
        $o = new DeepCloneSerializeReadingRefs();
        $o->x = &$x;
        [, $clone] = deepclone_from_array(deepclone_to_array([[&$x], $o]));
        $this->assertSame(1, $clone->x);

        // Also after meeting the reference of a typed property, which rejects markers
        $x = 1;
        $t = new DeepCloneTypedRefs();
        $o = new DeepCloneSerializeReadingRefs();
        $o->x = &$x;
        [, , $clone] = deepclone_from_array(deepclone_to_array([[&$x], [&$t->a], $o]));
        $this->assertSame(1, $clone->x);

        $x = 1;
        $o = new DeepCloneSleepReadingRefs();
        $o->x = &$x;
        deepclone_to_array([[&$x], $o]);
        $this->assertSame(1, $o->y);

        // Values written by that code stay, like with serialize()
        $x = 1;
        $o = new DeepCloneSleepReadingRefs();
        $o->y = &$x;
        $o->x = 2;
        deepclone_to_array([[&$x], $o]);
        $this->assertSame(2, $x);

        // References met before keep the value they had then in the payload, like with serialize()
        $x = 1;
        $o = new DeepCloneSleepReadingRefs();
        $o->y = &$x;
        $o->z = &$x;
        $o->x = 2;
        [$arr, $clone] = deepclone_from_array(deepclone_to_array([[&$x], $o]));
        $this->assertSame(2, $x);
        $this->assertSame([1], $arr);
        $this->assertSame(1, $clone->z);
        $arr[0] = 3;
        $this->assertSame(3, $clone->z);

        if (\PHP_VERSION_ID >= 80400) {
            $x = 1;
            $ghost = (new \ReflectionClass(DeepCloneRefHolder::class))->newLazyGhost(static function (DeepCloneRefHolder $o) use (&$x) {
                $o->a = $x;
            });
            [, $clone] = deepclone_from_array(deepclone_to_array([[&$x], $ghost]));
            $this->assertSame(1, $clone->a);
            $this->assertSame(1, $ghost->a);

            // The real instance of an initialized lazy proxy can have been reset as lazy since
            $x = 1;
            $r = new \ReflectionClass(DeepCloneRefHolder::class);
            $real = new DeepCloneRefHolder();
            $proxy = $r->newLazyProxy(static function () use ($real) {
                return $real;
            });
            $r->initializeLazyObject($proxy);
            $r->resetAsLazyGhost($real, static function (DeepCloneRefHolder $o) use (&$x) {
                $o->a = $x;
            });
            [, $clone] = deepclone_from_array(deepclone_to_array([[&$x], $proxy]));
            $this->assertSame(1, $clone->a);
            $this->assertSame(1, $real->a);
        }
    }

    /**
     * @group legacy
     */
    public function testSerializableReadsTheValuesOfHardReferences()
    {
        if (!class_exists(DeepCloneSerializableReadingRefs::class, false)) {
            eval('namespace '.__NAMESPACE__.'; class DeepCloneSerializableReadingRefs implements \\Serializable { public $x; public function serialize(): string { return serialize($this->x); } public function unserialize($data): void { $this->x = unserialize($data); } }');
        }

        $x = 1;
        $o = new DeepCloneSerializableReadingRefs();
        $o->x = [&$x];
        [, $clone] = deepclone_from_array(deepclone_to_array([[&$x], $o]));
        $this->assertSame([1], $clone->x);
    }

    public function testFromArrayBindsHardReferencesToDynamicProperties()
    {
        $this->skipIfExtensionDropsPropertyReferences();

        $payload = [
            'classes' => DeepCloneNoDynamicAttributeRefs::class,
            'objectMeta' => 1,
            'prepared' => 0,
            'properties' => ['stdClass' => ['a' => [0 => -1], 'b' => [0 => -1]]],
            'resolve' => ['stdClass' => ['a' => [0 => false], 'b' => [0 => false]]],
            'refs' => [1 => 3],
        ];

        // The origin reported the creation of these dynamic properties already
        set_error_handler(static function ($type, $message) {
            if (error_reporting() & $type) {
                throw new \ErrorException($message, 0, $type);
            }

            return false;
        });
        try {
            $o = deepclone_from_array($payload);
        } finally {
            restore_error_handler();
        }
        $o->a = 42;
        $this->assertSame(42, $o->b);

        if (\PHP_VERSION_ID >= 80200) {
            $payload['classes'] = DeepCloneReadonlyRefs::class;
            try {
                deepclone_from_array($payload);
                $this->fail('Error expected');
            } catch (\Error $e) {
                $this->assertSame('Cannot create dynamic property '.DeepCloneReadonlyRefs::class.'::$a', $e->getMessage());
            }
        }
    }

    /**
     * @requires PHP 8.4
     */
    public function testFromArrayRejectsHardReferencesToVirtualProperties()
    {
        $this->skipIfExtensionDropsPropertyReferences();

        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('hard references cannot target virtual properties');
        deepclone_from_array([
            'classes' => DeepCloneVirtualRefs::class,
            'objectMeta' => 1,
            'prepared' => 0,
            'properties' => ['stdClass' => ['virtual' => [0 => -1]]],
            'resolve' => ['stdClass' => ['virtual' => [0 => false]]],
            'refs' => [1 => 3],
        ]);
    }

    /**
     * @requires PHP 8.4
     */
    public function testFromArrayWritesHookedPropertiesRaw()
    {
        $o = new DeepCloneHookedChild();
        $o->pub = 1;
        $o->setProt(2);
        $o->setSecret(3);

        // Set hooks ran when the origin was built: the copy takes the stored values
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertSame(10, $clone->pub);
        $this->assertSame(20, $clone->getProt());
        $this->assertSame(30, $clone->getSecret());
    }

    private function skipIfExtensionMisresolvesSleepNames(): void
    {
        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills && version_compare(phpversion('deepclone'), '0.8.6', '<')) {
            $this->markTestSkipped('ext-deepclone < 0.8.6 resolves some names returned by __sleep() differently than serialize().');
        }
    }

    private function skipIfExtensionDiffersFromSerialize(): void
    {
        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills && version_compare(phpversion('deepclone'), '0.8.6', '<')) {
            $this->markTestSkipped('ext-deepclone < 0.8.6 exports some values differently than the polyfill.');
        }
    }

    private function skipIfExtensionDropsPropertyReferences(): void
    {
        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills && version_compare(phpversion('deepclone'), '0.8.4', '<')) {
            $this->markTestSkipped('ext-deepclone < 0.8.4 does not preserve all property references.');
        }
    }

    public function testRoundTripNamedClosureGlobalFunction()
    {
        $clone = deepclone_from_array(deepclone_to_array(\Closure::fromCallable('strlen'), null, true), null, true);

        $this->assertSame(5, $clone('hello'));
    }

    public function testRoundTripWideFixture()
    {
        $r = new \stdClass();
        $r->items = [];
        for ($i = 0; $i < 50; ++$i) {
            $it = new \stdClass();
            $it->id = $i;
            $it->label = "item-$i";
            $r->items[] = $it;
        }
        $r->meta = new \stdClass();
        $r->meta->count = 50;
        $clone = deepclone_from_array(deepclone_to_array($r));

        $this->assertCount(50, $clone->items);
        $this->assertSame(0, $clone->items[0]->id);
        $this->assertSame('item-49', $clone->items[49]->label);
        $this->assertSame(50, $clone->meta->count);
        $this->assertNotSame($r, $clone);
    }

    public function testRoundTripCowStringPreservation()
    {
        $big = str_repeat('x', 10000);
        $o = new \stdClass();
        $o->data = $big;
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertSame($big, $clone->data);
    }

    public function testRepeatedClonesAreIndependent()
    {
        $v = [1];
        $v[] = &$v[0];
        $data = deepclone_to_array($v);

        $c1 = deepclone_from_array($data);
        $c2 = deepclone_from_array($data);
        $c1[0] = 999;

        $this->assertSame(999, $c1[1]);
        $this->assertSame(1, $c2[0]);
        $this->assertSame(1, $c2[1]);
    }

    public function testFromArrayRejectsMissingClasses()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) is missing required "classes" key');
        deepclone_from_array(['objectMeta' => 0, 'prepared' => 0]);
    }

    public function testFromArrayRejectsMissingObjectMeta()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) is missing required "objectMeta" key');
        deepclone_from_array(['classes' => 'stdClass', 'prepared' => 0]);
    }

    public function testFromArrayRejectsMissingPrepared()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) is missing required "prepared" key');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 0]);
    }

    public function testFromArrayRejectsClassesWrongType()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "classes" must be of type string|array, null given');
        deepclone_from_array(['classes' => null, 'objectMeta' => 0, 'prepared' => 0]);
    }

    public function testFromArrayRejectsClassesIntEntry()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "classes" entries must be of type string, int given');
        deepclone_from_array(['classes' => [42], 'objectMeta' => 0, 'prepared' => 0]);
    }

    public function testFromArrayRejectsNonObjectUnserializeResult()
    {
        // A class-name string whose second byte is ':' is replayed through
        // unserialize(); a scalar/array serialize form must be rejected rather
        // than stored and later treated as an object.
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) object 0 did not unserialize to an object, int given');
        deepclone_from_array(['classes' => 'i:1234;', 'objectMeta' => 1, 'prepared' => 0]);
    }

    public function testFromArrayRejectsObjectMetaWrongType()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "objectMeta" must be of type int|array, string given');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 'foo', 'prepared' => 0]);
    }

    public function testFromArrayRejectsNegativeObjectMetaCount()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "objectMeta" count must be non-negative, -1 given');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => -1, 'prepared' => 0]);
    }

    public function testFromArrayRejectsOversizedObjectMetaCount()
    {
        // Matches the ext cap (1 << 20). Guards against a DoS where a tiny
        // payload with a huge IS_LONG objectMeta count triggers a massive
        // allocation.
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "objectMeta" count out of range: 1048577');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 0x100001, 'prepared' => 0]);
    }

    public function testFromArrayRejectsObjectMetaReferencingEmptyClasses()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "objectMeta" references class index 0 but "classes" is empty');
        deepclone_from_array(['classes' => '', 'objectMeta' => 1, 'prepared' => 0]);
    }

    public function testFromArrayRejectsOutOfRangeClassIndex()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "objectMeta" entry 0 has out-of-range class index 5');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => [[5, 0]], 'prepared' => 0]);
    }

    public function testFromArrayRejectsObjectMetaWrongShape()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "objectMeta" entry 0 must be [int, int]');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => [['x', 'y']], 'prepared' => 0]);
    }

    public function testFromArrayRejectsObjectMetaWrongScalar()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "objectMeta" entry 0 must be of type int|array, string given');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => ['foo'], 'prepared' => 0]);
    }

    public function testFromArrayRejectsPropertiesWrongType()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "properties" must be of type array, string given');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 0, 'prepared' => 0, 'properties' => 'foo']);
    }

    public function testFromArrayRejectsStatesWrongType()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('deepclone_from_array(): Argument #1 ($data) "states" must be of type array, string given');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 0, 'prepared' => 0, 'states' => 'foo']);
    }

    public function testFromArrayRejectsStatesEntryWrongType()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"states" entry must be of type int|array, string given');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'states' => [1 => 'foo']]);
    }

    public function testFromArrayRejectsStatesUnknownObjectId()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"states" entry references unknown object id 99');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'states' => [1 => 99]]);
    }

    public function testFromArrayRejectsPreparedObjectIdOutOfRange()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"prepared" references unknown object id 99');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 99]);
    }

    public function testFromArrayRejectsWakeupAdvertisedButNoStates()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"objectMeta" entry 0 flags object for state replay but no matching "states" entry was found');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => [[0, 1]], 'prepared' => 0]);
    }

    public function testFromArrayRejectsUnserializeAdvertisedButNoStates()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"objectMeta" entry 0 flags object for state replay but no matching "states" entry was found');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => [[0, -1]], 'prepared' => 0]);
    }

    public function testFromArrayRejectsStatesWakeupWithoutPositiveMeta()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"states" has a __wakeup entry for object id 0 but "objectMeta" does not flag it for __wakeup');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => [[0, -1]], 'prepared' => 0, 'states' => [1 => 0]]);
    }

    public function testFromArrayRejectsStatesUnserializeWithoutNegativeMeta()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"states" has an __unserialize entry for object id 0 but "objectMeta" does not flag it for __unserialize');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => [[0, 1]], 'prepared' => 0, 'states' => [1 => [0, []]]]);
    }

    public function testFromArrayRejectsStatesWakeupEntryButMetaZero()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"states" has a __wakeup entry for object id 0 but "objectMeta" does not flag it for __wakeup');
        deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'states' => [1 => 0]]);
    }

    public function testFromArrayRejectsPreparedRefIdUnknown()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"prepared" references unknown ref id 99');
        deepclone_from_array(['classes' => '', 'objectMeta' => 0, 'prepared' => -99]);
    }

    public function testFromArrayRejectsIntMinRefIdsWithoutWarning()
    {
        // Negating PHP_INT_MIN overflows to a float and emits a runtime warning
        // before the value can be used as a ref-id array key. Every resolution
        // path must reject it cleanly. A strict error handler turns any emitted
        // diagnostic into a failure so the warning cannot regress unnoticed.
        $cases = [
            [
                ['classes' => 'stdClass', 'objectMeta' => 0, 'prepared' => \PHP_INT_MIN],
                '"prepared" references unknown ref id out of range',
            ],
            [
                ['classes' => 'stdClass', 'objectMeta' => 0, 'prepared' => [0 => \PHP_INT_MIN], 'mask' => [0 => true]],
                'malformed payload, ref id out of range',
            ],
            [
                ['classes' => 'stdClass', 'objectMeta' => 0, 'prepared' => [\PHP_INT_MIN, 'strlen'], 'mask' => 0],
                'malformed payload, named-closure references unknown id -9223372036854775808',
            ],
        ];

        set_error_handler(static function ($type, $message) {
            throw new \RuntimeException('unexpected diagnostic: '.$message);
        });
        try {
            foreach ($cases as [$payload, $expected]) {
                try {
                    // allow_named_closures lets the named-closure case reach the
                    // ref-id check; the other cases carry no named-closure marker
                    // so the flag does not affect them.
                    deepclone_from_array($payload, null, true);
                    $this->fail('Expected ValueError was not thrown');
                } catch (\ValueError $e) {
                    $this->assertStringContainsString($expected, $e->getMessage());
                }
            }
        } finally {
            restore_error_handler();
        }
    }

    public function testClosureGlobalFunctionWireFormat()
    {
        $d = deepclone_to_array(\Closure::fromCallable('strlen'), null, true);

        $this->assertSame(0, $d['mask']);
        $this->assertNull($d['prepared'][0]);
        $this->assertSame('strlen', $d['prepared'][1]);
    }

    public function testClosureGlobalFunctionRoundTrip()
    {
        $clone = deepclone_from_array(deepclone_to_array(\Closure::fromCallable('strlen'), null, true), null, true);
        $this->assertSame(5, $clone('hello'));
    }

    public function testClosureStaticMethodWireFormat()
    {
        $d = deepclone_to_array(\Closure::fromCallable([ClosureFixture::class, 'staticMethod']), null, true);

        $this->assertSame(ClosureFixture::class, $d['prepared'][0]);
        $this->assertSame('staticMethod', $d['prepared'][1]);
    }

    public function testClosureStaticMethodRoundTrip()
    {
        $clone = deepclone_from_array(deepclone_to_array(\Closure::fromCallable([ClosureFixture::class, 'staticMethod']), null, true), null, true);
        $this->assertSame('static', $clone());
    }

    public function testClosureInstanceMethodWireFormat()
    {
        $obj = new ClosureFixture();
        $d = deepclone_to_array(\Closure::fromCallable([$obj, 'instanceMethod']), null, true);

        $this->assertSame(ClosureFixture::class, $d['classes']);
    }

    public function testClosureInstanceMethodRoundTrip()
    {
        $obj = new ClosureFixture();
        $clone = deepclone_from_array(deepclone_to_array(\Closure::fromCallable([$obj, 'instanceMethod']), null, true), null, true);
        $this->assertSame('instance', $clone());
    }

    public function testClosurePrivateMethodWireFormatAndRoundTrip()
    {
        $obj = new ClosureFixture();
        $fn = $obj->getPrivateClosure();
        $d = deepclone_to_array($fn, null, true);

        $this->assertSame(0, $d['mask']);

        $clone = deepclone_from_array($d, null, true);
        $this->assertSame('private', $clone());
    }

    public function testToArrayNamedClosureRequiresOptIn()
    {
        $this->expectException(\ValueError::class);
        // Substring common to the polyfill and extension messages (the polyfill
        // quotes the option name and appends an extension hint).
        $this->expectExceptionMessage('serializing a closure over the named callable "strlen" requires enabling the');
        deepclone_to_array(\Closure::fromCallable('strlen'));
    }

    public function testMalformedPayloadsThrowTheSameValueErrors()
    {
        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills && version_compare(phpversion('deepclone'), '0.8.6', '<')) {
            $this->markTestSkipped('ext-deepclone < 0.8.6 reports some malformed payloads differently.');
        }

        $payloads = [
            'deepclone_from_array(): Argument #1 ($data) "objectMeta" entry index k out of range' => ['classes' => 'stdClass', 'objectMeta' => ['k' => 0], 'prepared' => 0],
            'deepclone_from_array(): Argument #1 ($data) "properties" entry for "stdClass::a" references unknown object id 5' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'properties' => ['stdClass' => ['a' => [1, 5 => 2]]]],
            'deepclone_from_array(): Argument #1 ($data) "properties" entry for "stdClass::a" references unknown object id k' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'properties' => ['stdClass' => ['a' => ['k' => 1]]]],
            'deepclone_from_array(): Argument #1 ($data) "properties" value for "stdClass::x" targets a non-public declared property on object id 0' => ['classes' => PrivShadowA::class, 'objectMeta' => 1, 'prepared' => 0, 'properties' => ['stdClass' => ['x' => ['y']]]],
            'deepclone_from_array(): malformed payload, object reference value must be of type int, null given' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => [0], 'mask' => [1 => true]],
            'deepclone_from_array(): malformed payload, hard-ref slot must be of type int, null given' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => [0], 'mask' => [1 => false]],
            'deepclone_from_array(): malformed payload, array-mask value must be of type array, null given' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'refMasks' => [1 => [true]]],
            // Unknown masks that match nothing create no reference
            'deepclone_from_array(): malformed payload, unknown ref id 7' => ['classes' => '', 'objectMeta' => 0, 'prepared' => [-7], 'mask' => [false], 'refMasks' => [7 => 2]],
            'deepclone_from_array(): Argument #1 ($data) "prepared" references unknown ref id 1' => ['classes' => '', 'objectMeta' => 0, 'prepared' => -1, 'refMasks' => [1 => 'zz']],
            // Resolve markers that match no value too
            'deepclone_from_array(): malformed payload, enum value must be of type string, null given' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'properties' => ['stdClass' => ['a' => [1]]], 'resolve' => ['stdClass' => ['a' => [3 => 'e']]]],
            'deepclone_from_array(): Argument #1 ($data) "properties" scope "'.PrivShadowA::class.'" is not a parent of object id 0 (stdClass)' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'properties' => [PrivShadowA::class => ['x' => [1]]]],
            'deepclone_from_array(): Argument #1 ($data) "properties" value for "'.PrivShadowA::class.'::nope" does not match a declared property on object id 0' => ['classes' => PrivShadowA::class, 'objectMeta' => 1, 'prepared' => 0, 'properties' => [PrivShadowA::class => ['nope' => [1]]]],
            'deepclone_from_array(): Argument #1 ($data) "resolve" entry for scope "stdClass" must be of type array, null given' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'properties' => ['stdClass' => ['a' => [1]]], 'resolve' => ['stdClass' => null]],
            'deepclone_from_array(): Argument #1 ($data) "resolve" value for "stdClass::a" must be of type array, null given' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'properties' => ['stdClass' => ['a' => [1]]], 'resolve' => ['stdClass' => ['a' => null]]],
            'deepclone_from_array(): malformed payload, ref id 1 cannot reference itself' => ['classes' => '', 'objectMeta' => 0, 'prepared' => [-1], 'mask' => [false], 'refs' => [1 => -1], 'refMasks' => [1 => false]],
        ];
        if (!\extension_loaded('deepclone') || TestListenerTrait::$enabledPolyfills || version_compare(phpversion('deepclone'), '0.8.7', '>=')) {
            // An array cast can give such names to a stdClass
            $payloads['deepclone_from_array(): Argument #1 ($data) "properties" names of scope "stdClass" cannot start with "\0"'] = deepclone_to_array((object) ["\0*\0p" => 1]);
        }
        // Without warnings about the unknown id
        $payload = deepclone_to_array(hash_init('md5'));
        $payload['states'][] = [5, []];
        $payloads['deepclone_from_array(): Argument #1 ($data) "states" entry references unknown object id 5'] = $payload;
        if (\PHP_VERSION_ID >= 80200) {
            // A Random\Randomizer is created from its state before the properties are hydrated
            $payloads['deepclone_from_array(): Argument #1 ($data) malformed "states" entry: expected [int, mixed, mixed?]'] = ['classes' => \Random\Randomizer::class, 'objectMeta' => [[0, -1]], 'prepared' => 0, 'states' => [[[0], []]]];
        }

        foreach ($payloads as $message => $payload) {
            try {
                deepclone_from_array($payload);
                $this->fail(\sprintf('deepclone_from_array() accepted a payload expected to throw "%s".', $message));
            } catch (\ValueError $e) {
                $this->assertSame($message, $e->getMessage());
            }
        }

        // Nor do they add values
        $this->assertEquals([new \stdClass()], deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => [0], 'mask' => [0 => true, 'x' => 'zz']]));
        $this->assertEquals((object) ['a' => 1], deepclone_from_array(['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0, 'properties' => ['stdClass' => ['a' => [1]]], 'resolve' => ['stdClass' => ['a' => [3 => 'zz', 'k' => 'zz']]]]));

        // What PHP throws when writing a property comes first, as the extension stops there
        $this->expectException(\TypeError::class);
        $this->expectExceptionMessage('Cannot assign string to property '.TypedInt::class.'::$x of type int');
        deepclone_from_array(['classes' => TypedInt::class, 'objectMeta' => 1, 'prepared' => 0, 'properties' => ['stdClass' => ['x' => ['abc', 5 => 1]]]]);
    }

    private function skipIfExtensionCreatesNamedClosuresDifferently(): void
    {
        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills && version_compare(phpversion('deepclone'), '0.8.7', '<')) {
            $this->markTestSkipped('ext-deepclone < 0.8.7 creates some named closures differently.');
        }
    }

    public function testNamedClosuresAreCreatedLikeFromCallable()
    {
        $this->skipIfExtensionCreatesNamedClosuresDifferently();

        $roundtrip = static function (\Closure $closure) {
            return deepclone_from_array(deepclone_to_array($closure, null, true), null, true);
        };

        // Called on the child class, with the scope of the declaring one
        $this->assertSame(NamedClosureChild::class, $roundtrip(\Closure::fromCallable([NamedClosureChild::class, 'create']))());
        $this->assertSame('base', $roundtrip(\Closure::fromCallable([new NamedClosureChild(), 'reveal']))());
        $this->assertSame(NamedClosureChild::class, $roundtrip((new NamedClosureChild())->getProt())());

        // Methods that __call() and __callStatic() handle
        $this->assertSame('call foo', $roundtrip(\Closure::fromCallable([new NamedClosureMagic(), 'foo']))());
        $this->assertSame('static bar '.NamedClosureMagic::class, $roundtrip(\Closure::fromCallable([NamedClosureMagic::class, 'bar']))());

        $payloads = [
            'deepclone_from_array(): malformed payload, named-closure function or method not found' => ['classes' => '', 'objectMeta' => 0, 'prepared' => [null, 'no_such_function'], 'mask' => 0],
            'deepclone_from_array(): malformed payload, named-closure method '.NamedClosureBase::class.'::reveal() is not static' => ['classes' => '', 'objectMeta' => 0, 'prepared' => [NamedClosureBase::class, 'reveal'], 'mask' => 0],
            'deepclone_from_array(): malformed payload, named-closure method '.NamedClosureBase::class.'::prot() cannot be called on stdClass' => ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => [[[0, 'prot'], NamedClosureBase::class, 'prot']], 'mask' => [0]],
        ];
        foreach ($payloads as $message => $payload) {
            try {
                deepclone_from_array($payload, null, true);
                $this->fail(\sprintf('deepclone_from_array() accepted a payload expected to throw "%s".', $message));
            } catch (\ValueError $e) {
                $this->assertSame($message, $e->getMessage());
            }
        }
    }

    public function testMagicMethodsAreCalledWhateverTheirVisibility()
    {
        $this->skipIfExtensionCreatesNamedClosuresDifferently();

        // Declaring them raises a warning
        if (!class_exists(DeepCloneNonPublicMagic::class, false)) {
            @eval('namespace '.__NAMESPACE__.'; class DeepCloneNonPublicMagic { public $calls = []; private function __serialize(): array { return ["calls" => ["__serialize"]]; } private function __unserialize(array $data): void { $this->calls = array_merge($data["calls"], ["__unserialize"]); } }');
            @eval('namespace '.__NAMESPACE__.'; class DeepCloneNonPublicSleep { public $calls = []; public $skipped = 1; protected function __sleep(): array { $this->calls[] = "__sleep"; return ["calls"]; } private function __wakeup(): void { $this->calls[] = "__wakeup"; } }');
        }

        $this->assertSame(['__serialize', '__unserialize'], deepclone_from_array(deepclone_to_array(new DeepCloneNonPublicMagic()))->calls);

        $o = new DeepCloneNonPublicSleep();
        $o->skipped = 2;
        $clone = deepclone_from_array(deepclone_to_array($o));
        $this->assertSame(['__sleep', '__wakeup'], $clone->calls);
        $this->assertSame(1, $clone->skipped);
    }

    public function testClassNamesAreCutAtTheirFirstNulInMessages()
    {
        foreach ([[new class() {}, ['stdClass'], 'deepclone_to_array(): class "class@anonymous" is not allowed'], [new \stdClass(), ["A\0B"], 'deepclone_to_array(): Argument $allowed_classes must be an array of class names, "A" given']] as [$value, $allowedClasses, $message]) {
            try {
                deepclone_to_array($value, $allowedClasses);
                $this->fail('ValueError expected.');
            } catch (\ValueError $e) {
                $this->assertSame($message, $e->getMessage());
            }
        }
    }

    public function testFromArrayNamedClosureRequiresOptIn()
    {
        $d = deepclone_to_array(\Closure::fromCallable('strlen'), null, true);
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('resolving a closure over a named callable requires enabling the "allow_named_closures" option');
        deepclone_from_array($d);
    }

    public function testFromArrayNamedClosureNestedRejectedBeforeInstantiation()
    {
        $h = new \stdClass();
        $h->cb = \Closure::fromCallable('strlen');
        $d = deepclone_to_array($h, null, true);

        try {
            deepclone_from_array($d);
            $this->fail('Expected ValueError was not thrown');
        } catch (\ValueError $e) {
            $this->assertStringContainsString('resolving a closure over a named callable requires enabling the "allow_named_closures" option', $e->getMessage());
        }

        $clone = deepclone_from_array($d, null, true);
        $this->assertSame(4, ($clone->cb)('abcd'));
    }

    public function testToArrayAnonymousClosureIsNotInstantiable()
    {
        $closures = [
            function () {},
            \Closure::bind(function () { return 1; }, new ClosureFixture(), ClosureFixture::class),
        ];

        foreach ($closures as $closure) {
            foreach ([false, true] as $allowNamedClosures) {
                try {
                    deepclone_to_array($closure, null, $allowNamedClosures);
                    $this->fail('Expected NotInstantiableException was not thrown');
                } catch (\DeepClone\NotInstantiableException $e) {
                    $this->assertSame('Type "Closure" is not instantiable.', $e->getMessage());
                }
            }
        }
    }

    public function testDateTimeRoundTrip()
    {
        $dt = \DateTime::createFromFormat('U', '0');
        $d = deepclone_to_array($dt);

        // __unserialize (negative wakeup) on 8.2+, __wakeup (positive) on 8.1
        $this->assertNotSame(0, $d['objectMeta'][0][1]);

        $clone = deepclone_from_array($d);
        $this->assertInstanceOf(\DateTime::class, $clone);
        $this->assertSame('0', $clone->format('U'));
        $this->assertNotSame($dt, $clone);
    }

    public function testDateTimeImmutableRoundTrip()
    {
        $dti = \DateTimeImmutable::createFromFormat('U', '0');
        $clone = deepclone_from_array(deepclone_to_array($dti));

        $this->assertInstanceOf(\DateTimeImmutable::class, $clone);
        $this->assertSame('0', $clone->format('U'));
    }

    public function testDateTimeZoneRoundTrip()
    {
        $tz = new \DateTimeZone('Europe/Paris');
        $clone = deepclone_from_array(deepclone_to_array($tz));

        $this->assertInstanceOf(\DateTimeZone::class, $clone);
        $this->assertSame('Europe/Paris', $clone->getName());
    }

    public function testDateIntervalRoundTrip()
    {
        $start = new \DateTimeImmutable('2009-10-11');
        $end = new \DateTimeImmutable('2009-10-18');
        $interval = $start->diff($end);
        $clone = deepclone_from_array(deepclone_to_array($interval));

        $this->assertInstanceOf(\DateInterval::class, $clone);
        $this->assertSame(7, $clone->d);
    }

    public function testDatePeriodRoundTrip()
    {
        $p = new DeepCloneDatePeriod(new \DateTimeImmutable('2020-01-01 10:00:00', new \DateTimeZone('Europe/Paris')), new \DateInterval('P1D'), 3, \DatePeriod::EXCLUDE_START_DATE);
        $p->label = 'L';
        $p->self = $p;
        $it = $p->getIterator();
        $it->rewind();
        $it->next();

        $c = deepclone_from_array(deepclone_to_array([$p, $p]));

        $this->assertInstanceOf(DeepCloneDatePeriod::class, $c[0]);
        $this->assertSame($c[0], $c[1]);
        $this->assertSame($c[0], $c[0]->self);
        $this->assertSame('L', $c[0]->label);
        $this->assertSame($p->recurrences, $c[0]->recurrences);
        $this->assertSame(3, $c[0]->getRecurrences());
        $this->assertFalse($c[0]->include_start_date);
        $this->assertEquals($p->current, $c[0]->current);
        $this->assertInstanceOf(\DateTimeImmutable::class, $c[0]->getStartDate());

        $dates = static function (\DatePeriod $p) {
            return array_map(static function ($d) { return $d->format('c'); }, iterator_to_array($p));
        };
        $this->assertSame(['2020-01-02T10:00:00+01:00', '2020-01-03T10:00:00+01:00', '2020-01-04T10:00:00+01:00'], $dates($c[0]));

        if (\PHP_VERSION_ID >= 80200) {
            $p = new \DatePeriod(new \DateTime('2020-01-01 UTC'), new \DateInterval('P1D'), new \DateTime('2020-01-02 UTC'), \DatePeriod::INCLUDE_END_DATE);
            $c = deepclone_from_array(deepclone_to_array($p));

            $this->assertTrue($c->include_end_date);
            $this->assertSame(['2020-01-01T00:00:00+00:00', '2020-01-02T00:00:00+00:00'], $dates($c));
        }
    }

    public function testDatePeriodSharesObjectsAndChecksAllowedClasses()
    {
        $o = new \stdClass();
        $p = new DeepCloneDatePeriod(new \DateTimeImmutable('2020-01-01 UTC'), new \DateInterval('P1D'), 1);
        $p->label = $o;

        $c = deepclone_from_array(deepclone_to_array([$p, $o]));
        $this->assertSame($c[1], $c[0]->label);

        try {
            deepclone_to_array($p, [DeepCloneDatePeriod::class, 'stdClass']);
            $this->fail('deepclone_to_array() accepted a DatePeriod holding a DateTimeImmutable.');
        } catch (\ValueError $e) {
            $this->assertSame('deepclone_to_array(): class "DateTimeImmutable" is not allowed', $e->getMessage());
        }

        try {
            deepclone_to_array($p, [DeepCloneDatePeriod::class, 'DateTimeImmutable', 'DateInterval']);
            $this->fail('deepclone_to_array() accepted a stdClass.');
        } catch (\ValueError $e) {
            $this->assertSame('deepclone_to_array(): class "stdClass" is not allowed', $e->getMessage());
        }
    }

    public function testUninitializedDatePeriodIsRejectedLikeUnserialize()
    {
        $p = (new \ReflectionClass(\DatePeriod::class))->newInstanceWithoutConstructor();

        try {
            unserialize(serialize($p));
            $this->fail('Error expected');
        } catch (\Error $expected) {
        }

        $this->expectException(\get_class($expected));
        $this->expectExceptionMessage($expected->getMessage());
        deepclone_from_array(deepclone_to_array($p));
    }

    public function testEnumIsStaticValue()
    {
        $d = deepclone_to_array(DeepCloneColor::Red);

        $this->assertArrayHasKey('value', $d);
        $this->assertSame(DeepCloneColor::Red, $d['value']);
    }

    public function testBackedEnumIsStaticValue()
    {
        $d = deepclone_to_array(DeepCloneSuit::Hearts);

        $this->assertSame(DeepCloneSuit::Hearts, $d['value']);
    }

    public function testEnumInArrayIsStatic()
    {
        $d = deepclone_to_array([DeepCloneColor::Red, DeepCloneColor::Blue]);

        $this->assertSame([DeepCloneColor::Red, DeepCloneColor::Blue], $d['value']);
    }

    public function testEnumAsObjectProperty()
    {
        $o = new \stdClass();
        $o->color = DeepCloneColor::Red;
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertSame(DeepCloneColor::Red, $clone->color);
    }

    public function testEnumHardReference()
    {
        $x = DeepCloneColor::Red;
        $v = [&$x, &$x];
        $d = deepclone_to_array($v);

        $this->assertArrayHasKey('refs', $d);
        $this->assertArrayHasKey('refMasks', $d);

        $clone = deepclone_from_array($d);
        $this->assertSame(DeepCloneColor::Red, $clone[0]);

        $clone[0] = DeepCloneColor::Blue;
        $this->assertSame(DeepCloneColor::Blue, $clone[1]);
    }

    public function testErrorPropertiesStayUnderErrorScope()
    {
        $e = new \Error('test');
        (new \ReflectionProperty(\Error::class, 'trace'))->setValue($e, ['file' => 't.php']);
        (new \ReflectionProperty(\Error::class, 'line'))->setValue($e, 234);

        $d = deepclone_to_array($e);

        $this->assertArrayHasKey('message', $d['properties']['Error']);
        $this->assertArrayHasKey('line', $d['properties']['Error']);
        $this->assertArrayHasKey('trace', $d['properties']['Error']);
        $this->assertArrayNotHasKey('TypeError', $d['properties']);
    }

    public function testErrorSubclassKeepsErrorScope()
    {
        $e = new DeepCloneFinalError('subclass');
        (new \ReflectionProperty(\Error::class, 'trace'))->setValue($e, []);
        (new \ReflectionProperty(\Error::class, 'line'))->setValue($e, 123);

        $d = deepclone_to_array($e);

        $this->assertArrayHasKey('trace', $d['properties']['Error']);
        $this->assertArrayHasKey('line', $d['properties']['Error']);
    }

    public function testErrorRoundTrip()
    {
        $e = new \Error('round-trip');
        (new \ReflectionProperty(\Error::class, 'trace'))->setValue($e, []);

        $clone = deepclone_from_array(deepclone_to_array($e));

        $this->assertInstanceOf(\Error::class, $clone);
        $this->assertSame('round-trip', $clone->getMessage());
    }

    public function testErrorExceptionKeepsItsSeverity()
    {
        $e = new \ErrorException('round-trip', 0, \E_WARNING);

        $this->assertSame(\E_WARNING, deepclone_from_array(deepclone_to_array($e))->getSeverity());
        $this->assertSame(\E_NOTICE, deepclone_hydrate(\ErrorException::class, ['severity' => \E_NOTICE])->getSeverity());
        $this->assertSame(\E_NOTICE, deepclone_hydrate(\ErrorException::class, ["\0*\0severity" => \E_NOTICE])->getSeverity());
    }

    public function testSerializeMethodWireFormatAndRoundTrip()
    {
        $o = new DeepCloneSerializeFixture('test', 42);
        $d = deepclone_to_array($o);

        // Negative wakeup = __unserialize will be called during reconstruction.
        $this->assertLessThan(0, $d['objectMeta'][0][1]);

        $clone = deepclone_from_array($d);
        $this->assertInstanceOf(DeepCloneSerializeFixture::class, $clone);
        $this->assertSame('test', $clone->name);
        $this->assertSame(42, $clone->val);
    }

    public function testWakeupIsCalledWithPositiveWakeup()
    {
        $o = new DeepCloneWakeupFixture();
        $o->status = 'custom';
        $d = deepclone_to_array($o);

        $this->assertGreaterThan(0, $d['objectMeta'][0][1]);

        $clone = deepclone_from_array($d);
        $this->assertSame('awake', $clone->status);
    }

    public function testSleepFiltersProperties()
    {
        $o = new DeepCloneSleepFixture();
        $o->keep = 'yes';
        $o->skip = 'no';
        $d = deepclone_to_array($o);

        $this->assertArrayHasKey('keep', $d['properties']['stdClass']);
        $this->assertArrayNotHasKey('skip', $d['properties']['stdClass']);
    }

    public function testSerializeWithoutUnserializeScopedProperties()
    {
        $o = new DeepCloneChildNoUnser();
        $d = deepclone_to_array($o);

        // foo is private on ParentNoUnser → scoped to ParentNoUnser
        $this->assertArrayHasKey('foo', $d['properties']['Symfony\\Polyfill\\Tests\\DeepClone\\DeepCloneParentNoUnser']);
        // baz is public → scoped to stdClass
        $this->assertArrayHasKey('baz', $d['properties']['stdClass']);
        // bar is private on ChildNoUnser → scoped to ChildNoUnser
        $this->assertArrayHasKey('bar', $d['properties']['Symfony\\Polyfill\\Tests\\DeepClone\\DeepCloneChildNoUnser']);
        // No __unserialize → no states key
        $this->assertArrayNotHasKey('states', $d);
    }

    public function testUnserializeWithoutSerializeUsesRawArrayState()
    {
        $o = new DeepCloneUnserOnly();
        $o->foo = 'hello';
        $d = deepclone_to_array($o);

        // Should have states (negative wakeup = __unserialize)
        $this->assertArrayHasKey('states', $d);

        // State props are the raw (array) cast, NOT scoped
        $state = reset($d['states']);
        $this->assertArrayHasKey('foo', $state[1]);
        $this->assertSame('hello', $state[1]['foo']);

        // Properties should be empty (all data in state)
        $this->assertTrue(empty($d['properties']));
    }

    public function testUnserializeWithoutSerializeRoundTrip()
    {
        $o = new DeepCloneUnserOnly();
        $o->foo = 'hello';
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertSame('hello', $clone->foo);
    }

    public function testSleepWithMangledPrivateKeys()
    {
        $o = new DeepCloneSleepPrivate();
        $o->setAll('night', 'afternoon', 'morning');
        // Like serialize(), warns that "\0*\0foo" is returned from __sleep() after "foo"
        $d = @deepclone_to_array($o);

        $this->assertArrayHasKey('good', $d['properties']['stdClass']);
        $this->assertArrayHasKey('foo', $d['properties']['Symfony\\Polyfill\\Tests\\DeepClone\\DeepCloneSleepPrivate']);
        $this->assertArrayHasKey('bar', $d['properties']['Symfony\\Polyfill\\Tests\\DeepClone\\DeepCloneSleepPrivate']);
    }

    public function testSleepInheritedPrivateExclusion()
    {
        $this->skipIfExtensionMisresolvesSleepNames();

        $o = new DeepCloneChildSleep();
        $o->pub = 'visible';
        // A non-default value, as default ones are not exported anyway
        $o->setSecret('changed');
        // `__sleep` returning the unmangled name "secret" triggers the same
        // E_NOTICE that serialize() itself would ("returned as member variable
        // … but does not exist"), because unmangled names are not allowed to
        // reach a parent's private property. The PHPT just ignores that; we
        // have to silence it so phpunit-bridge doesn't turn it into an error.
        $d = @deepclone_to_array($o);

        $this->assertArrayHasKey('pub', $d['properties']['stdClass']);
        // 'secret' is a private property of ParentSleep. Unmangled "secret"
        // in __sleep must NOT match it (inherited-private exclusion).
        $this->assertArrayNotHasKey('Symfony\\Polyfill\\Tests\\DeepClone\\DeepCloneParentSleep', $d['properties'] ?? []);
    }

    public function testSleepBareAndMangledNamesOfSameNamedPrivates()
    {
        $this->skipIfExtensionMisresolvesSleepNames();

        $o = new DeepCloneSleepSamePrivate();
        $o->setBaseSecret('parent');
        $o->setSecret('child');
        $d = deepclone_to_array($o);

        // Like serialize(), the bare name selects the private property of the
        // object's class and the mangled one the private property of the parent
        $this->assertSame(['parent'], $d['properties'][DeepCloneSleepBase::class]['secret']);
        $this->assertSame(['child'], $d['properties'][DeepCloneSleepSamePrivate::class]['secret']);
        $this->assertEquals(unserialize(serialize($o)), deepclone_from_array($d));
    }

    public function testSleepBareNameOfGrandparentPrivateDoesNotExist()
    {
        $this->skipIfExtensionMisresolvesSleepNames();

        $o = new DeepCloneSleepGrandparentPrivate();
        $o->setBaseSecret('changed');
        $errors = [];
        set_error_handler(static function ($type, $msg) use (&$errors) {
            $errors[] = $msg;

            return true;
        });

        try {
            $d = deepclone_to_array($o);
        } finally {
            restore_error_handler();
        }

        // The mangled name selects the property, the bare one doesn't, like with serialize()
        $this->assertSame(['changed'], $d['properties'][DeepCloneSleepBase::class]['secret']);
        $this->assertCount(1, $errors);
        $this->assertStringEndsWith('serialize(): "secret" returned as member variable from __sleep() but does not exist', $errors[0]);
    }

    public function testSleepNoticeCutsMangledNames()
    {
        $errors = [];
        set_error_handler(static function ($type, $msg) use (&$errors) {
            $errors[] = $msg;

            return true;
        });

        try {
            deepclone_to_array(new DeepCloneSleepMissingMangled());
        } finally {
            restore_error_handler();
        }

        // serialize() cuts the name at its first NUL byte
        $this->assertCount(1, $errors);
        $this->assertStringEndsWith('serialize(): "" returned as member variable from __sleep() but does not exist', $errors[0]);
    }

    /**
     * @dataProvider provideSleepNames
     */
    public function testSleepSelectsPropertiesLikeSerialize($value)
    {
        $this->skipIfExtensionDiffersFromSerialize();

        $expected = self::captureErrors(static function () use ($value) { return unserialize(serialize($value)); }, $expectedErrors);
        $actual = self::captureErrors(static function () use ($value) { return deepclone_from_array(deepclone_to_array($value)); }, $actualErrors);

        // Same properties, in the same order, with the same warnings
        $this->assertSame(self::state($expected), self::state($actual));
        $this->assertSame(self::userErrors($expectedErrors), $actualErrors);
    }

    public static function provideSleepNames(): iterable
    {
        $sleeper = static function (array $names, string $value = 'changed', string $class = DeepCloneSleepNames::class) {
            $o = new $class();
            $o->set($value);
            $o->names = $names;

            return $o;
        };

        yield 'same name twice' => [$sleeper(['a', 'a'])];
        yield 'same name twice, default value' => [$sleeper(['a', 'a'], 'default')];
        yield 'bare then mangled protected name' => [$sleeper(['b', "\0*\0b"])];
        yield 'mangled then bare protected name' => [$sleeper(["\0*\0b", 'b'])];
        yield 'bare then mangled private name' => [$sleeper(['c', "\0".DeepCloneSleepNames::class."\0c"])];
        yield 'missing and repeated names' => [$sleeper(['a', 'x', 'a', 'y'])];
        yield 'names in reverse order' => [$sleeper(['c', 'b', 'a'])];

        $o = $sleeper(['a', 'b']);
        unset($o->a);
        yield 'unset untyped property' => [$o];
        yield 'uninitialized typed property' => [$sleeper(['typed', 'typed', 'a'])];
        yield 'names that are not strings' => [$sleeper([0, 'a', null])];

        $o = new DeepCloneSleepDynamic();
        $o->y = 1;
        $o->x = 2;
        $o->a = 'changed';
        $o->names = ['x', 'y', 'x', 'a'];
        yield 'dynamic properties' => [$o];

        yield '__unserialize()' => [$sleeper(['b', 'a', "\0*\0b", 'x', "\0".DeepCloneSleepNames::class."\0c"], 'changed', DeepCloneSleepUnserialize::class)];

        yield '__sleep() not returning an array' => [[new DeepCloneSleepNotArray()]];
    }

    public function testSleepNotReturningAnArray()
    {
        $this->skipIfExtensionDiffersFromSerialize();

        $d = self::captureErrors(static function () { return deepclone_to_array([new DeepCloneSleepNotArray()]); }, $errors);

        $this->assertSame(['value' => [null]], $d);
        $this->assertSame(self::userErrors([[\E_WARNING, 'serialize(): '.DeepCloneSleepNotArray::class.'::__sleep() should return an array only containing the names of instance-variables to serialize']]), $errors);
    }

    public function testSerializeLastKeyWins()
    {
        $this->skipIfExtensionDiffersFromSerialize();

        foreach ([
            ['b' => 'bare', "\0".DeepCloneSerializeKeys::class."\0b" => 'default'],
            ['p' => 'bare', "\0*\0p" => 'default'],
            ["\0".DeepCloneSerializeKeys::class."\0b" => 'mangled', 'b' => 'default'],
        ] as $data) {
            $o = new DeepCloneSerializeKeys();
            $o->data = $data;

            // Like unserialize(), the last key naming a property wins, even with its default value
            $this->assertEquals(unserialize(serialize($o)), deepclone_from_array(deepclone_to_array($o)));
        }
    }

    public function testSerializeUndeclaredKeys()
    {
        $this->skipIfExtensionDiffersFromSerialize();

        $o = new DeepCloneSerializeKeys();
        $o->data = [7 => 'seven', "\0*\0undeclared" => 1];
        $d = deepclone_to_array($o);

        // Both are restored as dynamic properties
        $this->assertSame(['stdClass' => [7 => ['seven'], 'undeclared' => [1]]], $d['properties']);
        $clone = deepclone_from_array($d);
        $this->assertSame('seven', $clone->{'7'});
        $this->assertSame(1, $clone->undeclared);
    }

    public function testToArrayRejectsClosedResources()
    {
        $this->skipIfExtensionDiffersFromSerialize();

        $closed = fopen('php://memory', 'r');
        fclose($closed);

        foreach ([$closed, [1, [$closed]], (object) ['a' => $closed]] as $value) {
            try {
                deepclone_to_array($value);
                $this->fail('NotInstantiableException expected');
            } catch (\DeepClone\NotInstantiableException $e) {
                $this->assertSame('Type "Unknown resource" is not instantiable.', $e->getMessage());
            }
        }
    }

    public function testAllowedClassesMustBeClassNames()
    {
        $this->skipIfExtensionDiffersFromSerialize();

        $payload = ['classes' => 'stdClass', 'objectMeta' => 1, 'prepared' => 0];
        $this->assertSame($payload, deepclone_to_array(new \stdClass(), ['Foo\\Bar_1', 'stdClass']));
        $this->assertInstanceOf(\stdClass::class, deepclone_from_array($payload, ['Foo\\Bar_1', 'stdClass']));

        // Like unserialize(), which rejects them as well
        foreach ([
            'deepclone_to_array' => static function ($allowed) { return deepclone_to_array(new \stdClass(), $allowed); },
            'deepclone_from_array' => static function ($allowed) use ($payload) { return deepclone_from_array($payload, $allowed); },
        ] as $function => $call) {
            foreach (['not a class', 'O:8:"stdClass":0:{}'] as $name) {
                try {
                    $call([$name]);
                    $this->fail('ValueError expected');
                } catch (\ValueError $e) {
                    $this->assertSame($function.'(): Argument $allowed_classes must be an array of class names, "'.$name.'" given', $e->getMessage());
                }
            }
        }
    }

    public function testToArrayOrdersPropertiesByObjectId()
    {
        $this->skipIfExtensionDiffersFromSerialize();

        // The names of an object's properties come before the ones of the objects it references
        $b = new \stdClass();
        $b->c = 3;
        $b->b = 2;
        $a = new \stdClass();
        $a->a = $b;
        $a->b = 1;
        $this->assertSame(['stdClass' => ['a' => [1], 'b' => [1, 2], 'c' => [1 => 3]]], deepclone_to_array($a)['properties']);

        // The same goes for their markers
        $n1 = new DeepCloneOrderNode();
        $n2 = new DeepCloneOrderNode();
        $n3 = new DeepCloneOrderNode();
        $n1->next = $n2;
        $n1->data = [$n3];
        $n2->next = $n3;
        $n3->next = $n1;
        $n3->data = [$n2];
        $d = deepclone_to_array($n1);
        $this->assertSame(['stdClass' => ['next' => [1, 2, 0], 'data' => [0 => [2], 2 => [1]]]], $d['properties']);
        $this->assertSame(['stdClass' => ['next' => [true, true, true], 'data' => [0 => [true], 2 => [true]]]], $d['resolve']);

        // A reference found once needs no marker, but still places the name it's the value of
        $v = 1;
        $n1 = new DeepCloneOrderNode();
        $n1->next = &$v;
        $n2 = new DeepCloneOrderNode();
        $n2->data = new \stdClass();
        $n3 = new DeepCloneOrderNode();
        $n3->next = new \stdClass();
        $d = deepclone_to_array([$n1, $n2, $n3]);
        $this->assertSame(['stdClass' => ['next' => [0 => 1, 3 => 4], 'data' => [1 => 2]]], $d['properties']);
        $this->assertSame(['stdClass' => ['next' => [3 => true], 'data' => [1 => true]]], $d['resolve']);
    }

    private static function state($value)
    {
        if (\is_array($value)) {
            return array_map([self::class, 'state'], $value);
        }

        return \is_object($value) ? [\get_class($value) => array_map([self::class, 'state'], (array) $value)] : $value;
    }

    private static function captureErrors(callable $f, ?array &$errors)
    {
        $errors = [];
        set_error_handler(static function ($type, $message) use (&$errors) {
            $errors[] = [$type, $message];

            return true;
        });

        try {
            return $f();
        } finally {
            restore_error_handler();
        }
    }

    /**
     * The polyfill raises the user-level counterparts of the warnings and notices of serialize().
     */
    private static function userErrors(array $errors): array
    {
        if (!\extension_loaded('deepclone') || TestListenerTrait::$enabledPolyfills) {
            foreach ($errors as $i => [$type]) {
                $errors[$i][0] = [\E_WARNING => \E_USER_WARNING, \E_NOTICE => \E_USER_NOTICE][$type] ?? $type;
            }
        }

        return $errors;
    }

    public function testTypedObjectParentClass()
    {
        $o = new DeepCloneParentClass();
        $o->pub = 'changed';
        $o->setProt(42);
        $o->setPriv('secret');
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertInstanceOf(DeepCloneParentClass::class, $clone);
        $this->assertSame('changed', $clone->pub);
        $this->assertEquals($o, $clone);
        $this->assertNotSame($o, $clone);
    }

    public function testTypedObjectChildClassInheritedProperties()
    {
        $o = new DeepCloneChildClass();
        $o->pub = 'child_pub';
        $o->setProt(99);
        $o->setPriv('parent_secret');
        $o->setChildPriv('child_secret');
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertInstanceOf(DeepCloneChildClass::class, $clone);
        $this->assertSame('child_pub', $clone->pub);
        $this->assertEquals($o, $clone);
    }

    public function testTypedObjectDefaultValuesAreSkipped()
    {
        $o = new DeepCloneParentClass();
        $d = deepclone_to_array($o);

        // All properties at defaults → properties empty or minimal.
        $this->assertTrue(empty($d['properties']) || [] === $d['properties']);
    }

    public function testReadonlyProperties()
    {
        $o = new DeepCloneReadonlyFixture('test', 42);
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertSame('test', $clone->name);
        $this->assertSame(42, $clone->value);
    }

    public function testDocBehaviorsMissingClassThrowsClassNotFound()
    {
        try {
            deepclone_from_array([
                'classes' => 'NonExistentClassXyz',
                'objectMeta' => 1,
                'prepared' => 0,
                'properties' => ['NonExistentClassXyz' => ['foo' => ['bar']]],
            ]);
            $this->fail('Expected DeepClone\\ClassNotFoundException');
        } catch (\InvalidArgumentException $e) {
            $this->assertInstanceOf(\DeepClone\ClassNotFoundException::class, $e);
            $this->assertSame('Class "NonExistentClassXyz" not found.', $e->getMessage());
        }
    }

    public function testDocBehaviorsSplObjectStorageSharedKey()
    {
        $key = new \stdClass();
        $key->id = 'shared-key';
        $storage = new \SplObjectStorage();
        $storage[$key] = 'value';

        $graph = new \stdClass();
        $graph->storage = $storage;
        $graph->keyOutside = $key;

        $clone = deepclone_from_array(deepclone_to_array($graph));
        $clonedKey = null;
        foreach ($clone->storage as $k) {
            $clonedKey = $k;
        }
        $this->assertSame($clone->keyOutside, $clonedKey);
    }

    public function testDocBehaviorsSplObjectStorageSharedValue()
    {
        $value = new \stdClass();
        $value->id = 'shared-value';
        $key = new \stdClass();
        $storage = new \SplObjectStorage();
        $storage[$key] = $value;

        $graph = new \stdClass();
        $graph->storage = $storage;
        $graph->valueOutside = $value;

        $clone = deepclone_from_array(deepclone_to_array($graph));
        $clonedK = null;
        foreach ($clone->storage as $k) {
            $clonedK = $k;
        }
        $this->assertSame($clone->valueOutside, $clone->storage[$clonedK]);
    }

    public function testDocBehaviorsArrayObjectSharedItem()
    {
        $shared = new \stdClass();
        $shared->id = 'shared';
        $ao = new \ArrayObject(['inside' => $shared]);

        $graph = new \stdClass();
        $graph->ao = $ao;
        $graph->outside = $shared;

        $clone = deepclone_from_array(deepclone_to_array($graph));
        $this->assertSame($clone->outside, $clone->ao['inside']);
    }

    public function testDocBehaviorsArrayIteratorSharedItem()
    {
        $shared = new \stdClass();
        $shared->id = 'shared';
        $ai = new \ArrayIterator(['inside' => $shared]);

        $graph = new \stdClass();
        $graph->ai = $ai;
        $graph->outside = $shared;

        $clone = deepclone_from_array(deepclone_to_array($graph));
        $this->assertSame($clone->outside, $clone->ai['inside']);
    }

    public function testDocBehaviorsReflectionClassIsRejected()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_to_array(new \ReflectionClass(\stdClass::class));
    }

    public function testDocBehaviorsReflectionMethodIsRejected()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_to_array(new \ReflectionMethod(\ArrayObject::class, '__construct'));
    }

    public function testDocBehaviorsReflectionPropertyIsRejected()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_to_array(new \ReflectionProperty(\Error::class, 'message'));
    }

    public function testDocBehaviorsIteratorIteratorIsRejected()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_to_array(new \IteratorIterator(new \ArrayIterator([1, 2])));
    }

    public function testDocBehaviorsRecursiveIteratorIteratorIsRejected()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_to_array(new \RecursiveIteratorIterator(new \RecursiveArrayIterator([[1]])));
    }

    public function testDocBehaviorsAnonymousClassIsRejected()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_to_array(eval('return new class { public int $x = 1; };'));
    }

    public function testDocBehaviorsSplFileInfoIsRejected()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        $this->expectExceptionMessage('SplFileInfo');
        deepclone_to_array(new \SplFileInfo('/etc/hostname'));
    }

    private function skipIfExtensionRejectsClassesDifferently(): void
    {
        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills && version_compare(phpversion('deepclone'), '0.8.6', '<')) {
            $this->markTestSkipped('ext-deepclone < 0.8.6 rejects some classes differently.');
        }
    }

    public function testSubclassesOfClassesRefusingSerializationAreRejected()
    {
        $this->skipIfExtensionRejectsClassesDifferently();

        foreach ([DeepCloneFileInfoSleep::class, DeepCloneFileInfoWakeup::class, DeepCloneFileInfoSerialize::class] as $class) {
            try {
                deepclone_to_array(new $class(__FILE__));
                $this->fail(\sprintf('deepclone_to_array() accepted "%s".', $class));
            } catch (\DeepClone\NotInstantiableException $e) {
                $this->assertSame('Type "'.$class.'" is not instantiable.', $e->getMessage());
            }

            try {
                deepclone_from_array(['classes' => $class, 'objectMeta' => 1, 'prepared' => 0]);
                $this->fail(\sprintf('deepclone_from_array() accepted "%s".', $class));
            } catch (\DeepClone\NotInstantiableException $e) {
                $this->assertSame('Type "'.$class.'" is not instantiable.', $e->getMessage());
            }

            try {
                deepclone_hydrate($class);
                $this->fail(\sprintf('deepclone_hydrate() accepted "%s".', $class));
            } catch (\DeepClone\NotInstantiableException $e) {
                $this->assertStringEndsWith(' "'.$class.'" is not instantiable.', $e->getMessage());
            }
        }
    }

    public function testAnonymousClassesRoundTripWhenTheyRestoreTheirState()
    {
        $objects = [
            new class {
                public $a = 1;

                public function __wakeup(): void
                {
                    $this->a = 2;
                }
            },
            new class {
                public $a = 1;

                public function __serialize(): array
                {
                    return ['a' => 2];
                }

                public function __unserialize(array $data): void
                {
                    $this->a = $data['a'];
                }
            },
        ];

        foreach ($objects as $o) {
            $clone = deepclone_from_array(deepclone_to_array($o));
            $this->assertInstanceOf(\get_class($o), $clone);
            $this->assertSame(2, $clone->a);
            $this->assertInstanceOf(\get_class($o), deepclone_hydrate(\get_class($o)));
        }

        $e = new class('boom') extends \Exception {};
        $this->assertSame('boom', deepclone_from_array(deepclone_to_array($e))->getMessage());
    }

    public function testAnonymousClassesNotRestoringTheirStateAreRejected()
    {
        $objects = [
            new class {
                public function __sleep(): array
                {
                    return [];
                }
            },
            new class {
                public function __serialize(): array
                {
                    return [];
                }
            },
        ];

        foreach ($objects as $o) {
            try {
                deepclone_to_array($o);
                $this->fail('deepclone_to_array() accepted an anonymous class.');
            } catch (\DeepClone\NotInstantiableException $e) {
                $this->assertSame('Type "class@anonymous" is not instantiable.', $e->getMessage());
            }
        }
    }

    public function testUninstantiableClassesAreRejected()
    {
        $this->skipIfExtensionRejectsClassesDifferently();

        foreach ([AbstractScopeBase::class, DeepCloneInterface::class, HydrateTrait::class, DeepCloneColor::class] as $class) {
            // Named in lower case: messages use the declared name
            $calls = [
                'deepclone_from_array' => static function () use ($class) { return deepclone_from_array(['classes' => strtolower($class), 'objectMeta' => 1, 'prepared' => 0]); },
                'deepclone_hydrate' => static function () use ($class) { return deepclone_hydrate(strtolower($class)); },
            ];
            foreach ($calls as $function => $call) {
                try {
                    $call();
                    $this->fail(\sprintf('%s() accepted "%s".', $function, $class));
                } catch (\DeepClone\NotInstantiableException $e) {
                    $this->assertSame('Type "'.$class.'" is not instantiable.', $e->getMessage());
                    $this->assertNull($e->getPrevious());
                }
            }
        }

        try {
            deepclone_from_array(['classes' => \Closure::class, 'objectMeta' => 1, 'prepared' => 0]);
            $this->fail('deepclone_from_array() accepted "Closure".');
        } catch (\DeepClone\NotInstantiableException $e) {
            $this->assertSame('Type "Closure" is not instantiable.', $e->getMessage());
            $this->assertNull($e->getPrevious());
        }
    }

    public function testClassesWhoseStateSerializeLosesAreRejected()
    {
        $this->skipIfExtensionRejectsClassesDifferently();

        // unserialize() creates them, but the three functions reject them, and their user subclasses
        foreach ([\IteratorIterator::class, \LimitIterator::class, \RecursiveIteratorIterator::class, DeepCloneIteratorIterator::class] as $class) {
            $this->assertInstanceOf($class, unserialize('O:'.\strlen($class).':"'.$class.'":0:{}'));

            $calls = [
                'deepclone_from_array' => static function () use ($class) { return deepclone_from_array(['classes' => $class, 'objectMeta' => 1, 'prepared' => 0]); },
                'deepclone_hydrate' => static function () use ($class) { return deepclone_hydrate($class); },
            ];
            foreach ($calls as $function => $call) {
                try {
                    $call();
                    $this->fail(\sprintf('%s() accepted "%s".', $function, $class));
                } catch (\DeepClone\NotInstantiableException $e) {
                    $this->assertSame('Type "'.$class.'" is not instantiable.', $e->getMessage());
                }
            }
        }

        foreach ([new \IteratorIterator(new \ArrayIterator([1])), new DeepCloneIteratorIterator(new \ArrayIterator([1]))] as $object) {
            try {
                deepclone_to_array($object);
                $this->fail(\sprintf('deepclone_to_array() accepted a "%s".', \get_class($object)));
            } catch (\DeepClone\NotInstantiableException $e) {
                $this->assertSame('Type "'.\get_class($object).'" is not instantiable.', $e->getMessage());
            }
        }

        // Unless they declare a serialization API
        $object = deepclone_from_array([
            'classes' => DeepCloneIteratorIteratorWithWakeup::class,
            'objectMeta' => 1,
            'prepared' => 0,
            'properties' => ['stdClass' => ['a' => [1]]],
        ]);
        $this->assertSame(1, $object->a);
        $this->assertSame(1, deepclone_hydrate(DeepCloneIteratorIteratorWithWakeup::class, ['a' => 1])->a);
    }

    public function testInternalClassesKeepingTheirStateOutOfTheirPropertiesAreRejected()
    {
        $this->skipIfExtensionRejectsClassesDifferently();

        // The ones loaded among the classes the polyfill knows, but Relay\Table, which crashes when destroyed without its constructor,
        // and the ones that got a serialization API, like ZipArchive on PHP 8.6
        $classes = array_filter(['XMLWriter', 'XMLReader', 'ZipArchive', 'Redis', 'RedisCluster', 'Imagick', 'ImagickPixel', 'Relay\Relay', 'AMQPConnection', 'APCUIterator', 'MessagePack'], static function ($class) { return class_exists($class) && !method_exists($class, '__unserialize'); });
        if (!$classes) {
            $this->markTestSkipped('No extension providing such classes is loaded.');
        }

        // And their user subclasses
        foreach ($classes as $class) {
            if (!(new \ReflectionClass($class))->isFinal()) {
                $subclass = 'DeepCloneUser'.strtr($class, '\\', '_');
                if (!class_exists($subclass, false)) {
                    eval('class '.$subclass.' extends \\'.$class.' {}');
                }
                $classes[] = $subclass;
            }
        }

        foreach ($classes as $class) {
            // Named in lower case: messages use the declared name
            $calls = [
                'deepclone_to_array' => static function () use ($class) { return deepclone_to_array((new \ReflectionClass($class))->newInstanceWithoutConstructor()); },
                'deepclone_from_array' => static function () use ($class) { return deepclone_from_array(['classes' => strtolower($class), 'objectMeta' => 1, 'prepared' => 0]); },
                'deepclone_hydrate' => static function () use ($class) { return deepclone_hydrate(strtolower($class)); },
            ];
            foreach ($calls as $function => $call) {
                try {
                    $call();
                    $this->fail(\sprintf('%s() accepted "%s".', $function, $class));
                } catch (\DeepClone\NotInstantiableException $e) {
                    $this->assertSame('Type "'.$class.'" is not instantiable.', $e->getMessage());
                }
            }
        }
    }

    public function testSerializedObjectsThatFailToDecodeAreMalformed()
    {
        $payloads = [
            'O:11:"SplFileInfo":0:{}' => \Exception::class,
            'O:'.\strlen(DeepCloneInterface::class).':"'.DeepCloneInterface::class.'":0:{}' => \Error::class,
            'O:8:"stdClass":1:{' => null,
        ];
        foreach ($payloads as $serialized => $previous) {
            try {
                @deepclone_from_array(['classes' => $serialized, 'objectMeta' => 1, 'prepared' => 0]);
                $this->fail(\sprintf('deepclone_from_array() accepted "%s".', $serialized));
            } catch (\ValueError $e) {
                $this->assertSame('deepclone_from_array(): Argument #1 ($data) failed to unserialize object 0', $e->getMessage());
                $this->assertSame($previous, $e->getPrevious() ? \get_class($e->getPrevious()) : null);
            }
        }

        try {
            deepclone_from_array(['classes' => 'b:1;', 'objectMeta' => 1, 'prepared' => 0]);
            $this->fail('deepclone_from_array() accepted a boolean.');
        } catch (\ValueError $e) {
            $this->assertSame('deepclone_from_array(): Argument #1 ($data) object 0 did not unserialize to an object, '.(\PHP_VERSION_ID >= 80300 ? 'true' : 'bool').' given', $e->getMessage());
        }

        // What __wakeup() throws once the object is decoded goes through
        $this->expectException(\LogicException::class);
        $this->expectExceptionMessage('Cannot wake up.');
        deepclone_from_array(['classes' => 'O:'.\strlen(DeepCloneWakeupThrows::class).':"'.DeepCloneWakeupThrows::class.'":0:{}', 'objectMeta' => 1, 'prepared' => 0]);
    }

    public function testClassesExtendingAnonymousOnesAreRejected()
    {
        $this->skipIfExtensionRejectsClassesDifferently();

        if (!class_exists(DeepCloneExtendsAnonymous::class, false)) {
            $anonymous = new class {
                public function __wakeup(): void
                {
                }
            };
            class_alias(\get_class($anonymous), __NAMESPACE__.'\DeepCloneAnonymousAlias');
            eval('namespace '.__NAMESPACE__.'; class DeepCloneExtendsAnonymous extends DeepCloneAnonymousAlias {}');
        }

        try {
            serialize(new DeepCloneExtendsAnonymous());
            $this->fail('serialize() accepted a class extending an anonymous one.');
        } catch (\Exception $e) {
            $this->assertSame('Serialization of \''.DeepCloneExtendsAnonymous::class.'\' is not allowed', $e->getMessage());
        }

        $calls = [
            'deepclone_to_array' => static function () { return deepclone_to_array(new DeepCloneExtendsAnonymous()); },
            'deepclone_from_array' => static function () { return deepclone_from_array(['classes' => DeepCloneExtendsAnonymous::class, 'objectMeta' => 1, 'prepared' => 0]); },
            'deepclone_hydrate' => static function () { return deepclone_hydrate(DeepCloneExtendsAnonymous::class); },
        ];
        foreach ($calls as $function => $call) {
            try {
                $call();
                $this->fail(\sprintf('%s() accepted a class extending an anonymous one.', $function));
            } catch (\DeepClone\NotInstantiableException $e) {
                $this->assertSame('Type "'.DeepCloneExtendsAnonymous::class.'" is not instantiable.', $e->getMessage());
            }
        }
    }

    public function testClassNamesEndAtNulBytesInMessages()
    {
        try {
            deepclone_from_array(['classes' => "Foo\0Bar", 'objectMeta' => 1, 'prepared' => 0], []);
            $this->fail('deepclone_from_array() accepted a class missing from $allowed_classes.');
        } catch (\ValueError $e) {
            $this->assertSame('deepclone_from_array(): class "Foo" is not allowed', $e->getMessage());
        }

        try {
            deepclone_from_array(['classes' => "Foo\0Bar", 'objectMeta' => 1, 'prepared' => 0]);
            $this->fail('deepclone_from_array() accepted a class that does not exist.');
        } catch (\DeepClone\ClassNotFoundException $e) {
            $this->assertSame('Class "Foo" not found.', $e->getMessage());
        }
    }

    public function testDocBehaviorsSensitiveParameterValueIsRejected()
    {
        if (\PHP_VERSION_ID < 80200) {
            $this->markTestSkipped('SensitiveParameterValue requires PHP 8.2+.');
        }
        $this->expectException(\DeepClone\NotInstantiableException::class);
        $this->expectExceptionMessage('SensitiveParameterValue');
        deepclone_to_array(new \SensitiveParameterValue('super-secret-api-key'));
    }

    public function testDocBehaviorsArrayObjectRoundTrips()
    {
        $ao = new \ArrayObject([1, 2, 3]);
        $clone = deepclone_from_array(deepclone_to_array($ao));
        $this->assertInstanceOf(\ArrayObject::class, $clone);
    }

    public function testDocBehaviorsSplFixedArrayRoundTrips()
    {
        if (\PHP_VERSION_ID < 80200) {
            $this->markTestSkipped('SplFixedArray::__serialize requires PHP 8.2+.');
        }
        $fa = \SplFixedArray::fromArray([10, 20, 30]);
        $clone = deepclone_from_array(deepclone_to_array($fa));
        $this->assertInstanceOf(\SplFixedArray::class, $clone);
    }

    public function testDocBehaviorsSplObjectStorageRoundTrips()
    {
        $s = new \SplObjectStorage();
        $s[new \stdClass()] = 'v';
        $clone = deepclone_from_array(deepclone_to_array($s));
        $this->assertInstanceOf(\SplObjectStorage::class, $clone);
    }

    public function testDocBehaviorsTopLevelResourceIsRejected()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        $this->expectExceptionMessage('stream resource');
        deepclone_to_array(\STDIN);
    }

    public function testToArrayRejectsResourceInDeclaredProperty()
    {
        $o = new DeepCloneRefHolder();
        $o->a = \STDIN;

        $this->expectException(\DeepClone\NotInstantiableException::class);
        $this->expectExceptionMessage('stream resource');
        deepclone_to_array($o);
    }

    public function testExceptionClassesExtendInvalidArgumentException()
    {
        $this->assertTrue(is_subclass_of(\DeepClone\NotInstantiableException::class, \InvalidArgumentException::class));
        $this->assertTrue(is_subclass_of(\DeepClone\ClassNotFoundException::class, \InvalidArgumentException::class));
    }

    public function testToArrayAllowedClassesRejectsDisallowed()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"stdClass" is not allowed');
        deepclone_to_array(new \stdClass(), []);
    }

    public function testToArrayAllowedClassesPermitsListed()
    {
        $d = deepclone_to_array(new \stdClass(), ['stdClass']);
        $this->assertSame('stdClass', $d['classes']);
    }

    public function testToArrayAllowedClassesCaseInsensitive()
    {
        $d = deepclone_to_array(new \stdClass(), ['STDCLASS']);
        $this->assertSame('stdClass', $d['classes']);
    }

    public function testToArrayAllowedClassesRejectsClosure()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"Closure" is not allowed');
        deepclone_to_array(\Closure::fromCallable('strlen'), [], true);
    }

    public function testToArrayAllowedClassesStaticValueBypassesCheck()
    {
        $d = deepclone_to_array(42, []);
        $this->assertSame(['value' => 42], $d);
    }

    public function testFromArrayAllowedClassesRejectsDisallowed()
    {
        $d = deepclone_to_array(new \stdClass());
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"stdClass" is not allowed');
        deepclone_from_array($d, []);
    }

    public function testFromArrayAllowedClassesCaseInsensitive()
    {
        $d = deepclone_to_array(new \stdClass());
        $c = deepclone_from_array($d, ['STDCLASS']);
        $this->assertInstanceOf(\stdClass::class, $c);
    }

    public function testFromArrayAllowedClassesRejectsClosureInMask()
    {
        $d = deepclone_to_array(\Closure::fromCallable('strlen'), null, true);
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"Closure" is not allowed');
        deepclone_from_array($d, ['stdClass']);
    }

    public function testFromArrayAllowedClassesStaticValueBypassesCheck()
    {
        $this->assertSame(42, deepclone_from_array(['value' => 42], []));
    }

    public function testRoundTripWithAllowedClasses()
    {
        $o = new \stdClass();
        $o->x = 1;
        $d = deepclone_to_array($o, ['stdClass']);
        $c = deepclone_from_array($d, ['stdClass']);
        $this->assertSame(1, $c->x);
    }

    public function testAllowedChildCarriesParentDeclaredPrivateState()
    {
        $c = new AllowedChild();
        (function () { $this->secret = 'inherited'; })->bindTo($c, AllowedParent::class)();
        $c->pub = 'visible';

        $d = deepclone_to_array($c, ['Symfony\Polyfill\Tests\DeepClone\AllowedChild']);
        $r = deepclone_from_array($d, ['Symfony\Polyfill\Tests\DeepClone\AllowedChild']);
        $this->assertInstanceOf(AllowedChild::class, $r);
        $this->assertSame('inherited', $r->getSecret());
        $this->assertSame('visible', $r->pub);
    }

    /**
     * @requires extension mongodb
     */
    public function testMongoDbBsonRoundTrip()
    {
        $roundtrip = static function (mixed $value): bool {
            $clone = deepclone_from_array(deepclone_to_array($value));

            return serialize($clone) === serialize($value);
        };

        // Stateless types
        $this->assertTrue($roundtrip(new \MongoDB\BSON\MinKey()));
        $this->assertTrue($roundtrip(new \MongoDB\BSON\MaxKey()));

        // Value types carrying state via __serialize / __unserialize
        $this->assertTrue($roundtrip(new \MongoDB\BSON\ObjectId('507f1f77bcf86cd799439011')));
        $this->assertTrue($roundtrip(new \MongoDB\BSON\Binary("\x00\x01\x02\x03", \MongoDB\BSON\Binary::TYPE_GENERIC)));
        $this->assertTrue($roundtrip(new \MongoDB\BSON\Binary(random_bytes(16), \MongoDB\BSON\Binary::TYPE_UUID)));
        $this->assertTrue($roundtrip(new \MongoDB\BSON\UTCDateTime(1000)));
        $this->assertTrue($roundtrip(new \MongoDB\BSON\Regex('^foo', 'i')));
        $this->assertTrue($roundtrip(new \MongoDB\BSON\Decimal128('3.14159265358979323846')));
        $this->assertTrue($roundtrip(new \MongoDB\BSON\Int64(\PHP_INT_MAX)));
        $this->assertTrue($roundtrip(new \MongoDB\BSON\Timestamp(1, 1234567890)));
        $this->assertTrue($roundtrip(new \MongoDB\BSON\Javascript('function(x) { return x; }')));
        $this->assertTrue($roundtrip(\MongoDB\BSON\Document::fromPHP(['_id' => new \MongoDB\BSON\ObjectId('507f1f77bcf86cd799439011'), 'n' => 1])));
        $this->assertTrue($roundtrip(\MongoDB\BSON\PackedArray::fromPHP([new \MongoDB\BSON\ObjectId('507f1f77bcf86cd799439011'), 42])));

        // Shared references: two properties pointing to the same BSON object
        $oid = new \MongoDB\BSON\ObjectId('507f1f77bcf86cd799439011');
        $obj = new \stdClass();
        $obj->a = $oid;
        $obj->b = $oid;
        $clone = deepclone_from_array(deepclone_to_array($obj));
        $this->assertEquals($clone->a, $clone->b);   // same value
        $this->assertSame($clone->a, $clone->b);     // object identity preserved in the graph
        $this->assertNotSame($clone->a, $oid);       // but distinct from the original
    }

    /**
     * @requires extension tidy
     */
    public function testTidyNodeIsNotInstantiable()
    {
        $tidy = new \tidy();
        $tidy->parseString('<p><b>hello</b></p>', [], 'utf8');
        $b = $tidy->body()->child[0]->child[0]; // <b> node

        if (\PHP_VERSION_ID < 80600 && \extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills) {
            // tidyNode is final and bare-instantiable there, so the extension
            // still restores it property by property.
            $clone = deepclone_from_array(deepclone_to_array($b));

            $this->assertInstanceOf(\tidyNode::class, $clone);
            $this->assertNotSame($b, $clone);
            $this->assertSame($b->name, $clone->name);
            $this->assertSame($b->value, $clone->value);

            return;
        }

        // tidyNode wraps a libTidy handle that cannot survive serialization; PHP 8.6
        // marks it NOT_SERIALIZABLE, and the polyfill mirrors that on every version.
        $this->expectException(\DeepClone\NotInstantiableException::class);
        $this->expectExceptionMessage('Type "tidyNode" is not instantiable.');

        deepclone_to_array($b);
    }

    public function testHydrateScopedInstantiate()
    {
        $obj = deepclone_hydrate(HydrateChild::class, [
            "\0".HydrateBase::class."\0secret" => 'hidden',
            'num' => 42,
            'pub' => 'visible',
        ]);

        $this->assertInstanceOf(HydrateChild::class, $obj);
        $this->assertSame('hidden', $obj->getSecret());
        $this->assertSame(42, $obj->getNum());
        $this->assertSame('visible', $obj->pub);
    }

    public function testHydrateScopedExistingObject()
    {
        $existing = new HydrateChild();
        $result = deepclone_hydrate($existing, [
            "\0".HydrateBase::class."\0secret" => 'updated',
            'pub' => 'changed',
        ]);

        $this->assertSame($existing, $result);
        $this->assertSame('updated', $result->getSecret());
        $this->assertSame('changed', $result->pub);
        $this->assertSame(0, $result->getNum());
    }

    public function testHydrateScopedStdClass()
    {
        $o = deepclone_hydrate('stdClass', ['x' => 1, 'y' => 'hi']);

        $this->assertSame(1, $o->x);
        $this->assertSame('hi', $o->y);
    }

    public function testHydrateSplObjectStorage()
    {
        // SplObjectStorage ships __serialize/__unserialize since PHP 7.4 —
        // deepclone_hydrate() instantiates, the caller wires up state.
        $o1 = new \stdClass();
        $o2 = new \stdClass();

        $s = deepclone_hydrate('SplObjectStorage');
        $s->__unserialize([[$o1, 'info1', $o2, 'info2'], []]);

        $this->assertSame(2, $s->count());
        $s->rewind();
        $this->assertSame($o1, $s->current());
        $this->assertSame('info1', $s->getInfo());
    }

    public function testHydrateArrayObject()
    {
        $ao = deepclone_hydrate('ArrayObject');
        $ao->__unserialize([\ArrayObject::ARRAY_AS_PROPS, ['x' => 1, 'y' => 2], []]);

        $this->assertInstanceOf(\ArrayObject::class, $ao);
        $this->assertSame(1, $ao['x']);
        $this->assertTrue(\ArrayObject::ARRAY_AS_PROPS === $ao->getFlags());
    }

    public function testHydrateArrayIterator()
    {
        $ai = deepclone_hydrate('ArrayIterator');
        $ai->__unserialize([0, ['a', 'b', 'c'], []]);

        $this->assertInstanceOf(\ArrayIterator::class, $ai);
        $this->assertCount(3, $ai);
    }

    public function testHydrateFlatStdClass()
    {
        $this->assertEquals((object) ['p' => 123], deepclone_hydrate('stdClass', ['p' => 123]));
    }

    public function testHydrateFlatCaseInsensitiveClass()
    {
        $this->assertEquals((object) ['p' => 123], deepclone_hydrate('STDcLASS', ['p' => 123]));
    }

    public function testHydrateFlatMangledKeys()
    {
        $expected = [
            "\0*\0prot" => 345,
            "\0".HydrateBar::class."\0priv" => 123,
            "\0".HydrateFoo::class."\0priv" => 234,
            'dyn' => 456,
            'ro' => 567,
        ];

        $actual = (array) deepclone_hydrate(HydrateBar::class, $expected);
        ksort($actual);

        $this->assertSame($expected, $actual);
    }

    public function testHydrateMangledKeysNameThePropertiesTheirScopeDeclaresOrInherits()
    {
        // Like unserialize() does for the "*" scope and the one of the object's class, whatever their visibility
        $vars = [
            "\0".HydrateBar::class."\0prot" => 1,
            "\0*\0priv" => 2,
            "\0".HydrateFoo::class."\0ro" => 3,
        ];
        $expected = [
            "\0*\0prot" => 1,
            "\0".HydrateBar::class."\0priv" => 2,
            "\0".HydrateFoo::class."\0priv" => null,
            'ro' => 3,
        ];

        $actual = (array) deepclone_hydrate(HydrateBar::class, $vars);
        ksort($actual);
        ksort($expected);

        $this->assertSame($expected, $actual);

        foreach (["\0*\0nope" => 'key scope "'.HydrateBar::class.'" does not declare a "nope" property', "\0stdClass\0prot" => 'key scope "stdClass" is not a parent of "'.HydrateBar::class.'"'] as $key => $message) {
            try {
                deepclone_hydrate(HydrateBar::class, [$key => 1]);
                $this->fail('ValueError expected.');
            } catch (\ValueError $e) {
                $this->assertSame('deepclone_hydrate(): Argument #2 ($vars) '.$message, $e->getMessage());
            }
        }
    }

    public function testHydrateFlatOwnScopeMangledKeys()
    {
        $src = new HydrateFoo();
        (function () {
            $this->prot = 345;
            $this->priv = 123;
        })->call($src);

        $vars = (array) $src;
        $obj = deepclone_hydrate(HydrateFoo::class, $vars);

        $this->assertSame($vars, (array) $obj);
    }

    public function testHydrateFlatExceptionTrace()
    {
        $e = deepclone_hydrate('Exception', ['trace' => [234]]);

        $this->assertSame([234], $e->getTrace());
    }

    public function testHydrateFlatReadonlyInitialized()
    {
        $obj = new HydrateReadonly(123);
        try {
            deepclone_hydrate($obj, ['value' => 456]);
            $this->fail('Expected Error on readonly overwrite');
        } catch (\Error $e) {
            $this->assertStringContainsString('readonly', $e->getMessage());
        }
        $this->assertSame(123, $obj->getValue());
    }

    public function testHydrateFlatReadonlyUninitialized()
    {
        $obj = deepclone_hydrate(HydrateReadonly::class, ['value' => 456]);

        $this->assertSame(456, $obj->getValue());
    }

    public function testHydratePhpReferences()
    {
        $properties = ['p1' => 1];
        $properties['p2'] = &$properties['p1'];

        $obj = deepclone_hydrate('stdClass', $properties, \DEEPCLONE_HYDRATE_PRESERVE_REFS);

        $this->assertSame(1, $obj->p1);
        $this->assertSame(1, $obj->p2);

        $properties['p1'] = 2;
        $this->assertSame(2, $obj->p1);
        $this->assertSame(2, $obj->p2);
    }

    public function testHydratePhpReferencesNotPreservedByDefault()
    {
        $properties = ['p1' => 1];
        $properties['p2'] = &$properties['p1'];

        $obj = deepclone_hydrate('stdClass', $properties);

        $this->assertSame(1, $obj->p1);
        $this->assertSame(1, $obj->p2);

        $properties['p1'] = 2;
        $this->assertSame(1, $obj->p1);
        $this->assertSame(1, $obj->p2);
    }

    public function testHydrateScopedReferences()
    {
        $v = 'hello';
        $obj = deepclone_hydrate('stdClass', ['x' => &$v, 'y' => &$v], \DEEPCLONE_HYDRATE_PRESERVE_REFS);

        $v = 'world';
        $this->assertSame('world', $obj->x);
        $this->assertSame('world', $obj->y);
    }

    public function testHydrateScopedReferencesNotPreservedByDefault()
    {
        $v = 'hello';
        $obj = deepclone_hydrate('stdClass', ['x' => &$v, 'y' => &$v]);

        $v = 'world';
        $this->assertSame('hello', $obj->x);
        $this->assertSame('hello', $obj->y);
    }

    public function testHydrateClassNotFound()
    {
        $this->expectException(\DeepClone\ClassNotFoundException::class);
        $this->expectExceptionMessage('NoSuchClass99');
        deepclone_hydrate('NoSuchClass99');
    }

    public function testHydrateAbstractClass()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        $this->expectExceptionMessage('SplHeap');
        deepclone_hydrate('SplHeap');
    }

    public function testHydrateInterface()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        $this->expectExceptionMessage('Throwable');
        deepclone_hydrate('Throwable');
    }

    public function testHydrateNoArgInstantiate()
    {
        $o = deepclone_hydrate('stdClass');

        $this->assertInstanceOf(\stdClass::class, $o);
    }

    public function testHydrateEnum()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_hydrate(HydrateColor::class);
    }

    public function testHydrateTrait()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_hydrate(HydrateTrait::class);
    }

    public function testHydrateGrandparentPrivate()
    {
        $o = deepclone_hydrate(HydrateC::class, [
            "\0".HydrateGP::class."\0secret" => 'gp_val',
            "\0".HydrateP::class."\0mid" => 42,
            'pub' => 'hi',
        ]);

        $this->assertSame('gp_val', $o->getSecret());
        $this->assertSame(42, $o->getMid());
        $this->assertSame('hi', $o->pub);
    }

    public function testHydrateBareNameReachesParentPrivate()
    {
        // Bare "secret" on HydrateC (which extends HydrateP extends HydrateGP, where
        // GP declares private $secret) resolves to GP's private slot — no mangled key
        // needed as long as there's only one private of that name in the chain.
        $o = deepclone_hydrate(HydrateC::class, [
            'secret' => 'bare_gp_val',
            'mid' => 7,       // bare, resolves to HydrateP's private $mid
            'pub' => 'hi',    // bare public on HydrateC
        ]);

        $this->assertSame('bare_gp_val', $o->getSecret());
        $this->assertSame(7, $o->getMid());
        $this->assertSame('hi', $o->pub);

        // No stray dynamic properties should have been created.
        $props = (array) $o;
        $this->assertArrayNotHasKey('secret', $props);
        $this->assertArrayNotHasKey('mid', $props);
        $this->assertArrayHasKey("\0".HydrateGP::class."\0secret", $props);
        $this->assertArrayHasKey("\0".HydrateP::class."\0mid", $props);
    }

    public function testHydrateReflectorSubclass()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_hydrate('ReflectionClass');
    }

    public function testHydrateClosure()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_hydrate('Closure');
    }

    public function testHydrateSplFileInfo()
    {
        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_hydrate('SplFileInfo');
    }

    /**
     * @requires extension dom
     */
    public function testDomNameSpaceNodeIsCreatedWithoutItsState()
    {
        if (!class_exists(DeepCloneDomNameSpaceNode::class, false)) {
            eval('namespace '.__NAMESPACE__.'; class DeepCloneDomNameSpaceNode extends \DOMNameSpaceNode { public $a; }');
        }

        // Cloning a bare DOMNameSpaceNode crashes before PHP 8.3
        foreach ([\DOMNameSpaceNode::class, DeepCloneDomNameSpaceNode::class] as $class) {
            $this->assertInstanceOf($class, deepclone_hydrate($class));
            $this->assertInstanceOf($class, deepclone_from_array(['classes' => $class, 'objectMeta' => 1, 'prepared' => 0]));
        }
        $this->assertSame(1, deepclone_hydrate(DeepCloneDomNameSpaceNode::class, ['a' => 1])->a);
    }

    /**
     * @requires extension imagick
     */
    public function testImagickPixelSubclassIsCreatedWithoutItsState()
    {
        // ImagickPixel keeps its state internally: its subclasses are created only when they restore it
        if (!class_exists(DeepCloneImagickPixel::class, false)) {
            eval('namespace '.__NAMESPACE__.'; class DeepCloneImagickPixel extends \ImagickPixel { public $a; public function __serialize(): array { return ["a" => $this->a]; } public function __unserialize(array $data): void { $this->a = $data["a"]; } }');
        }

        // Cloning a bare ImagickPixel aborts
        $this->assertSame(1, deepclone_hydrate(DeepCloneImagickPixel::class, ['a' => 1])->a);

        $pixel = new DeepCloneImagickPixel();
        $pixel->a = 1;
        $this->assertSame(1, deepclone_from_array(deepclone_to_array($pixel))->a);
    }

    /**
     * @requires extension intl
     */
    public function testIntlObjectsAreCreatedLikeUnserializeDoes()
    {
        $values = [
            new \MessageFormatter('en', '{0}'),
            new \IntlDateFormatter('en', \IntlDateFormatter::SHORT, \IntlDateFormatter::NONE),
            new \IntlDatePatternGenerator('en'),
            \Transliterator::create('Latin-ASCII'),
            \IntlTimeZone::createTimeZone('UTC'),
            new \IntlGregorianCalendar(),
            \IntlBreakIterator::createWordInstance('en'),
            \IntlBreakIterator::createCodePointInstance(),
            new \UConverter('utf-8', 'latin1'),
            // Last, as cloning a bare one is a fatal error before PHP 8.4
            new \Spoofchecker(),
        ];

        foreach ($values as $value) {
            $class = \get_class($value);
            try {
                // PHP 8.1 creates them without their state
                $expected = unserialize(serialize($value));
            } catch (\Exception $e) {
                // PHP 8.2+ refuses to serialize them
                try {
                    deepclone_to_array($value);
                    $this->fail(\sprintf('deepclone_to_array() accepted "%s".', $class));
                } catch (\DeepClone\NotInstantiableException $e) {
                    $this->assertSame('Type "'.$class.'" is not instantiable.', $e->getMessage());
                }
                continue;
            }

            $this->assertEquals($expected, deepclone_from_array(deepclone_to_array($value)));
            $this->assertEquals(unserialize('O:'.\strlen($class).':"'.$class.'":0:{}'), deepclone_hydrate($class));
        }
    }

    public function testRoundtripWithAbstractParentScope()
    {
        $o = new AbstractScopeChild('entity');
        $o->setSecret('changed');
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertSame('entity', $clone->sourceEntity);
    }

    public function testRoundtripWithPrivatePropertyOnAbstractParent()
    {
        $o = new AbstractWithPrivateChild();
        $o->set('changed');
        $o->pub = 'hello';
        $clone = deepclone_from_array(deepclone_to_array($o));

        $this->assertSame('changed', $clone->get());
        $this->assertSame('hello', $clone->pub);
    }

    public function testSleepSilentlySkipsUninitializedTypedProperty()
    {
        $o = new AbstractScopeChild('entity');
        $errors = [];
        set_error_handler(static function ($_, $msg) use (&$errors) {
            $errors[] = $msg;

            return true;
        });

        try {
            deepclone_to_array($o);
        } finally {
            restore_error_handler();
        }

        $this->assertSame([], $errors);
    }

    public function testCacheIsolationBetweenScopeHydratorAndClassReflector()
    {
        $child = new CacheIsolationChild();
        $child->pub = 'hi';
        $child->setPriv('override');
        deepclone_from_array(deepclone_to_array($child));

        $p = new CacheIsolationParent();
        $p->setPriv('direct');
        $clone = deepclone_from_array(deepclone_to_array($p));

        $this->assertSame('direct', $clone->getPriv());
    }

    public function testHydrateNulInMiddleOfPropertyNameMatchesUnserialize()
    {
        // Matches unserialize(): NUL in the middle of a dynamic property name
        // is silently accepted — the engine stores the raw name.
        $o = deepclone_hydrate('stdClass', ["foo\0bar" => 'val']);
        $this->assertSame('val', ((array) $o)["foo\0bar"]);
    }

    public function testHydrateNulInMangledKeyProperty()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('invalid mangled key');
        deepclone_hydrate('stdClass', ["\0*\0foo\0bar" => 'val']);
    }

    public function testHydrateIntegerKeyInsideScopeMatchesUnserialize()
    {
        // Matches unserialize(): integer keys coerce to string on dynamic
        // property access; no pre-validation rejects them.
        $o = deepclone_hydrate('stdClass', [0 => 'val']);
        $this->assertSame('val', $o->{'0'});
    }

    public function testNumericPropertyNameRoundTrip()
    {
        // GH-64548: a numeric property name like $o->{'999'} must round-trip
        // the same way serialize()/unserialize() handles it. PHP normalizes
        // numeric string keys to integers, so the wire format uses an int key.
        $cfg = new \stdClass();
        $cfg->{'999'} = ['TST'];

        $d = deepclone_to_array($cfg);
        $this->assertSame(999, array_key_first($d['properties']['stdClass']));

        $clone = deepclone_from_array($d);
        $this->assertEquals($cfg, $clone);
        $this->assertSame(['TST'], $clone->{'999'});
    }

    public function testNumericPropertyNameSurvivesSerializationFormats()
    {
        // The int-keyed payload must survive a var_export()/require round-trip
        // (the OPcache cache.php use case) and a JSON round-trip, both of which
        // re-normalize a "999" key back to the integer 999.
        $o = new \stdClass();
        $o->{'0'} = 'zero';
        $o->normal = 1;

        $d = deepclone_to_array($o);
        $viaExport = deepclone_from_array(eval('return '.var_export($d, true).';'));
        $viaJson = deepclone_from_array(json_decode(json_encode($d), true));

        $this->assertEquals($o, $viaExport);
        $this->assertEquals($o, $viaJson);
    }

    public function testNumericPropertyLeadingZeroStaysString()
    {
        // "007" is not a canonical integer key, so it stays a string — exactly
        // as PHP arrays and serialize() treat it.
        $o = new \stdClass();
        $o->{'007'} = 'keepstr';
        $o->{'8'} = 'int';

        $d = deepclone_to_array($o);
        $this->assertSame(['007', 8], array_keys($d['properties']['stdClass']));
        $this->assertEquals($o, deepclone_from_array($d));
    }

    public function testNumericPropertyOnTypedObjectRoundTrip()
    {
        $f = new DeepCloneNumericHolder();
        $f->{'999'} = ['TST'];
        $f->a = 5;

        $this->assertEquals($f, deepclone_from_array(deepclone_to_array($f)));
    }

    public function testNumericPropertyPreservesSharedObjectIdentity()
    {
        $shared = new \stdClass();
        $shared->x = 1;
        $o = new \stdClass();
        $o->{'42'} = $shared;
        $o->ref2 = $shared;

        $clone = deepclone_from_array(deepclone_to_array($o));
        $this->assertSame($clone->{'42'}, $clone->ref2);
    }

    public function testFromArrayRejectsUnloadedScope()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('scope "NoSuchScope"');
        deepclone_from_array([
            'classes' => ScopeChild::class,
            'objectMeta' => 1,
            'prepared' => 0,
            'properties' => ['NoSuchScope' => ['pub' => [0 => 1]]],
        ]);
    }

    public function testHydrateRejectsMangledKeyWithEmptyClass()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('invalid mangled key');
        deepclone_hydrate('stdClass', ["\0\0x" => 1]);
    }

    public function testHydrateRejectsMangledKeyNoSecondNul()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('invalid mangled key');
        deepclone_hydrate('stdClass', ["\0broken" => 1]);
    }

    public function testHydrateRejectsMangledKeyWithNonParentClass()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('not a parent');
        deepclone_hydrate('stdClass', ["\0SomeUnrelatedClass\0x" => 1]);
    }

    public function testHydrateRejectsMangledProtectedKeyForUndeclaredProp()
    {
        // "\0*\0undeclared" specifically targets a protected slot; if the
        // slot doesn't exist, reject instead of silently creating a dynamic
        // property.
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('does not declare');
        deepclone_hydrate(HydrateReadonly::class, ["\0*\0undeclared" => 1]);
    }

    public function testHydrateRejectsMangledPrivateKeyForUndeclaredProp()
    {
        // "\0ParentClass\0undeclared" with a valid parent class but a prop
        // not declared on it — same reasoning as above.
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('does not declare');
        deepclone_hydrate(HydrateC::class, ["\0".HydrateGP::class."\0undeclared" => 1]);
    }

    /**
     * @requires PHP 8.4
     */
    public function testHydrateInvokesSetHookForVirtualProperty()
    {
        $h = deepclone_hydrate(HookedProps::class, ['x' => 5]);
        $this->assertSame(6, $h->x);
    }

    /**
     * @requires PHP 8.4
     */
    public function testRoundtripOnlyWritesBackingStorage()
    {
        $orig = new HookedProps();
        $orig->x = 20;
        $clone = deepclone_from_array(deepclone_to_array($orig));
        $this->assertSame(21, $clone->x);
    }

    /**
     * @requires PHP 8.4
     */
    public function testHydrateBypassesSetHookForNonVirtualProperty()
    {
        $h = deepclone_hydrate(HookedBackingProps::class, ['x' => 7]);
        $this->assertSame(7, $h->x);
    }

    public function testPrivateShadowingDistinctSlotsPerScope()
    {
        $b = new PrivShadowB();
        deepclone_hydrate($b, [
            "\0".PrivShadowA::class."\0x" => 'A_written',
            'x' => 'B_written',
        ]);
        $this->assertSame('A_written', $b->get());
        $this->assertSame('B_written', $b->getChild());
    }

    public function testPrivateShadowingRoundtripPreservesBothSlots()
    {
        $orig = new PrivShadowB();
        (new \ReflectionProperty(PrivShadowA::class, 'x'))->setValue($orig, 'parent_val');
        (new \ReflectionProperty(PrivShadowB::class, 'x'))->setValue($orig, 'child_val');

        $clone = deepclone_from_array(deepclone_to_array($orig));
        $this->assertSame('parent_val', $clone->get());
        $this->assertSame('child_val', $clone->getChild());
    }

    public function testPrivateShadowingBareMangledNameTargetsMostDerived()
    {
        $b = new PrivShadowB();
        deepclone_hydrate($b, ['x' => 'bare_val']);
        $this->assertSame('a_init', $b->get());
        $this->assertSame('bare_val', $b->getChild());
    }

    public function testPrivateShadowingMangledKeyTargetsParentSlot()
    {
        $b = new PrivShadowB();
        deepclone_hydrate($b, ["\0".PrivShadowA::class."\0x" => 'parent_targeted']);
        $this->assertSame('parent_targeted', $b->get());
        $this->assertSame('b_init', $b->getChild());
    }

    public function testHydrateTypedPropTypeMismatchThrows()
    {
        $this->expectException(\TypeError::class);
        $this->expectExceptionMessage('type int');
        deepclone_hydrate(TypedInt::class, ['x' => 'hello']);
    }

    public function testHydrateTypedPropCoercesNonStrict()
    {
        $o = deepclone_hydrate(TypedInt::class, ['x' => '42']);
        $this->assertSame(42, $o->x);
    }

    public function testHydrateReadonlyTypedMismatchThrows()
    {
        $this->expectException(\TypeError::class);
        $this->expectExceptionMessage('type int');
        deepclone_hydrate(TypedReadonly::class, ['v' => 'nope']);
    }

    public function testFromArrayTypedPropMismatchThrows()
    {
        $this->expectException(\TypeError::class);
        $this->expectExceptionMessage('type int');
        deepclone_from_array([
            'classes' => TypedInt::class,
            'objectMeta' => 1,
            'prepared' => 0,
            'properties' => [TypedInt::class => ['x' => [0 => 'hello']]],
        ]);
    }

    /**
     * @requires PHP 8.4
     */
    public function testHydrateFlagCallHooksInvokesSetHook()
    {
        $o = deepclone_hydrate(HookedBackingProps::class, ['x' => 7], \DEEPCLONE_HYDRATE_CALL_HOOKS);
        $this->assertSame(70, $o->x);
    }

    /**
     * @requires PHP 8.4
     */
    public function testHydrateDefaultFlagBypassesSetHook()
    {
        $o = deepclone_hydrate(HookedBackingProps::class, ['x' => 7]);
        $this->assertSame(7, $o->x);
    }

    public function testHydrateFlagsUnknownBitThrows()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('unknown bits');
        deepclone_hydrate(\stdClass::class, [], 1 << 30);
    }

    public function testHydrateFlagsMutuallyExclusiveThrows()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('mutually exclusive');
        deepclone_hydrate(\stdClass::class, [], \DEEPCLONE_HYDRATE_CALL_HOOKS | \DEEPCLONE_HYDRATE_NO_LAZY_INIT);
    }

    /**
     * @requires PHP 8.4
     */
    public function testHydrateNoLazyInitSkipsInitializer()
    {
        $rc = new \ReflectionClass(TypedInt::class);
        $initRan = 0;
        $ghost = $rc->newLazyGhost(static function (TypedInt $o) use (&$initRan) {
            ++$initRan;
            $o->x = 1;
        });
        deepclone_hydrate($ghost, ['x' => 99], \DEEPCLONE_HYDRATE_NO_LAZY_INIT);
        $this->assertSame(0, $initRan);
        $this->assertSame(99, $ghost->x);
    }

    /**
     * @requires PHP 8.4
     */
    public function testHydrateDefaultFlagRunsLazyInitializer()
    {
        $rc = new \ReflectionClass(TypedInt::class);
        $initRan = 0;
        $ghost = $rc->newLazyGhost(static function (TypedInt $o) use (&$initRan) {
            ++$initRan;
            $o->x = 1;
        });
        deepclone_hydrate($ghost, ['x' => 99]);
        $this->assertSame(1, $initRan);
        $this->assertSame(99, $ghost->x);
    }

    /**
     * @requires PHP 8.4
     */
    public function testToArrayInitializesLazyGhost()
    {
        $this->skipIfExtensionKeepsLazyObjectsUninitialized();

        $rc = new \ReflectionClass(DeepCloneLazyBase::class);
        $initRan = 0;
        $ghost = $rc->newLazyGhost(static function (DeepCloneLazyBase $o) use (&$initRan) {
            ++$initRan;
            $o->__construct('ghost');
        });

        $clone = deepclone_from_array(deepclone_to_array($ghost));

        $this->assertSame(1, $initRan);
        $this->assertFalse($rc->isUninitializedLazyObject($ghost));
        $this->assertSame('ghost', $clone->value);
    }

    /**
     * @requires PHP 8.4
     */
    public function testToArrayInitializesLazyProxy()
    {
        $this->skipIfExtensionKeepsLazyObjectsUninitialized();

        $factoryCalls = 0;
        $proxy = (new \ReflectionClass(DeepCloneLazyChild::class))->newLazyProxy(static function () use (&$factoryCalls) {
            ++$factoryCalls;
            $instance = new DeepCloneLazyBase('proxied');
            $instance->setSecret('s3cr3t');

            return $instance;
        });

        // Like serialize(), the copy is a regular instance of the proxy's class
        // holding the state of its real instance
        $clone = deepclone_from_array(deepclone_to_array($proxy));

        $this->assertSame(1, $factoryCalls);
        $this->assertSame(DeepCloneLazyChild::class, \get_class($clone));
        $this->assertSame('proxied', $clone->value);
        $this->assertSame('s3cr3t', $clone->getSecret());

        $clone = deepclone_from_array(deepclone_to_array($proxy));

        $this->assertSame(1, $factoryCalls);
        $this->assertSame('proxied', $clone->value);
    }

    /**
     * @requires PHP 8.4
     */
    public function testToArrayKeepsLazyProxyAndItsInstanceDistinct()
    {
        $this->skipIfExtensionKeepsLazyObjectsUninitialized();

        $instance = new DeepCloneLazyBase('shared');
        $proxy = (new \ReflectionClass(DeepCloneLazyBase::class))->newLazyProxy(static function () use ($instance) {
            return $instance;
        });

        [$p, $i] = deepclone_from_array(deepclone_to_array([$proxy, $instance]));

        $this->assertNotSame($p, $i);
        $this->assertSame('shared', $p->value);
        $this->assertSame('shared', $i->value);
    }

    /**
     * @requires PHP 8.4
     */
    public function testToArrayInitializesResetInstanceOfLazyProxy()
    {
        $this->skipIfExtensionKeepsLazyObjectsUninitialized();

        $rc = new \ReflectionClass(DeepCloneLazyBase::class);
        $instance = new DeepCloneLazyBase('orig');
        $proxy = $rc->newLazyProxy(static function () use ($instance) {
            return $instance;
        });
        $rc->initializeLazyObject($proxy);
        $rc->resetAsLazyGhost($instance, static function (DeepCloneLazyBase $o) {
            $o->__construct('reset');
        });

        $this->assertSame('reset', deepclone_from_array(deepclone_to_array($proxy))->value);
    }

    /**
     * @requires PHP 8.4
     */
    public function testToArrayIgnoresSkipInitializationOnSerialize()
    {
        $this->skipIfExtensionKeepsLazyObjectsUninitialized();

        $rc = new \ReflectionClass(DeepCloneLazyBase::class);
        $ghost = $rc->newLazyGhost(static function (DeepCloneLazyBase $o) {
            $o->__construct('ghost');
        }, \ReflectionClass::SKIP_INITIALIZATION_ON_SERIALIZE);
        $proxy = $rc->newLazyProxy(static function () {
            return new DeepCloneLazyBase('proxy');
        }, \ReflectionClass::SKIP_INITIALIZATION_ON_SERIALIZE);

        [$g, $p] = deepclone_from_array(deepclone_to_array([$ghost, $proxy]));

        $this->assertSame('ghost', $g->value);
        $this->assertSame('proxy', $p->value);
    }

    /**
     * @requires PHP 8.4
     */
    public function testToArrayPropagatesLazyInitializerException()
    {
        $this->skipIfExtensionKeepsLazyObjectsUninitialized();

        $rc = new \ReflectionClass(DeepCloneLazyBase::class);
        $proxy = $rc->newLazyProxy(static function () {
            throw new \DomainException('boom');
        });

        try {
            deepclone_to_array($proxy);
            $this->fail('DomainException expected');
        } catch (\DomainException $e) {
            $this->assertSame('boom', $e->getMessage());
        }

        $this->assertTrue($rc->isUninitializedLazyObject($proxy));
    }

    /**
     * @requires PHP 8.4
     */
    public function testToArrayExportsUntouchedGhostsFromFromArray()
    {
        $this->skipIfExtensionKeepsLazyObjectsUninitialized();

        // The extension hydrates closure-bearing nodes as lazy ghosts
        $a = new DeepCloneLazyNode('a', \Closure::fromCallable('strlen'));
        $a->next = new DeepCloneLazyNode('b', \Closure::fromCallable('strtoupper'));
        $a->next->next = $a;

        $copy = deepclone_from_array(deepclone_to_array($a, null, true), null, true);
        $again = deepclone_from_array(deepclone_to_array($copy, null, true), null, true);

        $this->assertSame('a', $again->name);
        $this->assertSame(3, ($again->cb)('abc'));
        $this->assertSame('b', $again->next->name);
        $this->assertSame('ABC', ($again->next->cb)('abc'));
        $this->assertSame($again, $again->next->next);
    }

    public function testHydrateReadonlyIdempotentSkipsSameValue()
    {
        $obj = new HydrateReadonly(123);
        $obj = deepclone_hydrate($obj, ['value' => 123]);
        $this->assertSame(123, $obj->getValue());
    }

    public function testHydrateReadonlyDifferentValueThrows()
    {
        $obj = new HydrateReadonly(123);
        try {
            deepclone_hydrate($obj, ['value' => 456]);
            $this->fail('Expected Error on readonly overwrite');
        } catch (\Error $e) {
            $this->assertStringContainsString('readonly', $e->getMessage());
        }
        $this->assertSame(123, $obj->getValue());
    }

    public function testHydrateReadonlyObjectIdentityIsSkipped()
    {
        $inner = new \stdClass();
        $host = new HydrateReadonlyObject($inner);
        $host = deepclone_hydrate($host, ['o' => $inner]);
        $this->assertSame($inner, $host->o);
    }

    public function testHydrateNullIntoNonNullableTypedUnsetsSlot()
    {
        $o = new TypedInt();
        $o = deepclone_hydrate($o, ['x' => null]);
        $this->assertFalse((new \ReflectionProperty(TypedInt::class, 'x'))->isInitialized($o));
    }

    public function testHydrateNullIntoNullableTypedKeepsNull()
    {
        $o = new HydrateNullableInt();
        deepclone_hydrate($o, ['y' => null]);
        $this->assertNull($o->y);
    }

    public function testHydrateCallHooksStillUnsetsOnNullForNonHookedProps()
    {
        // Per-prop gate: TypedInt::$x is not hooked, so A2 still applies
        // even under CALL_HOOKS.
        $o = new TypedInt();
        $o = deepclone_hydrate($o, ['x' => null], \DEEPCLONE_HYDRATE_CALL_HOOKS);
        $this->assertFalse((new \ReflectionProperty(TypedInt::class, 'x'))->isInitialized($o));
    }

    public function testHydrateStringCastToBackedEnum()
    {
        $o = deepclone_hydrate(WithBackedEnums::class, ['s' => 'S']);
        $this->assertSame(DeepCloneHydrateSuit::Spades, $o->s);
    }

    public function testHydrateIntCastToBackedEnum()
    {
        $o = deepclone_hydrate(WithBackedEnums::class, ['n' => 2]);
        $this->assertSame(DeepCloneHydrateSize::Large, $o->n);
    }

    public function testHydrateNullableBackedEnumKeepsNull()
    {
        $o = deepclone_hydrate(WithBackedEnums::class, ['ns' => null]);
        $this->assertNull($o->ns);
    }

    public function testHydrateNullableBackedEnumCastsScalar()
    {
        $o = deepclone_hydrate(WithBackedEnums::class, ['ns' => 'S']);
        $this->assertSame(DeepCloneHydrateSuit::Spades, $o->ns);
    }

    public function testHydrateUnknownEnumValueThrows()
    {
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('not a valid backing value for enum');
        deepclone_hydrate(WithBackedEnums::class, ['s' => 'X']);
    }

    public function testHydrateEnumCastStillAppliesToNonHookedPropsUnderCallHooks()
    {
        // Per-prop gate: WithBackedEnums::$s has no set hook, so A3 still
        // applies even under CALL_HOOKS.
        $o = deepclone_hydrate(WithBackedEnums::class, ['s' => 'S'], \DEEPCLONE_HYDRATE_CALL_HOOKS);
        $this->assertSame(DeepCloneHydrateSuit::Spades, $o->s);
    }

    /**
     * @requires PHP 8.4
     */
    public function testHydrateEnumCastAppliesToHookedPropUnderCallHooks()
    {
        // Property-type-only rule: the cast is decided from the prop type,
        // not the hook signature. The hook receives the enum case.
        $o = deepclone_hydrate(HookedEnumMatchingParam::class, ['s' => 'S'], \DEEPCLONE_HYDRATE_CALL_HOOKS);
        $this->assertSame(DeepCloneHydrateSuit::Spades, $o->s);
    }

    /**
     * @requires PHP 8.4
     */
    public function testHydrateEnumCastAppliesEvenWhenHookParamIsWider()
    {
        // Wider hook signature `set(Suit|string $v)` doesn't change the
        // hydrate decision: cast first, hook receives the enum case via
        // its non-string union arm.
        $o = deepclone_hydrate(HookedEnumWiderParam::class, ['s' => 'S'], \DEEPCLONE_HYDRATE_CALL_HOOKS);
        $this->assertSame(DeepCloneHydrateSuit::Spades, $o->s);
        $this->assertNull(HookedEnumWiderParam::$lastRaw);
    }

    /**
     * @requires PHP 8.4
     * @requires extension bcmath
     */
    public function testRoundTripBcMathNumber()
    {
        // BcMath\Number is a final internal class with a custom create_object,
        // so newInstanceWithoutConstructor() is rejected and an empty O:
        // unserialize is refused by __unserialize(). The round-trip must still
        // reconstruct it through a full serialization replay.
        $n = new \BcMath\Number('12.34');
        $o = (object) ['a' => $n, 'b' => $n, 'list' => [$n, new \BcMath\Number('5')]];

        $c = deepclone_from_array(deepclone_to_array($o));

        $this->assertInstanceOf(\BcMath\Number::class, $c->a);
        $this->assertSame('12.34', (string) $c->a);
        $this->assertSame(2, $c->a->scale);
        $this->assertNotSame($n, $c->a, 'is a real clone, not the original instance');
        $this->assertSame($c->a, $c->b, 'shared identity is preserved');
        $this->assertSame($c->a, $c->list[0], 'shared identity is preserved across the graph');
        $this->assertSame('5', (string) $c->list[1]);
    }

    /**
     * @requires PHP 8.4
     * @requires extension bcmath
     */
    public function testRoundTripBcMathNumberTopLevel()
    {
        $c = deepclone_from_array(deepclone_to_array(new \BcMath\Number('99.999')));

        $this->assertInstanceOf(\BcMath\Number::class, $c);
        $this->assertSame('99.999', (string) $c);
        $this->assertSame(3, $c->scale);
        $this->assertSame('100.499', (string) $c->add('0.5'));
    }

    /**
     * @requires PHP 8.4
     * @requires extension bcmath
     */
    public function testHydrateBcMathNumberThrows()
    {
        $this->skipIfExtensionRejectsClassesDifferently();

        // deepclone_hydrate() injects properties into an empty shell; a class
        // that only becomes valid through __construct()/__unserialize() cannot
        // be built that way and must be rejected rather than yielding a broken
        // (uninitialized) instance.
        $this->expectException(\DeepClone\NotInstantiableException::class);
        $this->expectExceptionMessage('Type "BcMath\Number" is not instantiable.');
        deepclone_hydrate(\BcMath\Number::class, ['value' => '7.5']);
    }

    /**
     * @requires PHP 8.2
     */
    public function testRoundTripRandomizerAsObjectProperty()
    {
        // Random\Randomizer is a final internal class whose __serialize() nests
        // its engine object, so its deep-clone state carries an object-ref mask
        // and it cannot be built as an early empty shell. Used as a property it
        // must still round-trip: it is finalized once the engine it references
        // exists, before references to it are resolved.
        $seed = 1234;
        $expected = (new \Random\Randomizer(new \Random\Engine\Mt19937($seed)))->getInt(1, \PHP_INT_MAX);

        $g = (object) ['r' => new \Random\Randomizer(new \Random\Engine\Mt19937($seed))];
        $c = deepclone_from_array(deepclone_to_array($g));

        $this->assertInstanceOf(\Random\Randomizer::class, $c->r);
        $this->assertSame($expected, $c->r->getInt(1, \PHP_INT_MAX));
    }

    /**
     * @requires PHP 8.2
     */
    public function testRoundTripRandomizerTopLevelAndNested()
    {
        $top = deepclone_from_array(deepclone_to_array(new \Random\Randomizer(new \Random\Engine\Mt19937(7))));
        $this->assertInstanceOf(\Random\Randomizer::class, $top);

        $arr = deepclone_from_array(deepclone_to_array([new \Random\Randomizer(new \Random\Engine\Mt19937(8))]));
        $this->assertInstanceOf(\Random\Randomizer::class, $arr[0]);

        $deep = deepclone_from_array(deepclone_to_array((object) ['list' => [(object) ['r' => new \Random\Randomizer(new \Random\Engine\Mt19937(9))]]]));
        $this->assertInstanceOf(\Random\Randomizer::class, $deep->list[0]->r);
    }

    /**
     * @requires PHP 8.2
     */
    public function testRoundTripRandomizerWithEnginePointingBack()
    {
        $engine = new DeepCloneCountingEngine();
        $engine->count = 3;
        $engine->owner = new \Random\Randomizer($engine);

        $c = deepclone_from_array(deepclone_to_array($engine->owner));

        $this->assertSame($c, $c->engine->owner);
        $this->assertSame(3, $c->engine->count);
        $c->nextInt();
        $this->assertSame(4, $c->engine->count);
    }

    /**
     * @requires PHP 8.2
     */
    public function testRoundTripRandomizersSharingTheirEngine()
    {
        $engine = new DeepCloneCountingEngine();
        $engine->count = 3;

        $c = deepclone_from_array(deepclone_to_array([new \Random\Randomizer($engine), $engine, new \Random\Randomizer($engine)]));

        $this->assertSame($c[1], $c[0]->engine);
        $this->assertSame($c[1], $c[2]->engine);
        $this->assertSame(3, $c[1]->count);
    }

    /**
     * @requires PHP 8.2
     */
    public function testRoundTripRandomizerBehindReference()
    {
        $engine = new DeepCloneCountingEngine();
        $r = new \Random\Randomizer($engine);
        $engine->owner = &$r;

        $c = deepclone_from_array(deepclone_to_array([&$r]));

        $this->assertInstanceOf(\Random\Randomizer::class, $c[0]);
        $this->assertSame($c[0], $c[0]->engine->owner);
        $engine = $c[0]->engine;
        $c[0] = 1;
        $this->assertSame(1, $engine->owner);
    }

    /**
     * @group legacy
     */
    public function testRoundTripHashContextWithDynamicPropertiesPointingBack()
    {
        $h = hash_init('md5');
        hash_update($h, 'abc');
        $o = new \stdClass();
        $o->h = $h;
        $list = [$o];
        $h->o = $o;
        $h->a = &$list;
        $h->b = &$list;

        $c = deepclone_from_array(deepclone_to_array($h));

        $this->assertSame($c, $c->o->h);
        $this->assertSame([$c->o], $c->a);
        $c->a = 2;
        $this->assertSame(2, $c->b);
        $this->assertSame(md5('abc'), hash_final($c));
    }

    public function testFromArrayRejectsUnserializeClassWithoutReplayFlag()
    {
        // A class with __unserialize() is always emitted as a negative-wakeup
        // state replay. A crafted payload that clears that flag and drops the
        // replay would leave the object uninitialized (e.g. a BcMath\Number
        // with a NULL bc_num), so it is rejected rather than reconstructed,
        // matching the extension.
        $d = deepclone_to_array(new DeepCloneSerializeFixture('x', 1));
        $d['objectMeta'][0][1] = 0; // clear the __unserialize flag
        $d['states'] = [];          // drop the replay

        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('has an __unserialize() method but "objectMeta" does not flag it for an __unserialize state');
        deepclone_from_array($d);
    }

    /**
     * @requires PHP 8.5
     */
    public function testToArrayConstExprClosureClassAttributeWireFormat()
    {
        $closure = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprClosureFixture::class, '', 0, 0, $line], $d['prepared']);
        $this->assertSame(1, $d['mask']);
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureClassAttributeRebindsScope()
    {
        $closure = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];

        $clone = deepclone_from_array(deepclone_to_array($closure));

        $this->assertInstanceOf(\Closure::class, $clone);
        $this->assertNotSame($closure, $clone);
        $this->assertSame('class-secret', $clone());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureNestedAttributeArgument()
    {
        $closure = (new \ReflectionProperty(ConstExprClosureFixture::class, 'tagged'))->getAttributes()[0]->getArguments()['cb'][1]['x'];
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprClosureFixture::class, '$tagged', 0, 0, $line], $d['prepared']);
        $this->assertSame(6, deepclone_from_array($d)(3));
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureMultipleClosuresInOneAttribute()
    {
        $args = (new \ReflectionClassConstant(ConstExprClosureFixture::class, 'TAGGED'))->getAttributes()[0]->getArguments();

        foreach (['multi-0', 'multi-1'] as $i => $expected) {
            $line = (new \ReflectionFunction($args[$i]))->getStartLine();
            $d = deepclone_to_array($args[$i]);

            $this->assertSame([ConstExprClosureFixture::class, 'TAGGED', 0, $i, $line], $d['prepared']);
            $this->assertSame($expected, deepclone_from_array($d)());
        }
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureRepeatedAttribute()
    {
        $closure = (new \ReflectionMethod(ConstExprClosureFixture::class, 'tagged'))->getAttributes()[1]->getArguments()[0];
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprClosureFixture::class, 'tagged()', 1, 0, $line], $d['prepared']);
        $this->assertSame('repeated', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureParameterAttribute()
    {
        $closure = (new \ReflectionMethod(ConstExprClosureFixture::class, 'tagged'))->getParameters()[0]->getAttributes()[0]->getArguments()[0];
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprClosureFixture::class, 'tagged()#0', 0, 0, $line], $d['prepared']);
        $this->assertSame('param-attr', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureParameterDefault()
    {
        $closure = (new \ReflectionMethod(ConstExprClosureFixture::class, 'tagged'))->getParameters()[0]->getDefaultValue();
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprClosureFixture::class, 'tagged()#0', null, 0, $line], $d['prepared']);
        $this->assertSame('param-default', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosurePropertyDefault()
    {
        $closure = (new \ReflectionProperty(ConstExprClosureFixture::class, 'factory'))->getDefaultValue();
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprClosureFixture::class, '$factory', null, 0, $line], $d['prepared']);
        $this->assertSame('prop-default', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripObjectWithClosurePropertyDefault()
    {
        $o = new ConstExprClosureFixture();
        $o->tagged = 'changed';

        $d = deepclone_to_array($o);

        $this->assertSame(['stdClass' => ['tagged' => ['changed']]], $d['properties']);

        $clone = deepclone_from_array($d);

        $this->assertSame('changed', $clone->tagged);
        $this->assertSame('prop-default', ($clone->factory)());
        $this->assertSame('prop-default', (deepclone_hydrate(ConstExprClosureFixture::class)->factory)());

        $o->factory = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];

        $this->assertSame('class-secret', (deepclone_from_array(deepclone_to_array($o))->factory)());

        $o = new ConstExprStdClassFixture();
        $o->dynamic = 1;

        $this->assertSame('std-default', (deepclone_from_array(deepclone_to_array($o))->factory)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureStaticPropertyDefault()
    {
        $closure = (new \ReflectionProperty(ConstExprClosureFixture::class, 'staticFactory'))->getDefaultValue();
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprClosureFixture::class, '$staticFactory', null, 0, $line], $d['prepared']);
        $this->assertSame('static-prop-default', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureClassConstantValue()
    {
        $closure = ConstExprClosureFixture::CALLBACKS['first'];
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprClosureFixture::class, 'CALLBACKS', null, 0, $line], $d['prepared']);
        $this->assertSame('const-value', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureEnumCaseAttribute()
    {
        $closure = (new \ReflectionClassConstant(ConstExprEnumFixture::class, 'Active'))->getAttributes()[0]->getArguments()[0];
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprEnumFixture::class, 'Active', 0, 0, $line], $d['prepared']);
        $this->assertSame('enum-case-attr', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureEnumConstant()
    {
        $closure = ConstExprEnumFixture::FILTER;
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprEnumFixture::class, 'FILTER', null, 0, $line], $d['prepared']);
        $this->assertSame('enum-const', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureTraitMethodAttribute()
    {
        $closure = (new \ReflectionClass(ConstExprTraitUserFixture::class))->getMethod('traitTagged')->getAttributes()[0]->getArguments()[0];

        $d = deepclone_to_array($closure);

        $this->assertSame(ConstExprTraitUserFixture::class, $d['prepared'][0]);
        $this->assertSame('trait-attr', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosurePromotedParameterAttribute()
    {
        $closure = (new \ReflectionProperty(ConstExprPromotedFixture::class, 'promoted'))->getAttributes()[0]->getArguments()[0];
        $line = (new \ReflectionFunction($closure))->getStartLine();

        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprPromotedFixture::class, '__construct()#0', 0, 0, $line], $d['prepared']);
        $this->assertSame('promoted-attr', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureSameLineDistinctSignatures()
    {
        $args = (new \ReflectionClass(ConstExprSameLineFixture::class))->getAttributes()[0]->getArguments();

        $this->assertSame('noargs', deepclone_from_array(deepclone_to_array($args[0]))());
        $this->assertSame('witharg', deepclone_from_array(deepclone_to_array($args[1]))(1));
    }

    /**
     * @requires PHP 8.5
     */
    public function testToArrayConstExprClosureAmbiguousSameLineSites()
    {
        foreach (['attributeAndDefault' => 'default', 'twoDefaults' => 'b'] as $method => $expected) {
            $closure = (new ConstExprSameLineSitesFixture())->$method();

            if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills) {
                // The extension tells same-line closures apart by op_array identity.
                $this->assertSame($expected, deepclone_from_array(deepclone_to_array($closure))());
                continue;
            }

            // The polyfill could otherwise resolve them to the first closure of the line
            try {
                deepclone_to_array($closure);
                $this->fail('ValueError expected.');
            } catch (\ValueError $e) {
                $this->assertStringContainsString('multiple closures share this declaration site', $e->getMessage());
            }
        }
    }

    /**
     * @requires PHP 8.5
     */
    public function testToArrayConstExprClosureAmbiguousSameLine()
    {
        $args = (new \ReflectionClass(ConstExprAmbiguousFixture::class))->getAttributes()[0]->getArguments();

        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills) {
            // The extension tells same-line closures apart by op_array identity.
            $this->assertSame('first', deepclone_from_array(deepclone_to_array($args[0]))());
            $this->assertSame('second', deepclone_from_array(deepclone_to_array($args[1]))());

            return;
        }

        // The polyfill only knows file/line/signature, which cannot tell them apart.
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('multiple closures share this declaration site');
        deepclone_to_array($args[0]);
    }

    /**
     * @requires PHP 8.5
     */
    public function testToArrayRuntimeStaticClosureIsNotInstantiable()
    {
        $closure = static function (): string { return 'runtime'; };

        $this->expectException(\DeepClone\NotInstantiableException::class);
        $this->expectExceptionMessage('Type "Closure" is not instantiable.');
        deepclone_to_array($closure);
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureInsideObjectGraph()
    {
        $classClosure = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];
        $propClosure = (new \ReflectionProperty(ConstExprClosureFixture::class, 'tagged'))->getAttributes()[0]->getArguments()['cb'][1]['x'];
        $graph = new ConstraintLikeFixture($classClosure, [new ConstraintLikeFixture($propClosure)]);

        $clone = deepclone_from_array(deepclone_to_array($graph));

        $this->assertInstanceOf(ConstraintLikeFixture::class, $clone);
        $this->assertInstanceOf(\Closure::class, $clone->callback);
        $this->assertSame('class-secret', ($clone->callback)());
        $this->assertSame(6, ($clone->constraints[0]->callback)(3));
    }

    /**
     * @requires PHP 8.5
     */
    public function testConstExprClosurePayloadSurvivesJsonRoundTrip()
    {
        $closure = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];
        $graph = new ConstraintLikeFixture($closure);

        $d = json_decode(json_encode(deepclone_to_array($graph)), true);

        $this->assertSame('class-secret', (deepclone_from_array($d)->callback)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testFromArrayConstExprClosureStaleLineThrows()
    {
        $closure = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];
        $d = deepclone_to_array($closure);
        ++$d['prepared'][4];

        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('stale payload');
        deepclone_from_array($d);
    }

    /**
     * @requires PHP 8.5
     */
    public function testToArrayAllowedClassesRejectsConstExprClosure()
    {
        $closure = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];

        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"Closure" is not allowed');
        deepclone_to_array($closure, []);
    }

    /**
     * @requires PHP 8.5
     */
    public function testFromArrayAllowedClassesRejectsConstExprClosureInMask()
    {
        $closure = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];
        $d = deepclone_to_array($closure);

        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('"Closure" is not allowed');
        deepclone_from_array($d, []);
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureWithAllowedClasses()
    {
        $closure = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];

        $clone = deepclone_from_array(deepclone_to_array($closure, ['Closure']), ['Closure', ConstExprClosureFixture::class]);

        $this->assertSame('class-secret', $clone());
    }

    /**
     * @requires PHP 8.5
     */
    public function testFromArrayConstExprClosureClassMustBeAllowed()
    {
        $closure = (new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0];
        $d = deepclone_to_array($closure, ['Closure']);

        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('class "'.ConstExprClosureFixture::class.'" is not allowed');
        deepclone_from_array($d, ['Closure']);
    }

    /**
     * @requires PHP 8.5
     */
    public function testToArrayConstExprClosureAllowedGatePrecedesAmbiguity()
    {
        $closure = (new \ReflectionClass(ConstExprAmbiguousFixture::class))->getAttributes()[0]->getArguments()[0];

        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('class "Closure" is not allowed');
        deepclone_to_array($closure, []);
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureFactoryConstant()
    {
        $outer = ConstExprFactoryFixture::FACTORY;

        $this->assertSame('inner', deepclone_from_array(deepclone_to_array($outer))()());

        $this->expectException(\DeepClone\NotInstantiableException::class);
        deepclone_to_array($outer());
    }

    /**
     * @requires PHP 8.5
     */
    public function testToArrayRuntimeClosureCollidingWithConstExprSite()
    {
        $attrClosure = (new \ReflectionMethod(ConstExprRuntimeCollisionFixture::class, 'make'))->getAttributes()[0]->getArguments()[0];

        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills) {
            // The extension tells the attribute literal and the same-line runtime
            // literal apart by op_array identity.
            $this->assertSame('const-expr', deepclone_from_array(deepclone_to_array($attrClosure))());

            $this->expectException(\DeepClone\NotInstantiableException::class);
            deepclone_to_array(ConstExprRuntimeCollisionFixture::make());

            return;
        }

        // Both closures share the method-derived name, line and signature; the
        // polyfill cannot tell them apart and refuses both.
        try {
            deepclone_to_array($attrClosure);
            $this->fail('Expected ValueError was not thrown');
        } catch (\ValueError $e) {
            $this->assertStringContainsString('multiple closures share this declaration site', $e->getMessage());
        }
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('multiple closures share this declaration site');
        deepclone_to_array(ConstExprRuntimeCollisionFixture::make());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureEvaluatedThroughTwoSurfaces()
    {
        $closure = (new ConstExprDualSurfaceFixture())->cb;

        $this->assertSame('dual-surface', deepclone_from_array(deepclone_to_array($closure))());
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosureAliasedTraitMethod()
    {
        $closure = (new \ReflectionMethod(ConstExprTraitAliasFixture::class, 'traitTagged'))->getAttributes()[0]->getArguments()[0];

        $this->assertSame('trait-attr', deepclone_from_array(deepclone_to_array($closure))());
    }

    /**
     * @requires PHP 8.5
     */
    public function testToArrayConstExprClosureWithoutSourcesInvitesExtension()
    {
        if (!class_exists('ConstExprNoSourcesFixture', false)) {
            $file = sys_get_temp_dir().'/ConstExprNoSourcesFixture.php';
            file_put_contents($file, '<?php class ConstExprNoSourcesFixture { #[Symfony\\Polyfill\\Tests\\DeepClone\\ConstExprAttr(static function (): string { return "no-sources"; })] public function m(): void {} }');
            require $file;
            unlink($file);
        }
        $closure = (new \ReflectionMethod(\ConstExprNoSourcesFixture::class, 'm'))->getAttributes()[0]->getArguments()[0];

        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills) {
            // The extension matches op_arrays and needs no source files.
            $this->assertSame('no-sources', deepclone_from_array(deepclone_to_array($closure))());

            return;
        }

        // Method-scoped names require reading the file to rule out aliasing.
        $this->expectException(\ValueError::class);
        $this->expectExceptionMessage('install the "deepclone" extension');
        deepclone_to_array($closure);
    }

    /**
     * @requires PHP 8.5
     */
    public function testRoundTripConstExprClosurePropertyHookAttributes()
    {
        $closure = (new \ReflectionProperty(ConstExprHookedFixture::class, 'virtual'))->getHook(\PropertyHookType::Get)->getAttributes()[0]->getArguments()[0];
        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprHookedFixture::class, '$virtual::get()', 0, 0, (new \ReflectionFunction($closure))->getStartLine()], $d['prepared']);
        $this->assertSame('get-hook-attr', deepclone_from_array($d)());

        $closure = (new \ReflectionProperty(ConstExprHookedFixture::class, 'stored'))->getHook(\PropertyHookType::Set)->getParameters()[0]->getAttributes()[0]->getArguments()[0];
        $d = deepclone_to_array($closure);

        $this->assertSame([ConstExprHookedFixture::class, '$stored::set()#0', 0, 0, (new \ReflectionFunction($closure))->getStartLine()], $d['prepared']);
        $this->assertSame('set-hook-param-attr', deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testFromArrayConstExprClosureMalformedPayloads()
    {
        $line = (new \ReflectionFunction((new \ReflectionClass(ConstExprClosureFixture::class))->getAttributes()[0]->getArguments()[0]))->getStartLine();
        $cases = [
            ['foo', 'const-expr-closure value must be of type array, string given'],
            [[ConstExprClosureFixture::class], 'const-expr-closure value must have 5 elements'],
            [[42, '', 0, 0, $line], 'const-expr-closure class name must be of type string, int given'],
            [['No\\Such\\ClassAtAll', '', 0, 0, $line], 'const-expr-closure references unknown class "No\\Such\\ClassAtAll"'],
            [[ConstExprClosureFixture::class, 42, 0, 0, $line], 'const-expr-closure site must be of type string, int given'],
            [[ConstExprClosureFixture::class, '', 'x', 0, $line], 'const-expr-closure attribute index must be of type int or null, string given'],
            [[ConstExprClosureFixture::class, '', 0, 'x', $line], 'const-expr-closure closure index must be of type int, string given'],
            [[ConstExprClosureFixture::class, '', 0, 0, 'x'], 'const-expr-closure line must be of type int, string given'],
            [[ConstExprClosureFixture::class, '$nope', 0, 0, $line], 'const-expr-closure references unknown property "$nope"'],
            [[ConstExprClosureFixture::class, 'nope()', 0, 0, $line], 'const-expr-closure references unknown method "nope()"'],
            [[ConstExprClosureFixture::class, 'NOPE', 0, 0, $line], 'const-expr-closure references unknown constant "NOPE"'],
            [[ConstExprClosureFixture::class, 'tagged()#9', 0, 0, $line], 'const-expr-closure references unknown parameter "tagged()#9"'],
            [[ConstExprClosureFixture::class, '', 9, 0, $line], 'const-expr-closure references unknown attribute index 9'],
            [[ConstExprClosureFixture::class, '', 0, 9, $line], 'const-expr-closure references unknown closure index 9'],
            [[ConstExprClosureFixture::class, '', null, 0, $line], 'const-expr-closure attribute index is required for site ""'],
            [[ConstExprClosureFixture::class, 'tagged()', null, 0, $line], 'const-expr-closure attribute index is required for site "tagged()"'],
        ];

        foreach ($cases as [$prepared, $expected]) {
            try {
                deepclone_from_array(['classes' => '', 'objectMeta' => 0, 'prepared' => $prepared, 'mask' => 1]);
                $this->fail('Expected ValueError was not thrown for: '.$expected);
            } catch (\ValueError $e) {
                $this->assertStringContainsString($expected, $e->getMessage());
            }
        }
    }

    /**
     * @requires PHP 8.5
     */
    public function testToArrayConstExprClosureFirstClassCallableUsesDeclarationSite()
    {
        // A first-class callable over a method of its own declaring class,
        // declared in a constant expression, is encoded as a declaration-site
        // reference (mask 1) like an anonymous const-expr closure, not by name,
        // so it round-trips without the allow_named_closures opt-in.
        $closure = (new \ReflectionMethod(ConstExprFccFixture::class, 'helper'))->getAttributes()[0]->getArguments()[0];

        $d = deepclone_to_array($closure);

        $this->assertSame(1, $d['mask']);
        $this->assertSame(ConstExprFccFixture::class, $d['prepared'][0]);
        $this->assertTrue(deepclone_from_array($d)());
    }

    /**
     * @requires PHP 8.5
     */
    public function testFromArrayConstExprClosureGlobalInternalFunction()
    {
        // The extension can reference a global internal function declared in an
        // attribute (e.g. #[ConstExprAttr(strlen(...))]); such a reference has
        // no start line and is encoded with line 0. The polyfill cannot produce
        // these (no reflection hook), but must decode them: ReflectionFunction
        // reports no start line for an internal function, so the line-0
        // reference must not be treated as stale.
        $payload = ['classes' => '', 'objectMeta' => 0, 'prepared' => [ConstExprGlobalFccFixture::class, '$p', 0, 0, 0], 'mask' => 1];

        $r = deepclone_from_array($payload);
        $this->assertSame(5, $r('hello'));
    }

    private function skipIfExtensionKeepsLazyObjectsUninitialized(): void
    {
        if (\extension_loaded('deepclone') && !TestListenerTrait::$enabledPolyfills && version_compare(phpversion('deepclone'), '0.8.4', '<')) {
            $this->markTestSkipped('ext-deepclone < 0.8.4 does not initialize lazy objects in deepclone_to_array().');
        }
    }
}
