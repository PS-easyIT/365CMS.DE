<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Polyfill\Tests\DeepClone;

enum DeepCloneColor
{
    case Red;
    case Blue;
}

enum DeepCloneSuit: string
{
    case Hearts = 'H';
    case Spades = 'S';
}

class NamedClosureBase
{
    private $secret = 'base';

    public static function create()
    {
        return static::class;
    }

    public function reveal()
    {
        return $this->secret;
    }

    protected function prot()
    {
        return static::class;
    }

    public function getProt(): \Closure
    {
        return $this->prot(...);
    }
}

class NamedClosureChild extends NamedClosureBase
{
}

class NamedClosureMagic
{
    public function __call($name, $args)
    {
        return 'call '.$name;
    }

    public static function __callStatic($name, $args)
    {
        return 'static '.$name.' '.static::class;
    }
}

class ClosureFixture
{
    public function instanceMethod(): string
    {
        return 'instance';
    }

    public static function staticMethod(): string
    {
        return 'static';
    }

    private function privateMethod(): string
    {
        return 'private';
    }

    public function getPrivateClosure(): \Closure
    {
        return \Closure::fromCallable([$this, 'privateMethod']);
    }
}

class DeepCloneFinalError extends \Error
{
}

class DeepCloneDatePeriod extends \DatePeriod
{
    public $label;
    public $self;
}

class DeepCloneSerializeFixture
{
    public function __construct(public string $name = '', public int $val = 0)
    {
    }

    public function __serialize(): array
    {
        return ['n' => $this->name, 'v' => $this->val];
    }

    public function __unserialize(array $data): void
    {
        $this->name = $data['n'];
        $this->val = $data['v'];
    }
}

class DeepCloneWakeupFixture
{
    public string $status = 'sleeping';

    public function __wakeup(): void
    {
        $this->status = 'awake';
    }
}

class DeepCloneSleepFixture
{
    public string $keep = '';
    public string $skip = '';

    public function __sleep(): array
    {
        return ['keep'];
    }
}

class DeepCloneParentNoUnser
{
    private string $foo = 'foo';
}

class DeepCloneChildNoUnser extends DeepCloneParentNoUnser
{
    public string $baz = '';
    private string $bar = '';

    public function __serialize(): array
    {
        return ['foo' => 'foo', 'baz' => 'ccc', 'bar' => 'ddd'];
    }
}

class DeepCloneUnserOnly
{
    public string $foo = '';

    public function __unserialize(array $data): void
    {
        $this->foo = $data['foo'] ?? '';
    }
}

class DeepCloneSleepPrivate
{
    public string $good = '';
    protected string $foo = '';
    private string $bar = '';

    public function __sleep(): array
    {
        return ['good', 'foo', "\0*\0foo", "\0".self::class."\0bar"];
    }

    public function setAll(string $g, string $f, string $b): void
    {
        $this->good = $g;
        $this->foo = $f;
        $this->bar = $b;
    }
}

class DeepCloneParentSleep
{
    private string $secret = '';

    public function setSecret(string $secret): void
    {
        $this->secret = $secret;
    }
}

class DeepCloneChildSleep extends DeepCloneParentSleep
{
    public string $pub = '';

    // __sleep returns unmangled "secret" — should NOT match parent's private.
    public function __sleep(): array
    {
        return ['pub', 'secret'];
    }
}

class DeepCloneSleepBase
{
    private $secret = 'default';

    public function setBaseSecret($secret): void
    {
        $this->secret = $secret;
    }
}

class DeepCloneSleepSamePrivate extends DeepCloneSleepBase
{
    private $secret = 'default';

    public function setSecret($secret): void
    {
        $this->secret = $secret;
    }

    public function __sleep(): array
    {
        return ['secret', "\0".DeepCloneSleepBase::class."\0secret"];
    }
}

class DeepCloneSleepMiddle extends DeepCloneSleepBase
{
}

class DeepCloneSleepGrandparentPrivate extends DeepCloneSleepMiddle
{
    public function __sleep(): array
    {
        return ['secret', "\0".DeepCloneSleepBase::class."\0secret"];
    }
}

class DeepCloneSleepMissingMangled
{
    public $pub = 'default';

    public function __sleep(): array
    {
        return ['pub', "\0*\0nope"];
    }
}

class DeepCloneSleepNames
{
    public $a = 'default';
    protected $b = 'default';
    private $c = 'default';
    public int $typed;
    public $names = [];

    public function set($value): void
    {
        $this->a = $this->b = $this->c = $value;
    }

    public function __sleep(): array
    {
        return $this->names;
    }
}

#[\AllowDynamicProperties]
class DeepCloneSleepDynamic
{
    public $a = 'default';
    public $names = [];

    public function __sleep(): array
    {
        return $this->names;
    }
}

class DeepCloneSleepUnserialize extends DeepCloneSleepNames
{
    public $keys;

    public function __unserialize(array $data): void
    {
        $this->keys = strtr(implode(',', array_keys($data)), ["\0" => '~']);
    }
}

class DeepCloneSleepNotArray
{
    public function __sleep()
    {
        return 'nope';
    }
}

#[\AllowDynamicProperties]
class DeepCloneSerializeKeys
{
    private $b = 'default';
    protected $p = 'default';
    public $pub = 'default';
    public $data = [];

    public function __serialize(): array
    {
        return $this->data;
    }
}

class DeepCloneOrderNode
{
    public $next;
    public $data;
}

class DeepCloneParentClass
{
    public string $pub = 'pub_default';
    protected int $prot = 0;
    private string $priv = 'parent_priv';

    public function setProt(int $v): void
    {
        $this->prot = $v;
    }

    public function setPriv(string $v): void
    {
        $this->priv = $v;
    }
}

class DeepCloneChildClass extends DeepCloneParentClass
{
    private string $childPriv = 'child_default';

    public function setChildPriv(string $v): void
    {
        $this->childPriv = $v;
    }
}

class DeepCloneReadonlyFixture
{
    public function __construct(
        public readonly string $name,
        public readonly int $value,
    ) {
    }
}

class HydrateFoo
{
    protected $prot;
    private $priv;
    public readonly int $ro;
}

#[\AllowDynamicProperties]
class HydrateBar extends HydrateFoo
{
    private $priv;
}

#[\AllowDynamicProperties]
class DeepCloneNumericHolder
{
    public int $a = 1;
}

class CacheIsolationParent
{
    private string $priv = 'def';

    public function getPriv(): string
    {
        return $this->priv;
    }

    public function setPriv(string $v): void
    {
        $this->priv = $v;
    }
}

class CacheIsolationChild extends CacheIsolationParent
{
    public string $pub = '';
}

abstract class AbstractScopeBase
{
    public string $sourceEntity;
    public string $mappedBy;
    private string $secret = 'def';

    public function __sleep(): array
    {
        return ['sourceEntity', 'mappedBy'];
    }

    public function setSecret(string $v): void
    {
        $this->secret = $v;
    }
}

class AbstractScopeChild extends AbstractScopeBase
{
    public function __construct(string $src)
    {
        $this->sourceEntity = $src;
    }
}

class AllowedParent
{
    private string $secret = '';

    public function getSecret(): string
    {
        return $this->secret;
    }
}

class AllowedChild extends AllowedParent
{
    public string $pub = '';
}

abstract class AbstractWithPrivate
{
    private string $secret = 'default';

    public function set(string $v): void
    {
        $this->secret = $v;
    }

    public function get(): string
    {
        return $this->secret;
    }
}

class AbstractWithPrivateChild extends AbstractWithPrivate
{
    public string $pub = '';
}

class HydrateBase
{
    private string $secret = '';

    public function getSecret(): string
    {
        return $this->secret;
    }
}

class HydrateChild extends HydrateBase
{
    protected int $num = 0;
    public string $pub = '';

    public function getNum(): int
    {
        return $this->num;
    }
}

class HydrateReadonly
{
    public string $status = 'new';
    private readonly int $value;

    public function __construct(int $value)
    {
        $this->value = $value;
    }

    public function getValue(): int
    {
        return $this->value;
    }
}

class HydrateReadonlyObject
{
    public function __construct(public readonly \stdClass $o)
    {
    }
}

class HydrateNullableInt
{
    public ?int $y = 7;
}

class HydrateGP
{
    private string $secret = '';

    public function getSecret(): string
    {
        return $this->secret;
    }
}

class HydrateP extends HydrateGP
{
    private int $mid = 0;

    public function getMid(): int
    {
        return $this->mid;
    }
}

class HydrateC extends HydrateP
{
    public string $pub = '';
}

enum HydrateColor
{
    case Red;
}

trait HydrateTrait
{
}

enum DeepCloneHydrateSuit: string
{
    case Hearts = 'H';
    case Spades = 'S';
}
enum DeepCloneHydrateSize: int
{
    case Small = 1;
    case Large = 2;
}

class WithBackedEnums
{
    public DeepCloneHydrateSuit $s = DeepCloneHydrateSuit::Hearts;
    public ?DeepCloneHydrateSuit $ns = DeepCloneHydrateSuit::Hearts;
    public DeepCloneHydrateSize $n = DeepCloneHydrateSize::Small;
}

class TypedInt
{
    public int $x = 0;
}

class TypedReadonly
{
    public readonly int $v;
}

class PrivShadowA
{
    private string $x = 'a_init';

    public function get(): string
    {
        return $this->x;
    }
}

class PrivShadowB extends PrivShadowA
{
    private string $x = 'b_init';

    public function getChild(): string
    {
        return $this->x;
    }
}

class ScopeParent
{
    public int $pub = 0;
}

class ScopeChild extends ScopeParent
{
    protected int $sealed = 0;
    public int $child = 0;
}

class DeepCloneLazyBase
{
    private string $secret = 'default';

    public function __construct(public string $value = '')
    {
    }

    public function setSecret(string $secret): void
    {
        $this->secret = $secret;
    }

    public function getSecret(): string
    {
        return $this->secret;
    }
}

class DeepCloneLazyChild extends DeepCloneLazyBase
{
}

class DeepCloneLazyNode
{
    public ?DeepCloneLazyNode $next = null;

    public function __construct(public string $name, public ?\Closure $cb = null)
    {
    }
}

class DeepCloneFileInfoSleep extends \SplFileInfo
{
    public function __sleep(): array
    {
        return [];
    }
}

class DeepCloneFileInfoWakeup extends \SplFileInfo
{
    public function __wakeup(): void
    {
    }
}

class DeepCloneFileInfoSerialize extends \SplFileInfo
{
    public function __serialize(): array
    {
        return ['path' => $this->getPathname()];
    }

    public function __unserialize(array $data): void
    {
        parent::__construct($data['path']);
    }
}

interface DeepCloneInterface
{
}

class DeepCloneIteratorIterator extends \IteratorIterator
{
    public $a;
    private $b;

    public function getB()
    {
        return $this->b;
    }
}

class DeepCloneIteratorIteratorWithWakeup extends \IteratorIterator
{
    public $a;

    public function __wakeup(): void
    {
    }
}

class DeepCloneWakeupThrows
{
    public function __wakeup(): void
    {
        throw new \LogicException('Cannot wake up.');
    }
}

if (\PHP_VERSION_ID >= 80400) {
    eval(<<<'PHP'
namespace Symfony\Polyfill\Tests\DeepClone;

class HookedProps {
    private int $backing = 0;
    public int $x {
        get => $this->backing;
        set(int $value) { $this->backing = $value + 1; }
    }
}

class HookedBackingProps {
    public int $x = 0 {
        set(int $value) { $this->x = $value * 10; }
    }
}

class HookedEnumMatchingParam {
    public DeepCloneHydrateSuit $s = DeepCloneHydrateSuit::Hearts {
        set(DeepCloneHydrateSuit $value) { $this->s = $value; }
    }
}

class HookedEnumWiderParam {
    public static ?string $lastRaw = null;
    public DeepCloneHydrateSuit $s = DeepCloneHydrateSuit::Hearts {
        set(DeepCloneHydrateSuit|string $value) {
            if (\is_string($value)) {
                self::$lastRaw = 'raw:'.$value;
                $this->s = DeepCloneHydrateSuit::from($value);
            } else {
                $this->s = $value;
            }
        }
    }
}
PHP);
}

class DeepCloneRefHolder
{
    public $a;
    public $b;
    public $other;
}

class DeepCloneRefParent
{
    public $q = 1;
    private $p;

    public function bind(): void
    {
        $this->p = &$this->q;
    }

    public function getP()
    {
        return $this->p;
    }
}

class DeepCloneRefChild extends DeepCloneRefParent
{
}

class DeepCloneTypedRefs
{
    public int $a = 1;
    public int $b = 2;
}

#[\AllowDynamicProperties]
class DeepCloneDynamicRefs
{
    public $declared;
    public $cb;
}

class DeepCloneNoDynamicAttributeRefs
{
}

class DeepCloneSleepRefs
{
    public $x = 1;
    public $y;
    public $z = 'skipped';

    public function __sleep(): array
    {
        return ['x', 'y'];
    }
}

class DeepCloneSleepReadingRefs
{
    public $x;
    public $y;
    public $z;

    public function __sleep(): array
    {
        $this->y = $this->x;

        return ['x', 'z'];
    }
}

class DeepCloneSerializeReadingRefs
{
    public $x;

    public function __serialize(): array
    {
        return ['x' => $this->x];
    }

    public function __unserialize(array $data): void
    {
        $this->x = $data['x'];
    }
}

if (\PHP_VERSION_ID >= 80200) {
    eval(<<<'PHP'
namespace Symfony\Polyfill\Tests\DeepClone;

readonly class DeepCloneReadonlyRefs
{
}
PHP);
}

if (\PHP_VERSION_ID >= 80400) {
    eval(<<<'PHP'
namespace Symfony\Polyfill\Tests\DeepClone;

class DeepCloneVirtualRefs
{
    public int $virtual {
        get => 7;
        set {}
    }
}
PHP);
}

class DeepCloneStateRefs
{
    public $data;

    public function __serialize(): array
    {
        return $this->data;
    }

    public function __unserialize(array $data): void
    {
        $this->data = $data;
    }
}

if (\PHP_VERSION_ID >= 80400) {
    eval(<<<'PHP'
namespace Symfony\Polyfill\Tests\DeepClone;

class DeepCloneHookedParent
{
    private int $secret = 0 {
        set => $value * 10;
    }

    public function setSecret(int $v): void
    {
        $this->secret = $v;
    }

    public function getSecret(): int
    {
        return $this->secret;
    }
}

class DeepCloneHookedChild extends DeepCloneHookedParent
{
    public int $pub = 0 {
        set => $value * 10;
    }

    protected int $prot = 0 {
        set => $value * 10;
    }

    public function setProt(int $v): void
    {
        $this->prot = $v;
    }

    public function getProt(): int
    {
        return $this->prot;
    }
}
PHP);
}

if (\PHP_VERSION_ID >= 80200) {
    final class DeepCloneCountingEngine implements \Random\Engine
    {
        public $owner;
        public $count = 0;

        public function generate(): string
        {
            return pack('P', ++$this->count);
        }
    }
}
