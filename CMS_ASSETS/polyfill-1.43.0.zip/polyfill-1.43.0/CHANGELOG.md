# 1.43.0

  * Add the `UUID_TYPE_TIME_V6`, `UUID_TYPE_TIME_V7`, `UUID_TYPE_VENDOR` and `UUID_TYPE_SECURITY` constants, and create v6 and v7 UUIDs with `uuid_create()`
  * Add `selectordinal` support to the `MessageFormatter` polyfill
  * Update the IDN data to Unicode 15.1
  * Validate charset names before loading their map in the Iconv polyfill
  * Fix `IDNA_CHECK_CONTEXTJ` on labels with several join controls, and reject `xn--` labels that decode to surrogates or code points above U+10FFFF
  * Match the intl extension on ill-formed UTF-8 in the grapheme functions, including `grapheme_strrev()`
  * Fix argument validation, grapheme comparison and memory usage of `grapheme_levenshtein()`
  * Fix `grapheme_strrev()` in standalone installs of symfony/polyfill-php86
  * Fix script and language detection in `locale_is_right_to_left()` and `Locale::isRightToLeft()`
  * Fix `Collator` sorting, English list patterns in `IntlListFormatter`, and number formatting in `MessageFormatter`
  * Fix bcmath number validation in `bcceil()`, `bcfloor()` and `bcround()`
  * Fix edge cases of `str_increment()`, `str_decrement()`, `ini_parse_quantity()`, `json_validate()` and `PhpToken`
  * Fix quoting in `odbc_connection_string_is_quoted()` and `odbc_connection_string_should_quote()`
  * Fix the Mbstring polyfill on ill-formed UTF-8, including endless loops in `mb_convert_case()` and `mb_encode_numericentity()`
  * Fix the Mbstring search functions ignoring their needle, offset or encoding
  * Fix argument validation in `mb_ord()`, `mb_chr()`, `mb_str_split()`, `mb_convert_encoding()` and `mb_check_encoding()`
  * Keep keys and scalar values when `mb_convert_encoding()` converts an array
  * Avoid excessive allocations in `mb_str_pad()`
  * Fix `iconv_substr()`, `iconv_strrpos()` and `//TRANSLIT` without the Normalizer class
  * Name the first parameter of the `Normalizer` methods `$string`, and reject invalid forms in `Normalizer::isNormalized()`
  * Align `uuid_compare()`, `uuid_create()`, `uuid_time()` and `uuid_mac()` with the extension
  * Fix duplicate v1 UUIDs generated in the same microsecond, also across processes sharing APCu
  * Accept extension-provided handles in `Io\Poll`, report `EINTR` like the native backends, and stop busy-waiting
  * Speed up `Io\Poll\Context::wait()`, watcher updates, and `deepclone_to_array()` on large object graphs
  * Align `deepclone_*()` payloads, errors and supported classes with `serialize()` and the extension
  * Preserve PHP references and initialize lazy objects in `deepclone_to_array()`
  * Fix deepcloning objects whose property defaults hold closures, `DatePeriod` on PHP 8.1, and objects held by `Random\Randomizer` or `HashContext`

# 1.42.0

  * Add polyfill for the `Time\Duration` class
  * Take the `Io\Poll\Context::wait()` timeout as a `Time\Duration`
  * Bound the Punycode decoder input length in `idn_to_ascii()`/`idn_to_utf8()`
  * Don't Punycode-encode domains that the intl extension would refuse
  * Fix hydrating from mangled keys when using `deepclone_from_array()`

# 1.41.0

  * Add polyfill for the `Io\Poll` API and `StreamPollHandle`
  * Throw `ValueError` on PHP 7 for `json_validate()`, `str_increment()`, `str_decrement()`, `grapheme_str_split()` and `grapheme_levenshtein()`
  * Reject out-of-range offsets in the `grapheme_str[ri]?pos()` family
  * Align the Php74 `mb_str_split()` polyfill with Mbstring and native

# 1.40.0

  * Gate deepcloning closures over named callables behind an `$allow_named_closures` option
  * Suggest ext-deepclone when refusing a named callable, and decode its global-function references

# 1.39.0

  * Support closures declared in constant expressions
  * Fix round-tripping short-lived `Random\Randomizer` instances on PHP 8.2
  * Reject `deepclone_from_array()` payloads that would build an uninitialized object

# 1.38.2

  * Fix round-tripping objects whose `__serialize()` nests another object
  * Fix round-tripping and hydrating `BcMath\Number`
  * Reject malformed `deepclone_from_array()` input without warnings
  * Fix cloning objects with numeric property names
  * Fix issues with `mb_scrub()`
  * Fix issues with `mb_str_pad()`

# 1.38.1

  * CVE-2026-46644 `idn_to_ascii()`/`idn_to_utf8()`: reject `xn--` labels whose Punycode payload decodes to ASCII-only
  * Fix `grapheme_str_split()` on PCRE 8
  * Fix `mb_str_split()` newline handling in the Php74 polyfill
  * Fix `grapheme_levenshtein()` delegation in the Intl/Grapheme polyfill
  * Make `mb_*` polyfills match the native `string` return type on PHP 8+
  * Fix missing `CURLOPT_ISSUERCERT_BLOB` and `CURLOPT_SSH_HOST_PUBLIC_KEY_SHA256` constants
  * Fix definition of MySQL PDO constants

# 1.38.0

  * Add polyfill for `normalizer_get_raw_decomposition()`
  * Add missing `IntlMessageFormatter::parseMessage()` method
  * Sync currencies metadata with `symfony/intl` data
  * Mark `UUID_TYPE_DCE` and `UUID_TYPE_NAME` as deprecated on PHP 8.5+
  * Validate `MessageFormatter` patterns at configuration time
  * Accept null in `mb_*` polyfills
  * Fall back to plain `iconv()` when `//IGNORE` is unsupported (e.g. on musl)
  * Improve type declarations of some mbstring polyfills
  * Make `mb_convert_encoding($s, $y, 'HTML-ENTITIES')` match native output
  * Update `IntlDateFormatter::__construct()` parameters
  * Fix `grapheme_strrev()` to return false on invalid UTF-8
  * Fix grapheme cluster splitting on PCRE < 10.44
  * Fix `mb_strlen()` for invalid UTF-8 input
  * Fix `mb_rtrim()` missing unicode-awareness
  * Fix `mb_str_pad()` invalid encoding error reporting
  * Fix `str_increment()` for numeric strings beyond `PHP_INT_MAX`
  * Fix `ldap_exop_sync()` polyfill on PHP < 8.3
  * Fix `ReflectionConstant` stub to declare its `$persistent` property
  * Fix detection of `PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT` when PHP is built without it

# 1.37.0

  * Add polyfill for `grapheme_strrev()`
  * Compat with deepclone v0.6.0
  * Fix `locale_is_right_to_left()` registration in polyfill-php85
  * Fix `grapheme_levenshtein()` registration in polyfill-php85

# 1.36.0

  * Polyfill deepclone v0.3.0

# 1.35.0

  * Add polyfill for `deepclone_hydrate()`
  * Add polyfill for `ARRAY_FILTER_USE_VALUE` constant
  * Add polyfill for the `SortDirection` enum
  * Fix cache poisoning in `DeepClone` polyfill

# 1.34.0

  * Add polyfill for the `symfony/deepclone` extension
  * Add polyfill for `clamp()`
  * Add polyfill for `bcround()`, `bcceil()` and `bcfloor()`
  * Add polyfill for `grapheme_levenshtein()`
  * Add polyfill for `#[DelayedTargetValidation]`
  * Add polyfill for `Filter\FilterException` and `Filter\FilterFailedException`
  * Add polyfill for `IntlListFormatter` to ICU polyfill
  * Add polyfill for `locale_is_right_to_left()`
  * Add polyfill for PDO driver specific subclasses
  * Fix PHP 8.5 deprecations
  * Fix ctype deprecations on PHP 8.1+
  * Fix PHP 7.2 compatibility of the `#[Deprecated]` polyfill
  * Fix mbstring polyfill must not raise value errors on PHP 7
  * Fix `bcdiv()` handling of `DivisionByZeroError`

# 1.33.0

  * Add polyfill for `ReflectionConstant`
  * Add polyfill for `bcdivmod()`
  * Add polyfill for `grapheme_str_split()`
  * Add polyfills for `array_first()` and `array_last()`
  * Fix `json_validate()` with properties containing a NUL byte

# 1.32.0

  * Remove the PHP 7.2 polyfill
  * Polyfill `#[\NoDiscard]`
  * Polyfill `fpow`
  * Polyfill `get_error_handler()` and `get_exception_handler()`
  * Fix `mb_rtrim` for UTF-8 text
  * Fix Curl constants being redefined in PHP 8.4 polyfill

# 1.31.0

  * Bump minimum PHP version to 7.2
  * Polyfill `mb_trim`, `mb_ltrim` and `mb_rtrim`
  * Polyfill `CURL_HTTP_VERSION_3(ONLY)` constants

# 1.30.0

  * Polyfill `array_find`, `array_find_key`, `array_any` and `array_all`
  * Polyfill `mb_ucfirst` and `mb_lcfirst`
  * Fix `mb_convert_encoding` to accept an array of strings
  * Update nullable types for PHP 8.4

# 1.29.0

  * Fix the `ini_parse_quantity()` polyfill
  * Add `str_increment` and `str_decrement` functions
  * Add `SQLite3Exception` class

# 1.28.0

  * Polyfill `ldap_exop_sync()`
  * Polyfill `ldap_connect_wallet()`
  * Polyfill `stream_context_set_options()`
  * Polyfill `odbc_connection_string_is_quoted()`
  * Polyfill `odbc_connection_string_should_quote()`
  * Polyfill `odbc_connection_string_quote()`
  * Polyfill `ini_parse_quantity()`
  * Polyfill `mb_str_pad()`
  * Polyfill `#[\Override]` attribute
  * Use full case folding when using `MB_CASE_FOLD`
  * Add `CURLStringFile` class introduced in PHP 8.1 (but only if PHP >= 7.4 is used)
  * Add `Date*Exception/Error` classes introduced in PHP 8.3 for the Date/Time extension

# 1.27.0

  * Add PHP 8.3 polyfill for `json_validate()`
  * Add polyfill for PHP 8.2's `Random` interfaces, exceptions and `Secure` engine
  * Fix `IntlDateFormatter::formatObject()` signature

# 1.26.0

  * Add PHP 8.2 polyfill with SensitiveParameter, SensitiveParameterValue and AllowDynamicProperties
  * Fix QQQQQ date format
  * Fix passing null to `preg_split()`, throwing a deprecation on PHP 8.1

# 1.25.0

  * Add `PhpToken` to the PHP 8.0 polyfill when the tokenizer extension is enabled
  * Fix `str_ends_with()` when needle is longer than haystack

# 1.24.0

  * Indicates that polyfills provides corresponding extensions
  * Add `IntlDateFormatter::RELATIVE_*` constants
  * Mimic deprecation from PHP 8.1 in IntlDateFormatter
  * Optimize `array_is_list`
  * Workaround buggy PCRE versions
  * Fix `iconv_mime_decode()` while using mbstring extension
  * Fix deprecations on PHP 8.1
  * Fix Intl Grapheme `PCRE_VERSION` comparison when version has a timestamp
  * Fix throwing from `mb_substitute_character` on PHP >= 8

# 1.23.1

  * Allow null in str_*() functions
  * Fix `grapheme_str(r)ipos()`

# 1.23.0

  * added `CURLStringFile` to the PHP 8.1 polyfill
  * added `enum_exists()` to the PHP 8.1 polyfill
  * added `MYSQLI_REFRESH_REPLICA` constant to PHP 8.1 polyfill
  * added `ReturnTypeWillChange` to PHP 8.1 polyfill
  * updated Unicode maps to v13
  * removed `INTL_IDNA_VARIANT_2003` on PHP 8
  * fixed return value of `mb_parse_str()`
  * fixed `IntlDateFormatter::format()` on 32b platforms
  * fixed `mb_chr()` in the PHP 7.2 polyfill
  * fixed `mb_strrchr()`, `mb_detect_order()`, `iconv_substr()`, `grapheme_substr()` on PHP 8

# 1.22.1

  * always accept null values on PHP 8, as native functions do

# 1.22.0

  * added PHP 8.1 polyfill
  * fixed signatures on PHP 8
  * fixed behaviors on PHP 8
  * synced values of `Normalizer::*` consts

# 1.21.0

  * made symfony/polyfill-intl-icu independent of symfony/intl
  * made polyfills for PHP <= 7.1 independent of symfony/polyfill
  * optimize grapheme polyfill

# 1.20.0

  * Bump minimum PHP version to 7.1

# 1.19.0

  * Add a polyfill for the `Attribute` class
  * Fix the name of arguments for PHP 8
  * Improve performances of `array_key_last()`
  * Fix polyfill for `mb_strrchr()`
  * Skip loading `Stringable` on PHP 8
  * Fix passing `$length=null` to `grapheme_substr()`
  * Fix `iconv_substr()` and `grapheme_substr()` on PHP 8
  * Fix using any IDNA constants

# 1.18.1

  * Don't force labels containing URL delimiters to stay in their Unicode form when using `idn_to_ascii()`

# 1.18.0

  * improve polyfill-idn to make it compliant with latest Unicode specs
  * added `UnhandledMatchError` to the PHP 8 polyfill

# 1.17.1

  * fix accuracy of `Normalizer::isNormalized()`

# 1.17.0

  * added `get_resource_id()` to the PHP 8 polyfill
  * fix declaring extra constants when `intl` is loaded

# 1.16.0

  * added `str_starts_with()` and `str_ends_with()` to the PHP 8 polyfill
  * added polyfill for `PHP_FLOAT_*` constants
  * fixed `spl_object_id()` on 32-bit systems
  * fixed `idn_to_ascii()` not failing on leading or trailing hyphen-minus

# 1.15.0

  * added interface `Stringable` to the PHP 8 polyfill
  * added `get_debug_type()` to the PHP 8 polyfill
  * added `str_contains()` to the PHP 8 polyfill
  * added `preg_last_error_msg()` to the PHP 8 polyfill
  * added support for UUID V3 and V5
  * added support for UUID on 32-bit systems
  * fixed support for preloading

# 1.14.0

  * added PHP 8.0 polyfill

# 1.13.2

  * use correct block size for SHA1 in `hash_pbkdf2()` polyfill
  * fixed `mb_str_split()` ignoring new-line characters
  * updated Unicode maps

# 1.13.1

  * fixed issues with the uuid polyfill

# 1.13.0

  * added polyfills for `uuid_*` functions
  * optimized `mb_str_split()`
  * fixed handling negative offsets for grapheme and mbstring functions

# 1.12.0

  * added PHP 7.4 polyfill

# 1.11.0

  * fixed support for IDN with trailing dot
  * added missing polyfill for `JsonException`

# 1.10.0

  * added polyfill for `idn_to_ascii()` and `idn_to_utf8()`
  * added polyfill for intl's `MessageFormatter`
  * prevented DoS via long passwords when using `hash_pbkdf2()` polyfill
  * duplicated `mb_ord()`, `mb_chr()` and `mb_scrub()` polyfills in the `php72` one

# 1.9.0

  * added polyfill for `hrtime()`
  * added polyfills for `array_key_first()` and `array_key_last()`
  * fixed infinite loop in `iconv()` polyfill when using translit mode
  * fixed converting to title case with mbstring polyfill

# 1.8.0

  * added PHP 7.3 polyfill
  * added polyfills for `ctype_*` functions

# 1.7.0

  * added logic to new stream functions on Windows (sapi_windows_vt100_support)
  * added polyfills for mb_*_numericentity
  * made translit/ignore flags order-insensitive

# 1.6.0

  * add `SessionUpdateTimestampHandlerInterface` in PHP 7.0 polyfill
  * fixed loading of Apcu polyfill when Zend Server's Data Cache is used

# 1.5.0

  * added polyfill for spl_object_id()
  * fixed apcu function when apc ones are polyfilled with Zend Server's Data Cache
  * added `PHP_OS_FAMILY` polyfill

# 1.4.0

  * added PHP 7.2 polyfill

# 1.3.1

  * added missing validation to mb_convert_case()
  * added missing PHP_INT_MIN constant
  * fixed iconv_substr(): Detected an illegal character in input string
  * provided APCUIterator for APCu 4.x users

# 1.3.0

  * added polyfill for `is_iterable()`
  * added polyfills for `mb_chr()`, `mb_ord()` and `mb_scrub()`
  * added support for PHP 7.1
  * silenced `iconv_strlen()` in `mb_strlen()` polyfill
  * bypassed iconv for some charsets in mb_strlen
  * fixed `mb_convert_variables()` poylfill

# 1.2.0

  * bug #61 Normalizer::decompose() should reorder "recursive" combining chars (nicolas-grekas)
  * bug #59 Normalizer::recompose() should reset the last combining class on ASCII (nicolas-grekas)
  * bug #59 Normalizer::isNormalized() should fail with Normalizer::NONE (nicolas-grekas)
  * bug #59 Normalizer::isNormalized() and ::normalize() should check for multibyte string function overload (nicolas-grekas)
  * feature #44/#53 allow paragonie/random_compat 2.0 (ickbinhier)
  * feature #51 Use plain PHP for data maps to benefit from OPcache on PHP 5.6+ (nicolas-grekas)
  * bug #49 Fix hex2bin return null (fuhry, binwiederhier)

# 1.1.1

  * bug #40 [Apcu] Load APCUIterator only when APCIterator exists (nicolas-grekas)
  * bug #37 [Iconv] Fix wrong use in bootstrap.php (tucksaun)
  * bug #31 Fix class_uses polyfill (WouterJ)

# 1.1.0

  * feature #22 [APCu] A new polyfill for the legacy APC users (nicolas-grekas)
  * bug #28 [Php70] Workaround https://bugs.php.net/63206 (nicolas-grekas)

# 1.0.1

  * bug #14 ldap_escape does not encode leading/trailing spaces. (ChadSikorra)
  * bug #17 Fix #16 - gzopen() / gzopen64() - 32 bit builds of Ubuntu 14.04 (fisharebest)

# 1.0.0

  * Hello symfony/polyfill
