| Q             | A
| ------------- | ---
| Bug fix?      | yes/no
| New feature?  | yes/no <!-- please update src/**/CHANGELOG.md files -->
| Docs?         | yes/no <!-- required for new features -->
| Issues        | Fix #... <!-- prefix each issue number with "Fix #", no need to create an issue if none exist, explain below instead -->
| License       | MIT

<!--
Replace this notice by a description of your feature/bugfix.
This will help reviewers and should be a good start for the documentation.

Additionally (see https://symfony.com/releases):
 - Always add tests and ensure they pass.
 - For new features, provide some code snippets to help understand usage.
 - Features and deprecations must be submitted against branch main.
 - Update/add documentation as required (we can help!)
 - Changelog entry should follow https://symfony.com/doc/current/contributing/code/conventions.html#writing-a-changelog-entry
 - Never break backward compatibility (see https://symfony.com/bc).

CHANGELOG.md/UPGRADE.md checks enforced on every PR:
 - A bug fix only (New feature? = no) must not change any CHANGELOG.md/UPGRADE.md, unless it's a BC break (then add the "BC Break" label + an UPGRADE.md entry).
 - A backward-compatibility break needs an UPGRADE.md entry AND the "BC Break" label (the two go together).
 - Only add entries to the upcoming (unreleased) version section.
-->
