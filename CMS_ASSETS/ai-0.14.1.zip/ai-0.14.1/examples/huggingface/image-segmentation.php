<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

use Symfony\AI\Platform\Bridge\HuggingFace\Factory;
use Symfony\AI\Platform\Bridge\HuggingFace\Task;
use Symfony\AI\Platform\Message\Content\Image;

require_once dirname(__DIR__).'/bootstrap.php';

$platform = Factory::createPlatform(env('HUGGINGFACE_KEY'), httpClient: http_client());

$image = Image::fromFile(dirname(__DIR__, 2).'/fixtures/image.jpg');
$result = $platform->invoke('nvidia/segformer-b0-finetuned-ade-512-512', $image, [
    'task' => Task::IMAGE_SEGMENTATION,
]);

dump($result->asObject());
