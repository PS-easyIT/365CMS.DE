import { createParagraphMock } from '../../support/utils/createParagraphMock';
import type EditorJS from '../../../../types';

/**
 * Test cases for Caret API
 */
describe('Caret API', () => {
  describe('.setToBlock()', () => {
    describe('first argument', () => {
      const paragraphDataMock = createParagraphMock('The first block content mock.');

      /**
       * The arrange part of the following tests are the same:
       *  - create an editor
       *  - move caret out of the block by default
       */
      beforeEach(() => {
        cy.createEditor({
          data: {
            blocks: [
              paragraphDataMock,
            ],
          },
        }).as('editorInstance');

        /**
         * Blur caret from the block before setting via api
         */
        cy.get('[data-cy=editorjs]')
          .click();
      });
      it('should set caret to a block (and return true) if block index is passed as argument', () => {
        cy.get<EditorJS>('@editorInstance')
          .then(async (editor) => {
            const returnedValue = editor.caret.setToBlock(0);

            /**
             * Check that caret belongs block
             */
            cy.window()
              .then((window) => {
                const selection = window.getSelection();
                const range = selection.getRangeAt(0);

                cy.get('[data-cy=editorjs]')
                  .find('.ce-block')
                  .first()
                  .should(($block) => {
                    expect($block[0].contains(range.startContainer)).to.be.true;
                  });
              });

            expect(returnedValue).to.be.true;
          });
      });

      it('should set caret to a block (and return true) if block id is passed as argument', () => {
        cy.get<EditorJS>('@editorInstance')
          .then(async (editor) => {
            const returnedValue = editor.caret.setToBlock(paragraphDataMock.id);

            /**
             * Check that caret belongs block
             */
            cy.window()
              .then((window) => {
                const selection = window.getSelection();
                const range = selection.getRangeAt(0);

                cy.get('[data-cy=editorjs]')
                  .find('.ce-block')
                  .first()
                  .should(($block) => {
                    expect($block[0].contains(range.startContainer)).to.be.true;
                  });
              });

            expect(returnedValue).to.be.true;
          });
      });

      it('should set caret to a block (and return true) if Block API is passed as argument', () => {
        cy.get<EditorJS>('@editorInstance')
          .then(async (editor) => {
            const block = editor.blocks.getById(paragraphDataMock.id);
            const returnedValue = editor.caret.setToBlock(block);

            /**
             * Check that caret belongs block
             */
            cy.window()
              .then((window) => {
                const selection = window.getSelection();
                const range = selection.getRangeAt(0);

                cy.get('[data-cy=editorjs]')
                  .find('.ce-block')
                  .first()
                  .should(($block) => {
                    expect($block[0].contains(range.startContainer)).to.be.true;
                  });
              });

            expect(returnedValue).to.be.true;
          });
      });
    });

    describe('offset', () => {
      it('should set caret at specific offset in text content', () => {
        const paragraphDataMock = createParagraphMock('Plain text content.');

        cy.createEditor({
          data: {
            blocks: [
              paragraphDataMock,
            ],
          },
        }).as('editorInstance');

        cy.get<EditorJS>('@editorInstance')
          .then(async (editor) => {
            const block = editor.blocks.getById(paragraphDataMock.id);

            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            editor.caret.setToBlock(block!, 'default', 5);

            cy.window()
              .then((window) => {
                const selection = window.getSelection();

                if (!selection) {
                  throw new Error('Selection not found');
                }
                const range = selection.getRangeAt(0);

                expect(range.startOffset).to.equal(5);
              });
          });
      });

      it('should set caret at correct offset when text contains HTML elements', () => {
        const paragraphDataMock = createParagraphMock('1234<b>567</b>!');

        cy.createEditor({
          data: {
            blocks: [
              paragraphDataMock,
            ],
          },
        }).as('editorInstance');

        cy.get<EditorJS>('@editorInstance')
          .then(async (editor) => {
            const block = editor.blocks.getById(paragraphDataMock.id);

            // Set caret after "12345"
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            editor.caret.setToBlock(block!, 'default', 6);

            cy.window()
              .then((window) => {
                const selection = window.getSelection();

                if (!selection) {
                  throw new Error('Selection not found');
                }
                const range = selection.getRangeAt(0);

                expect(range.startContainer.textContent).to.equal('567');
                expect(range.startOffset).to.equal(2);
              });
          });
      });

      it('should handle offset beyond content length', () => {
        const paragraphDataMock = createParagraphMock('1234567890');

        cy.createEditor({
          data: {
            blocks: [
              paragraphDataMock,
            ],
          },
        }).as('editorInstance');

        cy.get<EditorJS>('@editorInstance')
          .then(async (editor) => {
            const block = editor.blocks.getById(paragraphDataMock.id);

            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            const contentLength = block!.holder.textContent?.length ?? 0;

            // Set caret beyond content length
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            editor.caret.setToBlock(block!, 'default', contentLength + 10);

            cy.window()
              .then((window) => {
                const selection = window.getSelection();

                if (!selection) {
                  throw new Error('Selection not found');
                }
                const range = selection.getRangeAt(0);

                // Should be at the end of content
                expect(range.startOffset).to.equal(contentLength);
              });
          });
      });

      it('should handle offset in nested HTML structure', () => {
        const paragraphDataMock = createParagraphMock('123<b>456<i>789</i></b>!');

        cy.createEditor({
          data: {
            blocks: [
              paragraphDataMock,
            ],
          },
        }).as('editorInstance');

        cy.get<EditorJS>('@editorInstance')
          .then(async (editor) => {
            const block = editor.blocks.getById(paragraphDataMock.id);


            // Set caret after "8"
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            editor.caret.setToBlock(block!, 'default', 8);

            cy.window()
              .then((window) => {
                const selection = window.getSelection();

                if (!selection) {
                  throw new Error('Selection not found');
                }
                const range = selection.getRangeAt(0);

                expect(range.startContainer.textContent).to.equal('789');
                expect(range.startOffset).to.equal(2);
              });
          });
      });
    });
  });
});
