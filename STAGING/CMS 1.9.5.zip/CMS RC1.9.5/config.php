<?php
/**
 * CMS Configuration Stub
 *
 * C-02: Die eigentliche Konfiguration liegt in config/app.php,
 * das durch config/.htaccess vor direktem Web-Zugriff geschützt ist.
 * Diese Stub-Datei gewährleistet Abwärtskompatibilität (z. B. Installer).
 *
 * HINWEIS: Bei Neuinstallation schreibt install.php hierher → config/app.php
 * wird dabei NICHT überschrieben. Bitte nach Neuinstallation config/app.php
 * manuell mit den neuen Werten aktualisieren oder den Installer anpassen.
 *
 * @package 365CMS
 */

declare(strict_types=1);

// ABSPATH muss hier gesetzt sein, bevor app.php ihn mit dirname(__DIR__) setzt,
// weil __DIR__ in app.php auf config/ zeigt (nicht auf CMS/).
if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . DIRECTORY_SEPARATOR);
}

require_once __DIR__ . '/config/app.php';
