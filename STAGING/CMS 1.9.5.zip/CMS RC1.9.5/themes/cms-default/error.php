<?php
/**
 * Error Template – Allgemeine Fehlerseite
 *
 * @package CMS_Default_Theme
 * @var string $errorCode    HTTP-Statuscode (z.B. '500')
 * @var string $errorMessage Fehlermeldung (optional)
 */

if (!defined('ABSPATH')) {
    exit;
}

$errorCode    = isset($errorCode)    ? htmlspecialchars((string)$errorCode,    ENT_QUOTES, 'UTF-8') : '500';
$errorMessage = isset($errorMessage) ? htmlspecialchars((string)$errorMessage, ENT_QUOTES, 'UTF-8') : '';

$messages = [
    '400' => ['Ungültige Anfrage',          'Ihre Anfrage konnte nicht verarbeitet werden.'],
    '401' => ['Nicht autorisiert',          'Sie müssen angemeldet sein, um diese Seite aufzurufen.'],
    '403' => ['Zugriff verweigert',         'Sie haben keine Berechtigung, auf diese Seite zuzugreifen.'],
    '404' => ['Seite nicht gefunden',       'Die gesuchte Seite existiert nicht.'],
    '429' => ['Zu viele Anfragen',          'Bitte warten Sie einen Moment und versuchen Sie es erneut.'],
    '500' => ['Interner Serverfehler',      'Auf dem Server ist ein Fehler aufgetreten. Bitte versuchen Sie es später erneut.'],
    '503' => ['Dienst nicht verfügbar',     'Der Dienst ist momentan nicht erreichbar. Wir arbeiten daran.'],
];

$title = $messages[$errorCode][0] ?? 'Fehler';
$desc  = !empty($errorMessage) ? $errorMessage : ($messages[$errorCode][1] ?? 'Ein unbekannter Fehler ist aufgetreten.');
?>

<main id="main" class="site-main" role="main">
    <div class="container">
        <div class="error-page">

            <div class="error-code" aria-hidden="true"><?php echo $errorCode; ?></div>

            <h1 class="error-title"><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?></h1>

            <p class="error-description">
                <?php echo htmlspecialchars($desc, ENT_QUOTES, 'UTF-8'); ?>
            </p>

            <div class="hero-actions">
                <a href="<?php echo htmlspecialchars(SITE_URL, ENT_QUOTES, 'UTF-8'); ?>/"
                   class="btn btn-primary btn-lg">
                    ← Zur Startseite
                </a>
                <?php if ($errorCode === '401') : ?>
                    <a href="<?php echo htmlspecialchars(SITE_URL, ENT_QUOTES, 'UTF-8'); ?>/login"
                       class="btn btn-secondary btn-lg">
                        Anmelden
                    </a>
                <?php else : ?>
                    <button onclick="history.back()" class="btn btn-secondary btn-lg" type="button">
                        Zurück
                    </button>
                <?php endif; ?>
            </div>

        </div>
    </div>
</main>
