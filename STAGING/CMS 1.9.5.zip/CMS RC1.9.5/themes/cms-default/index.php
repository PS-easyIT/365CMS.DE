<?php
/**
 * Index / Fallback Template
 *
 * Universelles Fallback für alle Seiten ohne spezifisches Template.
 *
 * @package CMS_Default_Theme
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<main id="main" class="site-main" role="main">
    <div class="container">
        <div class="content-area">
            <div class="error-page">
                <div style="margin-bottom:var(--spacing-lg);">
                    <svg style="width:72px;height:72px;opacity:0.2;margin:0 auto;display:block;"
                         viewBox="0 0 24 24" fill="none" stroke="currentColor"
                         stroke-width="1" aria-hidden="true">
                        <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                </div>
                <p class="error-title" style="font-size:1.25rem;">Keine Inhalte vorhanden.</p>
                <p class="error-description">Diese Seite enthält noch keine Inhalte oder konnte nicht geladen werden.</p>
                <a href="<?php echo htmlspecialchars(SITE_URL, ENT_QUOTES, 'UTF-8'); ?>/"
                   class="btn btn-primary">
                    ← Zur Startseite
                </a>
            </div>
        </div>
    </div>
</main>
