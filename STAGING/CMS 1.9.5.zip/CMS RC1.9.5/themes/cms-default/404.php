<?php
/**
 * 404 Template
 *
 * @package CMS_Default_Theme
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<main id="main" class="site-main" role="main">
    <div class="container">
        <div class="error-page">

            <div class="error-code" aria-hidden="true">404</div>

            <h1 class="error-title">Seite nicht gefunden</h1>

            <p class="error-description">
                Die gesuchte Seite existiert nicht oder wurde verschoben.
                Bitte überprüfen Sie die URL oder nutzen Sie die Suche.
            </p>

            <div class="hero-actions">
                <a href="<?php echo htmlspecialchars(SITE_URL, ENT_QUOTES, 'UTF-8'); ?>/"
                   class="btn btn-primary btn-lg">
                    ← Zur Startseite
                </a>
                <button onclick="history.back()" class="btn btn-secondary btn-lg" type="button">
                    Zurück
                </button>
            </div>

            <!-- Inline-Suche -->
            <div style="margin-top:var(--spacing-xl);max-width:480px;margin-left:auto;margin-right:auto;">
                <form action="<?php echo htmlspecialchars(SITE_URL, ENT_QUOTES, 'UTF-8'); ?>/search"
                      method="GET" role="search"
                      style="display:flex;gap:.5rem;background:var(--bg-secondary);
                             border:1.5px solid var(--border-color);border-radius:var(--radius-xl);
                             padding:.5rem .5rem .5rem 1rem;">
                    <input type="search" name="q" placeholder="Seite suchen…"
                           aria-label="Suchen"
                           style="flex:1;border:none;background:transparent;font-size:1rem;
                                  color:var(--text-color);outline:none;">
                    <button type="submit" class="btn btn-primary btn-sm" aria-label="Suchen">
                        Suchen
                    </button>
                </form>
            </div>

        </div>
    </div>
</main>
