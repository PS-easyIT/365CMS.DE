<?php
/**
 * Login Template
 *
 * @package CMS_Default_Theme
 */

if (!defined('ABSPATH')) {
    exit;
}

$siteUrl   = SITE_URL;
$siteTitle = \CMS\ThemeManager::instance()->getSiteTitle();
$error     = theme_get_flash('error');
$success   = theme_get_flash('success');
?>

<main id="main" role="main"
      style="min-height:calc(100vh - 180px);display:flex;align-items:center;
             background:linear-gradient(135deg,#eff6ff 0%,#f8fafc 100%);
             padding:var(--spacing-lg) var(--container-padding);"
      aria-label="Anmelden">

    <div style="width:100%;max-width:440px;margin:0 auto;">

        <div class="auth-card">

            <!-- Logo / Icon -->
            <div class="auth-logo">
                <svg style="width:52px;height:52px;color:var(--primary-color);margin:0 auto 0.875rem;display:block;"
                     viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <rect width="44" height="44" rx="10" fill="currentColor" opacity="0.1"/>
                    <path d="M22 8L34 14V26L22 32L10 26V14L22 8Z"
                          stroke="currentColor" stroke-width="2" stroke-linejoin="round" fill="none"/>
                    <circle cx="22" cy="20" r="4" fill="currentColor"/>
                </svg>
                <h1><?php echo htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'); ?></h1>
                <p>Melde dich mit deinem Konto an</p>
            </div>

            <!-- Flash Messages -->
            <?php if ($error && trim($error) !== '') : ?>
                <div class="alert alert-error" role="alert">
                    <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <?php if ($success && trim($success) !== '') : ?>
                <div class="alert alert-success" role="alert">
                    <?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form method="POST"
                  action="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/login"
                  novalidate>
                <?php theme_csrf_field('login'); ?>

                <div class="form-group">
                    <label class="form-label" for="username">Benutzername oder E-Mail</label>
                    <input class="form-control"
                           type="text"
                           id="username"
                           name="username"
                           autocomplete="username"
                           required
                           autofocus
                           value="<?php echo htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">
                        Passwort
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/forgot-password"
                           style="float:right;font-weight:400;font-size:.8125rem;">
                            Passwort vergessen?
                        </a>
                    </label>
                    <input class="form-control"
                           type="password"
                           id="password"
                           name="password"
                           autocomplete="current-password"
                           required>
                </div>

                <button type="submit" class="btn btn-primary"
                        style="width:100%;margin-top:var(--spacing-md);padding:.75rem;">
                    Anmelden
                </button>

            </form>

            <div class="auth-footer">
                <p>Noch kein Konto?
                    <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/register">
                        Jetzt registrieren
                    </a>
                </p>
                <p style="margin-top:.5rem;">
                    <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/">
                        ← Zurück zur Startseite
                    </a>
                </p>
            </div>

        </div>
    </div>
</main>
