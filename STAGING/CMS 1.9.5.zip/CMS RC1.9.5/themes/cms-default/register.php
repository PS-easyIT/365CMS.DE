<?php
/**
 * Register Template
 *
 * @package CMS_Default_Theme
 */

if (!defined('ABSPATH')) {
    exit;
}

$siteUrl   = SITE_URL;
$siteTitle = \CMS\ThemeManager::instance()->getSiteTitle();
$error     = theme_get_flash('error');
$success   = theme_get_flash('success');
?>

<main id="main" role="main"
      style="min-height:calc(100vh - 180px);display:flex;align-items:center;
             background:linear-gradient(135deg,#eff6ff 0%,#f8fafc 100%);
             padding:var(--spacing-lg) var(--container-padding);"
      aria-label="Registrieren">

    <div style="width:100%;max-width:480px;margin:0 auto;">

        <div class="auth-card">

            <!-- Logo / Icon -->
            <div class="auth-logo">
                <svg style="width:52px;height:52px;color:var(--primary-color);margin:0 auto 0.875rem;display:block;"
                     viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <rect width="44" height="44" rx="10" fill="currentColor" opacity="0.1"/>
                    <path d="M22 8L34 14V26L22 32L10 26V14L22 8Z"
                          stroke="currentColor" stroke-width="2" stroke-linejoin="round" fill="none"/>
                    <circle cx="22" cy="20" r="4" fill="currentColor"/>
                </svg>
                <h1><?php echo htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'); ?></h1>
                <p>Kostenloses Konto erstellen</p>
            </div>

            <!-- Flash Messages -->
            <?php if ($error && trim($error) !== '') : ?>
                <div class="alert alert-error" role="alert">
                    <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <?php if ($success && trim($success) !== '') : ?>
                <div class="alert alert-success" role="alert">
                    <?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <!-- Register Form -->
            <form method="POST"
                  action="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/register"
                  novalidate>
                <?php theme_csrf_field('register'); ?>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:var(--spacing-sm);">
                    <div class="form-group" style="margin:0;">
                        <label class="form-label" for="first_name">Vorname</label>
                        <input class="form-control"
                               type="text"
                               id="first_name"
                               name="first_name"
                               autocomplete="given-name"
                               required
                               autofocus
                               value="<?php echo htmlspecialchars($_POST['first_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="form-group" style="margin:0;">
                        <label class="form-label" for="last_name">Nachname</label>
                        <input class="form-control"
                               type="text"
                               id="last_name"
                               name="last_name"
                               autocomplete="family-name"
                               value="<?php echo htmlspecialchars($_POST['last_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                </div>

                <div class="form-group" style="margin-top:var(--spacing-sm);">
                    <label class="form-label" for="username">Benutzername</label>
                    <input class="form-control"
                           type="text"
                           id="username"
                           name="username"
                           autocomplete="username"
                           required
                           value="<?php echo htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="email">E-Mail-Adresse</label>
                    <input class="form-control"
                           type="email"
                           id="email"
                           name="email"
                           autocomplete="email"
                           required
                           value="<?php echo htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Passwort</label>
                    <input class="form-control"
                           type="password"
                           id="password"
                           name="password"
                           autocomplete="new-password"
                           required
                           minlength="8">
                    <small style="font-size:.8125rem;color:var(--text-muted);margin-top:.25rem;display:block;">
                        Mindestens 8 Zeichen
                    </small>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password_confirm">Passwort bestätigen</label>
                    <input class="form-control"
                           type="password"
                           id="password_confirm"
                           name="password_confirm"
                           autocomplete="new-password"
                           required>
                </div>

                <!-- Datenschutz Checkbox -->
                <div style="display:flex;align-items:flex-start;gap:.625rem;margin-bottom:var(--spacing-md);">
                    <input type="checkbox" id="privacy" name="privacy" required
                           style="width:18px;height:18px;flex-shrink:0;margin-top:.15rem;
                                  accent-color:var(--primary-color);">
                    <label for="privacy" style="font-size:.875rem;cursor:pointer;color:var(--text-muted);">
                        Ich habe die
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/datenschutz">
                            Datenschutzerklärung
                        </a>
                        gelesen und stimme zu.
                    </label>
                </div>

                <button type="submit" class="btn btn-primary"
                        style="width:100%;padding:.75rem;">
                    Konto erstellen
                </button>

            </form>

            <div class="auth-footer">
                <p>Bereits ein Konto?
                    <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/login">
                        Jetzt anmelden
                    </a>
                </p>
                <p style="margin-top:.5rem;">
                    <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/">
                        ← Zurück zur Startseite
                    </a>
                </p>
            </div>

        </div>
    </div>
</main>
