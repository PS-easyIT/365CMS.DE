<?php
/**
 * Single-Post Template – Einzelner Blog-Beitrag
 *
 * @package CMS_Default_Theme
 * @var object $post
 */

if (!defined('ABSPATH')) {
    exit;
}

if (empty($post)) {
    http_response_code(404);
    \CMS\ThemeManager::instance()->render('404');
    return;
}

$postTitle   = htmlspecialchars($post->title        ?? '',         ENT_QUOTES, 'UTF-8');
$postContent = $post->content ?? '';
$postExcerpt = $post->excerpt ?? '';
$postSlug    = $post->slug    ?? '';
$authorName  = htmlspecialchars($post->author_name  ?? 'Unbekannt', ENT_QUOTES, 'UTF-8');
$catName     = htmlspecialchars($post->category_name ?? '',          ENT_QUOTES, 'UTF-8');
$featImg     = $post->featured_image ?? '';
$publishedAt = $post->published_at   ?? $post->created_at ?? '';
$tags        = $post->tags           ?? '';
$metaTitle   = !empty($post->meta_title)       ? htmlspecialchars($post->meta_title,       ENT_QUOTES, 'UTF-8') : $postTitle;
$metaDesc    = !empty($post->meta_description) ? htmlspecialchars($post->meta_description, ENT_QUOTES, 'UTF-8') : htmlspecialchars(strip_tags($postExcerpt ?: $postContent), ENT_QUOTES, 'UTF-8');
?>
<head>
    <title><?php echo $metaTitle; ?> – Blog</title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta property="og:title"       content="<?php echo $metaTitle; ?>">
    <meta property="og:description" content="<?php echo $metaDesc; ?>">
    <?php if ($featImg): ?>
    <meta property="og:image" content="<?php echo htmlspecialchars($featImg, ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
</head>

<main id="main" class="site-main" role="main">
    <div class="container">

        <!-- Breadcrumb -->
        <nav class="breadcrumb" aria-label="Brotkrümelnavigation" style="margin-bottom:1.5rem;">
            <a href="<?php echo SITE_URL; ?>/">Startseite</a>
            <span class="breadcrumb-sep" aria-hidden="true">/</span>
            <a href="<?php echo SITE_URL; ?>/blog">Blog</a>
            <span class="breadcrumb-sep" aria-hidden="true">/</span>
            <span class="breadcrumb-current"><?php echo $postTitle; ?></span>
        </nav>

        <div class="blog-single-layout">

            <!-- Artikel -->
            <article class="blog-single-article" itemscope itemtype="https://schema.org/BlogPosting">

                <?php if ($featImg): ?>
                <div class="blog-single-hero">
                    <img src="<?php echo htmlspecialchars($featImg, ENT_QUOTES, 'UTF-8'); ?>"
                         alt="<?php echo $postTitle; ?>"
                         class="blog-single-hero-img"
                         itemprop="image">
                </div>
                <?php endif; ?>

                <header class="blog-single-header">
                    <h1 class="blog-single-title" itemprop="headline"><?php echo $postTitle; ?></h1>
                    <div class="blog-single-meta">
                        <?php if ($publishedAt): ?>
                        <span>
                            <time datetime="<?php echo htmlspecialchars($publishedAt, ENT_QUOTES, 'UTF-8'); ?>"
                                  itemprop="datePublished">
                                <?php echo date('d. F Y', strtotime($publishedAt)); ?>
                            </time>
                        </span>
                        <?php endif; ?>
                        <?php if ($authorName): ?>
                        <span itemprop="author">von <?php echo $authorName; ?></span>
                        <?php endif; ?>
                        <?php if ($catName): ?>
                        <span class="blog-single-cat">📂 <?php echo $catName; ?></span>
                        <?php endif; ?>
                    </div>
                </header>

                <?php if ($postContent && trim($postContent) !== ''): ?>
                <div class="blog-single-content entry-content" itemprop="articleBody">
                    <?php echo $postContent; ?>
                </div>
                <?php endif; ?>

                <?php if ($tags && trim($tags) !== ''): ?>
                <footer class="blog-single-tags">
                    <?php foreach (array_filter(array_map('trim', explode(',', $tags))) as $tag): ?>
                    <span class="blog-tag"><?php echo htmlspecialchars($tag, ENT_QUOTES, 'UTF-8'); ?></span>
                    <?php endforeach; ?>
                </footer>
                <?php endif; ?>

            </article>

        </div><!-- /.blog-single-layout -->

        <div style="margin-top:2.5rem;">
            <a href="<?php echo SITE_URL; ?>/blog" class="btn btn-secondary">&larr; Alle Beiträge</a>
        </div>

    </div><!-- /.container -->
</main>

<style>
.blog-single-layout{max-width:820px;margin:0 auto;}
.blog-single-hero{margin-bottom:2rem;border-radius:10px;overflow:hidden;}
.blog-single-hero-img{width:100%;max-height:420px;object-fit:cover;display:block;}
.blog-single-header{margin-bottom:2rem;}
.blog-single-title{font-size:2rem;font-weight:800;line-height:1.22;margin:0 0 .75rem;}
.blog-single-meta{display:flex;flex-wrap:wrap;gap:.75rem;font-size:.875rem;color:#64748b;align-items:center;}
.blog-single-meta span+span::before{content:'·';margin-right:.75rem;}
.blog-single-cat{background:#e0f2fe;color:#0369a1;padding:.2rem .55rem;border-radius:99px;font-weight:600;}
.blog-single-content{font-size:1.05rem;line-height:1.75;color:#1e293b;}
.blog-single-content img{max-width:100%;border-radius:6px;}
.blog-single-content h2,.blog-single-content h3{margin-top:2rem;}
.blog-single-tags{display:flex;flex-wrap:wrap;gap:.4rem;margin-top:2.5rem;padding-top:1.5rem;border-top:1px solid #e2e8f0;}
.blog-tag{background:#f1f5f9;color:#475569;padding:.25rem .6rem;border-radius:99px;font-size:.8rem;}
</style>
