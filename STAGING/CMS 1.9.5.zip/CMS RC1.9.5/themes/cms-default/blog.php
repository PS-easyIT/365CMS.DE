<?php
/**
 * Blog-Archiv Template – Beitragsübersicht
 *
 * @package CMS_Default_Theme
 * @var array    $posts
 * @var int      $total
 * @var int      $currentPage
 * @var int      $totalPages
 * @var int      $perPage
 */

if (!defined('ABSPATH')) {
    exit;
}

$posts       = $posts       ?? [];
$currentPage = $currentPage ?? 1;
$totalPages  = $totalPages  ?? 1;
?>

<main id="main" class="site-main" role="main">
    <div class="container">

        <header class="blog-archive-header">
            <h1 class="blog-archive-title">📝 Blog</h1>
            <?php if (!empty($total)): ?>
            <p class="blog-archive-count"><?php echo (int)$total; ?> Beitrag<?php echo $total !== 1 ? 'e' : ''; ?></p>
            <?php endif; ?>
        </header>

        <?php if (empty($posts)): ?>
        <div class="blog-empty">
            <p>Noch keine Beiträge veröffentlicht.</p>
        </div>
        <?php else: ?>

        <div class="blog-grid">
            <?php foreach ($posts as $post):
                $slug        = htmlspecialchars($post->slug           ?? '', ENT_QUOTES, 'UTF-8');
                $title       = htmlspecialchars($post->title          ?? '', ENT_QUOTES, 'UTF-8');
                $excerpt     = $post->excerpt ?? '';
                $featImg     = $post->featured_image ?? '';
                $catName     = htmlspecialchars($post->category_name  ?? '', ENT_QUOTES, 'UTF-8');
                $publishedAt = $post->published_at ?? $post->created_at ?? '';
                $dateLabel   = $publishedAt ? date('d. M Y', strtotime($publishedAt)) : '';
            ?>
            <article class="blog-card">
                <a href="<?php echo SITE_URL; ?>/blog/<?php echo $slug; ?>" class="blog-card-img-wrap">
                    <?php if ($featImg): ?>
                    <img src="<?php echo htmlspecialchars($featImg, ENT_QUOTES, 'UTF-8'); ?>"
                         alt="<?php echo $title; ?>"
                         class="blog-card-img"
                         loading="lazy">
                    <?php else: ?>
                    <div class="blog-card-img-placeholder">📝</div>
                    <?php endif; ?>
                </a>
                <div class="blog-card-body">
                    <div class="blog-card-meta">
                        <?php if ($dateLabel): ?>
                        <span class="blog-card-date"><?php echo $dateLabel; ?></span>
                        <?php endif; ?>
                        <?php if ($catName): ?>
                        <span class="blog-card-cat">📂 <?php echo $catName; ?></span>
                        <?php endif; ?>
                    </div>
                    <h2 class="blog-card-title">
                        <a href="<?php echo SITE_URL; ?>/blog/<?php echo $slug; ?>"><?php echo $title; ?></a>
                    </h2>
                    <?php if ($excerpt && trim($excerpt) !== ''): ?>
                    <p class="blog-card-excerpt"><?php echo htmlspecialchars(strip_tags($excerpt), ENT_QUOTES, 'UTF-8'); ?></p>
                    <?php endif; ?>
                    <a href="<?php echo SITE_URL; ?>/blog/<?php echo $slug; ?>" class="blog-card-link">Weiterlesen &rarr;</a>
                </div>
            </article>
            <?php endforeach; ?>
        </div><!-- /.blog-grid -->

        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
        <nav class="blog-pagination" aria-label="Seitennavigation">
            <?php if ($currentPage > 1): ?>
            <a href="<?php echo SITE_URL; ?>/blog?p=<?php echo $currentPage - 1; ?>" class="blog-page-btn">&lsaquo; Zurück</a>
            <?php endif; ?>
            <?php for ($i = max(1, $currentPage - 3); $i <= min($totalPages, $currentPage + 3); $i++): ?>
            <?php if ($i === $currentPage): ?>
                <span class="blog-page-btn blog-page-current"><?php echo $i; ?></span>
            <?php else: ?>
                <a href="<?php echo SITE_URL; ?>/blog?p=<?php echo $i; ?>" class="blog-page-btn"><?php echo $i; ?></a>
            <?php endif; ?>
            <?php endfor; ?>
            <?php if ($currentPage < $totalPages): ?>
            <a href="<?php echo SITE_URL; ?>/blog?p=<?php echo $currentPage + 1; ?>" class="blog-page-btn">Vor &rsaquo;</a>
            <?php endif; ?>
        </nav>
        <?php endif; ?>

        <?php endif; ?>

    </div><!-- /.container -->
</main>

<style>
.blog-archive-header{margin-bottom:2.5rem;}
.blog-archive-title{font-size:2rem;font-weight:800;margin:0 0 .3rem;}
.blog-archive-count{color:#64748b;font-size:.9rem;margin:0;}
.blog-empty{text-align:center;padding:4rem;color:#94a3b8;}
.blog-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:2rem;margin-bottom:3rem;}
.blog-card{background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;display:flex;flex-direction:column;transition:box-shadow .2s,transform .2s;}
.blog-card:hover{box-shadow:0 8px 30px rgba(0,0,0,.1);transform:translateY(-2px);}
.blog-card-img-wrap{display:block;aspect-ratio:16/9;overflow:hidden;background:#f1f5f9;}
.blog-card-img{width:100%;height:100%;object-fit:cover;transition:transform .25s;}
.blog-card:hover .blog-card-img{transform:scale(1.04);}
.blog-card-img-placeholder{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:2.5rem;color:#cbd5e1;}
.blog-card-body{padding:1.25rem;display:flex;flex-direction:column;flex:1;gap:.5rem;}
.blog-card-meta{display:flex;flex-wrap:wrap;gap:.4rem;font-size:.76rem;color:#94a3b8;align-items:center;}
.blog-card-cat{background:#e0f2fe;color:#0369a1;padding:.12rem .45rem;border-radius:99px;font-weight:600;}
.blog-card-title{font-size:1.05rem;font-weight:700;margin:0;line-height:1.35;}
.blog-card-title a{color:#1e293b;text-decoration:none;}
.blog-card-title a:hover{color:#2563eb;}
.blog-card-excerpt{font-size:.875rem;color:#64748b;line-height:1.55;margin:0;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;}
.blog-card-link{margin-top:auto;font-size:.85rem;font-weight:600;color:#2563eb;text-decoration:none;}
.blog-card-link:hover{text-decoration:underline;}
.blog-pagination{display:flex;align-items:center;gap:.35rem;flex-wrap:wrap;margin-top:2rem;}
.blog-page-btn{padding:.4rem .8rem;border:1px solid #e2e8f0;border-radius:6px;font-size:.85rem;text-decoration:none;color:#374151;}
.blog-page-btn:hover{background:#f1f5f9;}
.blog-page-current{background:#2563eb;color:#fff;border-color:#2563eb;}
</style>
