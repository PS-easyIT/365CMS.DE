<?php
/**
 * Home Template – Universelle Startseite
 *
 * Inhalte werden über den LandingPageService / ThemeCustomizer aus der DB geladen.
 * Konfigurierbar im Admin unter Einstellungen → Theme → Startseite – Hero.
 *
 * @package CMS_Default_Theme
 */

if (!defined('ABSPATH')) {
    exit;
}

$siteUrl    = SITE_URL;
$isLoggedIn = theme_is_logged_in();

// ===== Startseiten-Modus =====
try {
    $homepageMode = \CMS\Services\ThemeCustomizer::instance()->get('hero', 'homepage_mode', 'hero');
} catch (\Throwable $e) {
    $homepageMode = 'hero';
}

// ===== Landing Page Modus – identisch mit der allgemeinen CMS Landing Page =====
if ($homepageMode === 'landing') {
    /*
     * Das 365Network-Theme enthält das allgemeine CMS Landing-Page-Template.
     * Wir binden es direkt ein, damit cms-default in LP-Modus identisch aussieht.
     * Da 365Network ausschließlich Inline-Styles nutzt, funktioniert das unabhängig
     * vom aktiven Theme-CSS.
     */
    $lpTemplate = THEME_PATH . '365Network/home.php';
    if (file_exists($lpTemplate)) {
        require $lpTemplate;
        return; // Landing-Modus fertig
    }

    // ---- Fallback wenn 365Network-Theme nicht vorhanden ----
    try {
        $lp      = \CMS\Services\LandingPageService::getInstance();
        $lpHead  = $lp->getHeader();
        $lpFeats = $lp->getFeatures() ?: [];
        $lpFoot  = $lp->getFooter();
        // Load Design Tokens
        $lpDesign = $lp->getDesign();
        $lpContent = $lp->getContentSettings();
        
        $lpColors = $lpHead['colors'] ?? [];
        $lpGradStart = htmlspecialchars($lpColors['hero_gradient_start'] ?? '#1e3a5f', ENT_QUOTES, 'UTF-8');
        $lpGradEnd   = htmlspecialchars($lpColors['hero_gradient_end']   ?? '#0c1f35', ENT_QUOTES, 'UTF-8');
        $lpBorderCol = htmlspecialchars($lpColors['hero_border']         ?? '#b45309', ENT_QUOTES, 'UTF-8');
        $heroText    = htmlspecialchars($lpColors['hero_text']           ?? '#ffffff', ENT_QUOTES, 'UTF-8');
        $featuresBg  = htmlspecialchars($lpColors['features_bg']         ?? '#f2f0ec', ENT_QUOTES, 'UTF-8');
        $cardBg      = htmlspecialchars($lpColors['feature_card_bg']     ?? '#faf9f7', ENT_QUOTES, 'UTF-8');
        $cardHover   = htmlspecialchars($lpColors['feature_card_hover']  ?? '#b45309', ENT_QUOTES, 'UTF-8');
        $primaryBtn  = htmlspecialchars($lpColors['primary_button']      ?? '#b45309', ENT_QUOTES, 'UTF-8');
        
        // Extract Design Tokens
        $d_cardBr   = (int)($lpDesign['card_border_radius'] ?? 12) . 'px';
        $d_btnBr    = (int)($lpDesign['button_border_radius'] ?? 8) . 'px';
        $d_cardIcon = $lpDesign['card_icon_layout'] ?? 'top';
        $d_cardShadow = match($lpDesign['card_shadow'] ?? 'sm') {
            'none' => 'none',
            'sm' => '0 1px 3px rgba(0,0,0,0.05)',
            'md' => '0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06)',
            'lg' => '0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05)',
            default => '0 1px 3px rgba(0,0,0,0.05)'
        };
        $d_heroPad  = match($lpDesign['hero_padding'] ?? 'md') {
            'sm' => '2rem',
            'md' => '4rem',
            'lg' => '6rem',
            'xl' => '8rem',
            default => '4rem'
        };
        $d_featPad  = match($lpDesign['feature_padding'] ?? 'md') {
            'sm' => '2rem',
            'md' => '4rem',
            'lg' => '6rem',
            'xl' => '8rem',
            default => '4rem'
        };
        $d_contentBg = htmlspecialchars($lpDesign['content_section_bg'] ?? '#ffffff', ENT_QUOTES, 'UTF-8');

    } catch (\Throwable $e) {
        error_log('home.php LandingPageService fallback: ' . $e->getMessage());
        $lpHead = ['title' => 'Willkommen', 'subtitle' => '', 'description' => '', 'header_buttons' => []];
        $lpFeats = []; $lpFoot = []; $lpContent = ['content_type'=>'features','content_text'=>''];
        $lpGradStart = '#1e3a5f'; $lpGradEnd = '#0c1f35'; $lpBorderCol = '#b45309';
        $heroText = '#ffffff'; $featuresBg = '#f2f0ec'; $cardBg = '#faf9f7';
        $cardHover = '#b45309'; $primaryBtn = '#b45309';
        $d_cardBr = '12px'; $d_btnBr = '8px'; $d_cardIcon = 'top'; $d_cardShadow = '0 1px 3px rgba(0,0,0,0.05)';
        $d_heroPad = '4rem'; $d_featPad = '4rem'; $d_contentBg = '#ffffff';
    }
    ?>
<main id="main" class="site-main" role="main">

    <!-- ===== Hero (Fallback) ===== -->
    <?php
    $logoPos      = $lpHead['logo_position'] ?? 'top';
    $headerLayout = $lpHead['header_layout'] ?? 'standard';
    $hasLogo      = !empty($lpHead['logo']);
    if ($headerLayout === 'compact') {
        $heroPadding    = $d_heroPad === '4rem' ? '2rem 1rem' : $d_heroPad; // Adjust compact if needed
        $titleSize      = '1.75rem'; $subtitleSize = '1.1rem'; $descSize = '0.95rem';
        $logoHeight     = '40px';    $logoMargin   = '0 auto 0.5rem';
        $titleMargin    = '0.5rem';
        $descMargin     = ($logoPos === 'left' && $hasLogo) ? '0 0 0.5rem' : '0 auto 1rem';
        $btnMarginTop   = '1rem';    $containerWidth = '900px'; $minHeight = 'auto';
    } else {
        $heroPadding    = $hasLogo ? $d_heroPad : $d_heroPad; 
        $titleSize      = '3rem';    $subtitleSize = '1.5rem'; $descSize = '1.2rem';
        $logoHeight     = '90px';    $logoMargin   = '0 auto 2rem';
        $titleMargin    = '1.5rem';
        $descMargin     = ($logoPos === 'left' && $hasLogo) ? '0 0 2rem' : '0 auto 3rem';
        $btnMarginTop   = '2.5rem';  $containerWidth = ($logoPos === 'left') ? '1000px' : '800px';
        $minHeight      = '70vh';
    }
    ?>
    <style>
    .lp-hero-fb { --lp-grad-start:<?php echo $lpGradStart; ?>;--lp-grad-end:<?php echo $lpGradEnd; ?>;--lp-border:<?php echo $lpBorderCol; ?>;--lp-text:<?php echo $heroText; ?>;--lp-btn-primary:<?php echo $primaryBtn; ?>; }
    .lp-feat-fb { --lp-features-bg:<?php echo $featuresBg; ?>;--lp-card-bg:<?php echo $cardBg; ?>;--lp-card-hover:<?php echo $cardHover; ?>; }
    /* Design Tokens */
    .lp-hero-fb .btn { border-radius: <?php echo $d_btnBr; ?> !important; }
    .lp-feat-fb .feat-card { border-radius: <?php echo $d_cardBr; ?> !important; box-shadow: <?php echo $d_cardShadow; ?> !important; }
    .lp-content-fb { background-color: <?php echo $d_contentBg; ?>; }
    </style>

    <section class="lp-hero-fb" style="
        background:linear-gradient(135deg,var(--lp-grad-start) 0%,var(--lp-grad-end) 100%);
        color:var(--lp-text);padding:<?php echo $heroPadding; ?>;
        text-align:<?php echo ($logoPos === 'left' && $hasLogo) ? 'left' : 'center'; ?>;
        position:relative;overflow:hidden;border-bottom:3px solid var(--lp-border);
        margin-top:0;min-height:<?php echo $minHeight; ?>;display:flex;flex-direction:column;justify-content:center;">
        <div class="container" style="position:relative;z-index:1;max-width:<?php echo $containerWidth; ?>;margin:0 auto;">

            <?php if ($logoPos === 'left' && $hasLogo): ?>
                <div style="display:flex;gap:2rem;align-items:center;justify-content:center;flex-wrap:wrap;text-align:left;">
                <div style="flex:0 0 auto;"><img src="<?php echo htmlspecialchars($lpHead['logo'], ENT_QUOTES, 'UTF-8'); ?>" alt="" style="max-height:<?php echo $headerLayout === 'compact' ? '80px' : '120px'; ?>;display:block;"></div>
                <div style="flex:1;min-width:300px;">
            <?php elseif ($hasLogo): ?>
                <img src="<?php echo htmlspecialchars($lpHead['logo'], ENT_QUOTES, 'UTF-8'); ?>" alt="" style="max-height:<?php echo $logoHeight; ?>;margin:<?php echo $logoMargin; ?>;display:block;">
            <?php endif; ?>

            <?php if (!empty($lpHead['title'])): ?>
                <h1 style="font-size:<?php echo $titleSize; ?>;font-weight:900;margin-bottom:<?php echo $titleMargin; ?>;color:var(--lp-text);line-height:1.2;">
                    <?php echo htmlspecialchars($lpHead['title'], ENT_QUOTES, 'UTF-8'); ?>
                </h1>
            <?php endif; ?>
            <?php if (!empty($lpHead['subtitle'])): ?>
                <p style="font-size:<?php echo $subtitleSize; ?>;opacity:0.85;margin-bottom:<?php echo $titleMargin; ?>;font-weight:500;">
                    <?php echo htmlspecialchars($lpHead['subtitle'], ENT_QUOTES, 'UTF-8'); ?>
                </p>
            <?php endif; ?>
            <?php if (!empty($lpHead['description'])): ?>
                <div style="font-size:<?php echo $descSize; ?>;opacity:0.75;max-width:640px;margin:<?php echo $descMargin; ?>;line-height:1.6;">
                    <?php echo $lpHead['description']; ?>
                </div>
            <?php endif; ?>

            <?php if ($logoPos === 'left' && $hasLogo): ?></div></div><?php endif; ?>

            <!-- Buttons -->
            <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;margin-top:<?php echo $btnMarginTop; ?>;">
                <?php foreach ($lpHead['header_buttons'] ?? [] as $btn):
                    if (empty($btn['url'])) continue;
                    $bText    = htmlspecialchars($btn['text'] ?? 'Link', ENT_QUOTES, 'UTF-8');
                    $bUrl     = htmlspecialchars($btn['url'],            ENT_QUOTES, 'UTF-8');
                    $bIcon    = htmlspecialchars($btn['icon'] ?? '',     ENT_QUOTES, 'UTF-8');
                    $bTarget  = htmlspecialchars($btn['target'] ?? '_self', ENT_QUOTES, 'UTF-8');
                    $isOutline = !empty($btn['outline']);
                    $btnStyle = $isOutline ? 'border-color:rgba(255,255,255,0.5);color:var(--lp-text);' : 'background:rgba(255,255,255,0.2);color:var(--lp-text);border:1px solid rgba(255,255,255,0.3);';
                ?>
                    <a href="<?php echo $bUrl; ?>" class="btn <?php echo $isOutline ? 'btn-outline' : ''; ?> btn-lg" style="<?php echo $btnStyle; ?>"
                       target="<?php echo $bTarget; ?>" <?php echo $bTarget === '_blank' ? 'rel="noopener noreferrer"' : ''; ?>>
                        <?php echo $bIcon ? $bIcon . ' ' : ''; ?><?php echo $bText; ?>
                    </a>
                <?php endforeach; ?>
                <?php if (empty($lpHead['header_buttons'])): ?>
                    <?php if ($isLoggedIn): ?>
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/member" class="btn btn-lg" style="background:rgba(255,255,255,0.2);color:#fff;border:1px solid rgba(255,255,255,0.3);">Zum Dashboard →</a>
                    <?php else: ?>
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/register" class="btn btn-lg" style="background:rgba(255,255,255,0.2);color:#fff;border:1px solid rgba(255,255,255,0.3);">Jetzt starten →</a>
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/login" class="btn btn-outline btn-lg">Anmelden</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- ===== Content Section ===== -->
    <?php if (!empty($lpContent['content_text'])): ?>
    <section class="lp-content-fb" style="padding:<?php echo $d_heroPad; ?> 2rem;">
        <div class="container" style="max-width:800px;margin:0 auto;line-height:1.8;font-size:1.1rem;color:var(--text-color);">
            <?php echo $lpContent['content_text']; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- ===== Feature Grid ===== -->
    <?php if (!empty($lpFeats)): ?>
    <section class="lp-feat-fb" style="padding:<?php echo $d_featPad; ?> 2rem;background:var(--lp-features-bg);">
        <div class="container">
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1.5rem;">
                <?php foreach ($lpFeats as $feat):
                    if (trim($feat['title'] ?? '') === '') continue;
                    $fIcon  = htmlspecialchars($feat['icon']        ?? '🔧', ENT_QUOTES, 'UTF-8');
                    $fTitle = htmlspecialchars($feat['title']       ?? '',   ENT_QUOTES, 'UTF-8');
                    $fDesc  = htmlspecialchars($feat['description'] ?? '',   ENT_QUOTES, 'UTF-8');
                    
                    // Icon Layout Class
                    $flexClass = $d_cardIcon === 'left' ? 'display:flex;text-align:left;gap:1.5rem;align-items:flex-start;' : 'text-align:center;';
                    $iconMargin = $d_cardIcon === 'left' ? 'margin-bottom:0;' : 'margin-bottom:1rem;';
                ?>
                    <div class="feat-card" style="background:var(--lp-card-bg);padding:2rem 1.5rem;<?php echo $flexClass; ?>transition:transform 0.2s,box-shadow 0.2s;border-top:3px solid transparent;"
                         onmouseenter="this.style.transform='translateY(-4px)';this.style.boxShadow='0 8px 24px rgba(0,0,0,0.12)';this.style.borderTopColor='<?php echo $cardHover; ?>'"
                         onmouseleave="this.style.transform='';this.style.boxShadow='<?php echo $d_cardShadow; ?>';this.style.borderTopColor='transparent'">
                        <div style="font-size:2.5rem;<?php echo $iconMargin; ?>color:var(--lp-btn-primary);"><?php echo $fIcon; ?></div>
                        <div>
                            <?php if ($fTitle !== ''): ?><h3 style="font-size:1.1rem;font-weight:700;margin-bottom:0.6rem;margin-top:0;"><?php echo $fTitle; ?></h3><?php endif; ?>
                            <?php if ($fDesc  !== ''): ?><p  style="font-size:0.95rem;line-height:1.6;color:var(--muted-color,#666);margin-bottom:0;"><?php echo $fDesc; ?></p><?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ===== Footer / CTA ===== -->
    <?php if (!empty($lpFoot['show_footer']) && $lpFoot['show_footer']): ?>
    <section style="padding:4rem 2rem;text-align:center;background:var(--body-bg,#fff);border-top:1px solid var(--border-color,#e2e8f0);">
        <div class="container" style="max-width:800px;margin:0 auto;">
            <?php if (!empty($lpFoot['content'])): ?>
                <div style="font-size:1.1rem;line-height:1.6;margin-bottom:2rem;"><?php echo $lpFoot['content']; ?></div>
            <?php endif; ?>
            <?php if (!empty($lpFoot['button_text']) && !empty($lpFoot['button_url'])): ?>
                <div style="margin-bottom:3rem;">
                    <a href="<?php echo htmlspecialchars($lpFoot['button_url'], ENT_QUOTES, 'UTF-8'); ?>" class="btn btn-primary btn-lg"
                       style="display:inline-block;background:var(--lp-btn-primary,#b45309);color:#fff;padding:0.75rem 2rem;border-radius:99px;font-weight:600;">
                        <?php echo htmlspecialchars($lpFoot['button_text'], ENT_QUOTES, 'UTF-8'); ?>
                    </a>
                </div>
            <?php endif; ?>
            <?php if (!empty($lpFoot['copyright'])): ?>
                <div style="margin-top:2rem;padding-top:2rem;border-top:1px solid #eee;font-size:0.9rem;color:#888;">
                    <?php echo htmlspecialchars($lpFoot['copyright']); ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>

</main>
    <?php
    return; // Landing-Modus fertig – Rest von home.php überspringen
}

// ===== Beiträge-Cards Modus =====
if ($homepageMode === 'posts_grid') {

    $gridCount = 6;
    try {
        $gridCount = (int)\CMS\Services\ThemeCustomizer::instance()->get('hero', 'posts_grid_count', '6');
        if (!in_array($gridCount, [6, 9, 12])) $gridCount = 6;
    } catch (\Throwable $e) { /* default */ }

    $db     = \CMS\Database::instance();
    $prefix = $db->getPrefix();

    $gridPosts = $db->get_results(
        "SELECT p.*, c.name AS category_name
         FROM {$prefix}posts p
         LEFT JOIN {$prefix}post_categories c ON c.id = p.category_id
         WHERE p.status = 'published'
         ORDER BY p.published_at DESC
         LIMIT {$gridCount}"
    ) ?: [];

    // Schriftfarben aus Customizer
    try {
        $custGrid   = \CMS\Services\ThemeCustomizer::instance();
        $primaryCol = $custGrid->get('colors', 'primary_color',  '#2563eb');
        $headingCol = $custGrid->get('colors', 'heading_color',  '#111827');
        $textCol    = $custGrid->get('colors', 'text_color',     '#1f2937');
        $bgCol      = $custGrid->get('colors', 'bg_color',       '#ffffff');
    } catch (\Throwable $e) {
        $primaryCol = '#2563eb'; $headingCol = '#111827';
        $textCol    = '#1f2937'; $bgCol      = '#ffffff';
    }
    $primaryCol = htmlspecialchars($primaryCol, ENT_QUOTES, 'UTF-8');
    $headingCol = htmlspecialchars($headingCol, ENT_QUOTES, 'UTF-8');
    $textCol    = htmlspecialchars($textCol,    ENT_QUOTES, 'UTF-8');
    $bgCol      = htmlspecialchars($bgCol,      ENT_QUOTES, 'UTF-8');
?>
<main id="main" class="site-main" role="main">
<style>
.pg-section{padding:3.5rem 1.5rem;background:<?php echo $bgCol; ?>;}
.pg-container{max-width:1200px;margin:0 auto;}
.pg-header{text-align:center;margin-bottom:2.75rem;}
.pg-header h1{font-size:2rem;font-weight:800;color:<?php echo $headingCol; ?>;margin:0 0 .6rem;}
.pg-header p{color:<?php echo $textCol; ?>;opacity:.7;font-size:1rem;margin:0;}
.pg-grid{display:grid;gap:1.5rem;}
.pg-grid.count-6,.pg-grid.count-12{grid-template-columns:repeat(auto-fill,minmax(320px,1fr));}
.pg-grid.count-9{grid-template-columns:repeat(auto-fill,minmax(280px,1fr));}
@media(max-width:680px){.pg-grid{grid-template-columns:1fr!important;}}
.pg-card{background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;display:flex;flex-direction:column;transition:transform .2s,box-shadow .2s;}
.pg-card:hover{transform:translateY(-4px);box-shadow:0 8px 24px rgba(0,0,0,0.10);}
.pg-card-img{width:100%;height:190px;object-fit:cover;display:block;}
.pg-card-img-ph{width:100%;height:190px;background:linear-gradient(135deg,#f1f5f9,#e2e8f0);display:flex;align-items:center;justify-content:center;font-size:3rem;color:#cbd5e1;}
.pg-card-body{padding:1.25rem;flex:1;display:flex;flex-direction:column;}
.pg-card-cat{font-size:.72rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:<?php echo $primaryCol; ?>;margin-bottom:.4rem;}
.pg-card-title{font-size:1.05rem;font-weight:700;color:<?php echo $headingCol; ?>;margin:0 0 .5rem;line-height:1.35;}
.pg-card-title a{color:inherit;text-decoration:none;}
.pg-card-title a:hover{color:<?php echo $primaryCol; ?>;}
.pg-card-excerpt{font-size:.875rem;color:<?php echo $textCol; ?>;opacity:.7;line-height:1.5;flex:1;margin:0 0 1rem;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;}
.pg-card-footer{display:flex;align-items:center;justify-content:space-between;padding-top:.75rem;border-top:1px solid #f1f5f9;font-size:.78rem;color:#94a3b8;}
.pg-card-read{font-size:.82rem;font-weight:600;color:<?php echo $primaryCol; ?>;text-decoration:none;}
.pg-card-read:hover{text-decoration:underline;}
.pg-empty{text-align:center;padding:4rem 1rem;color:#94a3b8;}
.pg-empty .pg-empty-icon{font-size:3.5rem;margin-bottom:1rem;}
</style>

<section class="pg-section" aria-label="Aktuelle Beiträge">
    <div class="pg-container">
        <header class="pg-header">
            <h1>Aktuelle Beiträge</h1>
            <p>Die neuesten Inhalte auf einen Blick</p>
        </header>

        <?php if (empty($gridPosts)): ?>
        <div class="pg-empty">
            <div class="pg-empty-icon">📭</div>
            <p>Noch keine Beiträge veröffentlicht.</p>
            <?php if ($isLoggedIn && \CMS\Auth::instance()->isAdmin()): ?>
            <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/admin/posts?view=edit"
               style="color:<?php echo $primaryCol; ?>;font-weight:600;">+ Ersten Beitrag erstellen</a>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <div class="pg-grid count-<?php echo $gridCount; ?>" role="list">
            <?php foreach ($gridPosts as $gp):
                $gTitle   = htmlspecialchars($gp->title          ?? '', ENT_QUOTES, 'UTF-8');
                $gSlug    = htmlspecialchars($gp->slug           ?? '', ENT_QUOTES, 'UTF-8');
                $gExcerpt = htmlspecialchars(strip_tags($gp->excerpt ?? ''), ENT_QUOTES, 'UTF-8');
                if (!$gExcerpt && !empty($gp->content)) {
                    $gExcerpt = htmlspecialchars(mb_substr(strip_tags($gp->content), 0, 200), ENT_QUOTES, 'UTF-8');
                }
                $gDate    = $gp->published_at ? date('d.m.Y', strtotime($gp->published_at)) : '';
                $gCat     = htmlspecialchars($gp->category_name ?? '', ENT_QUOTES, 'UTF-8');
                $gImg     = htmlspecialchars($gp->featured_image ?? '', ENT_QUOTES, 'UTF-8');
                $gUrl     = htmlspecialchars($siteUrl . '/blog/' . $gSlug, ENT_QUOTES, 'UTF-8');
            ?>
            <article class="pg-card" role="listitem">
                <a href="<?php echo $gUrl; ?>" tabindex="-1" aria-hidden="true">
                    <?php if ($gImg): ?>
                        <img src="<?php echo $gImg; ?>" alt="<?php echo $gTitle; ?>" class="pg-card-img" loading="lazy">
                    <?php else: ?>
                        <div class="pg-card-img-ph" aria-hidden="true">📄</div>
                    <?php endif; ?>
                </a>
                <div class="pg-card-body">
                    <?php if ($gCat): ?>
                        <div class="pg-card-cat"><?php echo $gCat; ?></div>
                    <?php endif; ?>
                    <h2 class="pg-card-title">
                        <a href="<?php echo $gUrl; ?>"><?php echo $gTitle; ?></a>
                    </h2>
                    <?php if ($gExcerpt): ?>
                        <p class="pg-card-excerpt"><?php echo $gExcerpt; ?></p>
                    <?php endif; ?>
                    <div class="pg-card-footer">
                        <span><?php echo $gDate; ?></span>
                        <a href="<?php echo $gUrl; ?>" class="pg-card-read">Weiterlesen →</a>
                    </div>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>
</main>
<?php
    return; // Posts-Grid Modus fertig
}

// ===== Customizer: Hero-Einstellungen (Standard-Modus) =====
try {
    $customizer    = \CMS\Services\ThemeCustomizer::instance();
    $heroTitle     = $customizer->get('hero', 'hero_title',              'Willkommen auf unserer Website');
    $heroSubtitle  = $customizer->get('hero', 'hero_subtitle',           'Ihr zuverlässiger Partner');
    $heroDesc      = $customizer->get('hero', 'hero_description',        'Entdecken Sie unsere Leistungen und treten Sie mit uns in Kontakt.');
    $heroBtnPrimTxt = $customizer->get('hero', 'hero_button_primary_text',  'Mehr erfahren');
    $heroBtnPrimUrl = $customizer->get('hero', 'hero_button_primary_url',   '/about');
    $heroBtnSecTxt  = $customizer->get('hero', 'hero_button_secondary_text','Kontakt aufnehmen');
    $heroBtnSecUrl  = $customizer->get('hero', 'hero_button_secondary_url', '/contact');
    $heroGradStart  = $customizer->get('hero', 'hero_gradient_start',       '#1e40af');
    $heroGradEnd    = $customizer->get('hero', 'hero_gradient_end',         '#0369a1');
} catch (\Throwable $e) {
    $heroTitle      = 'Willkommen';
    $heroSubtitle   = 'Ihr zuverlässiger Partner';
    $heroDesc       = 'Entdecken Sie unsere Leistungen.';
    $heroBtnPrimTxt = 'Mehr erfahren';
    $heroBtnPrimUrl = '/about';
    $heroBtnSecTxt  = 'Kontakt';
    $heroBtnSecUrl  = '/contact';
    $heroGradStart  = '#1e40af';
    $heroGradEnd    = '#0369a1';
}

// ===== LandingPage Features (optional) =====
$landingFeatures = [];
try {
    $landingService  = \CMS\Services\LandingPageService::getInstance();
    $landingFeatures = $landingService->getFeatures() ?: [];
} catch (\Throwable $e) {
    // Fallback: Standard-Features
    $landingFeatures = [
        ['icon' => '⚡', 'title' => 'Schnell & Performant',    'description' => 'Optimiert für maximale Geschwindigkeit auf allen Geräten.'],
        ['icon' => '🔒', 'title' => 'Sicher & Zuverlässig',    'description' => 'Höchste Sicherheitsstandards zum Schutz Ihrer Daten.'],
        ['icon' => '🎨', 'title' => 'Individuell anpassbar',   'description' => 'Vollständig konfigurierbar für Ihr einzigartiges Branding.'],
        ['icon' => '📱', 'title' => 'Responsive Design',       'description' => 'Perfekte Darstellung auf Desktop, Tablet und Smartphone.'],
        ['icon' => '🔍', 'title' => 'SEO-optimiert',           'description' => 'Technisch sauber für bestmögliche Suchmaschinenplatzierung.'],
        ['icon' => '🤝', 'title' => 'Community & Support',     'description' => 'Persönlicher Support und aktive Community-Integration.'],
    ];
}

// HTML-Escaping
$heroTitle       = htmlspecialchars($heroTitle,      ENT_QUOTES, 'UTF-8');
$heroSubtitle    = htmlspecialchars($heroSubtitle,   ENT_QUOTES, 'UTF-8');
$heroDesc        = htmlspecialchars($heroDesc,       ENT_QUOTES, 'UTF-8');
$heroBtnPrimTxt  = htmlspecialchars($heroBtnPrimTxt, ENT_QUOTES, 'UTF-8');
$heroBtnPrimUrl  = htmlspecialchars($heroBtnPrimUrl, ENT_QUOTES, 'UTF-8');
$heroBtnSecTxt   = htmlspecialchars($heroBtnSecTxt,  ENT_QUOTES, 'UTF-8');
$heroBtnSecUrl   = htmlspecialchars($heroBtnSecUrl,  ENT_QUOTES, 'UTF-8');
$heroGradStart   = htmlspecialchars($heroGradStart,  ENT_QUOTES, 'UTF-8');
$heroGradEnd     = htmlspecialchars($heroGradEnd,    ENT_QUOTES, 'UTF-8');
?>

<main id="main" class="site-main" role="main">

    <!-- ===== Hero Section ===== -->
    <section class="default-hero"
             style="--hero-grad-start:<?php echo $heroGradStart; ?>;--hero-grad-end:<?php echo $heroGradEnd; ?>;"
             aria-labelledby="hero-heading">

        <div class="default-hero-inner">

            <?php if ($heroSubtitle && trim($heroSubtitle) !== '') : ?>
                <span class="hero-badge"><?php echo $heroSubtitle; ?></span>
            <?php endif; ?>

            <h1 id="hero-heading"><?php echo $heroTitle; ?></h1>

            <?php if ($heroDesc && trim($heroDesc) !== '') : ?>
                <p class="hero-description"><?php echo $heroDesc; ?></p>
            <?php endif; ?>

            <div class="hero-actions">

                <?php if ($heroBtnPrimTxt && trim($heroBtnPrimTxt) !== '') : ?>
                    <?php if ($isLoggedIn) : ?>
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/member"
                           class="btn btn-primary btn-lg">
                            Zum Dashboard →
                        </a>
                    <?php else : ?>
                        <a href="<?php echo htmlspecialchars($siteUrl . $heroBtnPrimUrl, ENT_QUOTES, 'UTF-8'); ?>"
                           class="btn btn-primary btn-lg">
                            <?php echo $heroBtnPrimTxt; ?> →
                        </a>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if ($heroBtnSecTxt && trim($heroBtnSecTxt) !== '') : ?>
                    <a href="<?php echo htmlspecialchars($siteUrl . $heroBtnSecUrl, ENT_QUOTES, 'UTF-8'); ?>"
                       class="btn btn-outline btn-lg">
                        <?php echo $heroBtnSecTxt; ?>
                    </a>
                <?php endif; ?>

            </div>
        </div>
    </section>

    <!-- ===== Features Section ===== -->
    <?php if (!empty($landingFeatures)) : ?>
    <section class="section section-alt" aria-label="Unsere Vorteile">
        <div class="container">
            <div class="section-header">
                <span class="section-tag">Was wir bieten</span>
                <h2>Alles was Sie brauchen</h2>
                <p>Eine Plattform, die sich Ihren Anforderungen anpasst – flexibel, sicher und einfach zu bedienen.</p>
            </div>

            <div class="feature-grid">
                <?php foreach ($landingFeatures as $feature) :
                    if (empty($feature['title'])) continue;
                    $fTitle = htmlspecialchars($feature['title'] ?? '',       ENT_QUOTES, 'UTF-8');
                    $fDesc  = htmlspecialchars($feature['description'] ?? '', ENT_QUOTES, 'UTF-8');
                    $fIcon  = htmlspecialchars($feature['icon'] ?? '✦',       ENT_QUOTES, 'UTF-8');
                ?>
                    <div class="feature-card">
                        <div class="feature-icon" aria-hidden="true"><?php echo $fIcon; ?></div>
                        <h3><?php echo $fTitle; ?></h3>
                        <?php if ($fDesc && trim($fDesc) !== '') : ?>
                            <p><?php echo $fDesc; ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ===== CTA Section ===== -->
    <section class="section"
             style="background:linear-gradient(135deg,<?php echo $heroGradStart; ?>,<?php echo $heroGradEnd; ?>);color:#fff;"
             aria-label="Jetzt starten">
        <div class="container text-center">
            <?php if (!$isLoggedIn) : ?>
                <h2 style="color:#fff;margin-bottom:1rem;">Jetzt kostenlos starten</h2>
                <p style="color:rgba(255,255,255,0.8);max-width:480px;margin:0 auto 2rem;font-size:1.0625rem;">
                    Registrieren Sie sich noch heute und nutzen Sie alle Funktionen auf unserer Plattform.
                </p>
                <div class="hero-actions">
                    <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/register"
                       class="btn btn-primary btn-lg"
                       style="background:#fff;color:var(--primary-color);border-color:#fff;">
                        Kostenlos registrieren
                    </a>
                    <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/login"
                       class="btn btn-outline btn-lg">
                        Anmelden
                    </a>
                </div>
            <?php else : ?>
                <h2 style="color:#fff;margin-bottom:1rem;">Willkommen zurück!</h2>
                <p style="color:rgba(255,255,255,0.8);max-width:480px;margin:0 auto 2rem;font-size:1.0625rem;">
                    Gehen Sie direkt zu Ihrem persönlichen Dashboard.
                </p>
                <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/member"
                   class="btn btn-primary btn-lg"
                   style="background:#fff;color:var(--primary-color);border-color:#fff;">
                    Zum Dashboard →
                </a>
            <?php endif; ?>
        </div>
    </section>

</main>
