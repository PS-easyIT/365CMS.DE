<?php
/**
 * Header Template
 *
 * @package CMS_Default_Theme
 */

if (!defined('ABSPATH')) {
    exit;
}

$themeManager = \CMS\ThemeManager::instance();
$siteTitle    = $themeManager->getSiteTitle();
$siteDesc     = $themeManager->getSiteDescription();
$themeUrl     = $themeManager->getThemeUrl();
$isLoggedIn   = theme_is_logged_in();
$siteUrl      = SITE_URL;

// Logo aus Customizer
try {
    $_logoUrl = \CMS\Services\ThemeCustomizer::instance()->get('header', 'logo_url', '');
} catch (\Throwable $_e) {
    $_logoUrl = '';
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'); ?></title>
    <?php \CMS\Hooks::doAction('head'); ?>
</head>

<body>
<?php \CMS\Hooks::doAction('body_open'); ?>
<div id="page" class="site">
    <a class="skip-link" href="#content">Zum Inhalt springen</a>

    <header id="masthead" class="site-header" role="banner">
        <div class="header-container">
            <div class="header-inner">

                <!-- Branding -->
                <div class="site-branding">
                    <div class="site-logo">
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/"
                           aria-label="<?php echo htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'); ?> – Zur Startseite">
                            <?php if (!empty($_logoUrl)) : ?>
                                <img src="<?php echo htmlspecialchars($_logoUrl, ENT_QUOTES, 'UTF-8'); ?>"
                                     alt="<?php echo htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'); ?>"
                                     width="160" height="48">
                            <?php else : ?>
                                <!-- Default SVG Logo Icon -->
                                <svg class="default-logo-icon" viewBox="0 0 44 44" fill="none"
                                     xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <rect width="44" height="44" rx="10" fill="currentColor" opacity="0.1"/>
                                    <path d="M22 8L34 14V26L22 32L10 26V14L22 8Z"
                                          stroke="currentColor" stroke-width="2"
                                          stroke-linejoin="round" fill="none"/>
                                    <circle cx="22" cy="20" r="4" fill="currentColor"/>
                                    <path d="M22 24v8M14 16l8 4M30 16l-8 4"
                                          stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                            <?php endif; ?>
                        </a>
                    </div>
                    <div class="site-identity">
                        <p class="site-title">
                            <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/" rel="home">
                                <?php echo htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'); ?>
                            </a>
                        </p>
                        <?php if ($siteDesc && trim($siteDesc) !== '') : ?>
                            <p class="site-description">
                                <?php echo htmlspecialchars($siteDesc, ENT_QUOTES, 'UTF-8'); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Desktop Navigation -->
                <nav id="site-navigation" class="main-navigation"
                     role="navigation" aria-label="Hauptnavigation">
                    <?php theme_nav_menu('primary'); ?>
                </nav>

                <!-- Header Actions -->
                <div class="header-actions">

                    <!-- Dark Mode Toggle -->
                    <button class="theme-toggle" id="themeToggle"
                            aria-label="Farbschema wechseln" type="button" title="Dark Mode">
                        <span class="theme-toggle-icon dark-icon" aria-hidden="true">🌙</span>
                        <span class="theme-toggle-icon light-icon" aria-hidden="true">☀️</span>
                    </button>

                    <!-- Suche -->
                    <button class="search-toggle" id="searchToggle"
                            aria-label="Suche öffnen" type="button" aria-expanded="false">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                             stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <circle cx="11" cy="11" r="8"/>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                        </svg>
                    </button>

                    <!-- Login/Dashboard Button (optional) -->
                    <?php if ($isLoggedIn) : ?>
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/member"
                           class="btn btn-primary btn-sm" style="display:none;" id="headerDashBtn">
                            Dashboard
                        </a>
                    <?php else : ?>
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/login"
                           class="btn btn-primary btn-sm" id="headerLoginBtn">
                            Anmelden
                        </a>
                    <?php endif; ?>

                    <!-- Mobile Menu Toggle -->
                    <button class="mobile-menu-toggle" id="mobileMenuToggle"
                            aria-label="Menü öffnen" aria-expanded="false"
                            aria-controls="mobileMenuDrawer" type="button">
                        <span class="hamburger" aria-hidden="true">
                            <span class="line"></span>
                            <span class="line"></span>
                            <span class="line"></span>
                        </span>
                    </button>

                </div>
            </div>
        </div>
    </header>

    <!-- Mobile Menu Overlay -->
    <div class="mobile-menu-overlay" id="mobileMenuOverlay" role="presentation"></div>

    <!-- Mobile Menu Drawer -->
    <nav id="mobileMenuDrawer" class="mobile-menu-drawer"
         aria-label="Mobile Navigation" aria-hidden="true">
        <div style="margin-bottom:1.5rem;padding-bottom:1rem;border-bottom:1px solid var(--border-color);">
            <strong style="font-size:1.0625rem;color:var(--heading-color);">
                <?php echo htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'); ?>
            </strong>
        </div>
        <?php theme_nav_menu('mobile'); ?>
        <div style="margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--border-color);">
            <?php if ($isLoggedIn) : ?>
                <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/member"
                   class="btn btn-primary" style="width:100%;justify-content:center;">
                    Mein Dashboard
                </a>
            <?php else : ?>
                <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/login"
                   class="btn btn-primary" style="width:100%;justify-content:center;">
                    Anmelden
                </a>
            <?php endif; ?>
        </div>
    </nav>

    <!-- Search Overlay -->
    <div class="search-overlay" id="searchOverlay"
         role="dialog" aria-label="Suche" aria-hidden="true" aria-modal="true">
        <button class="search-overlay-close" id="searchOverlayClose"
                aria-label="Suche schließen" type="button">×</button>
        <div class="search-overlay-inner">
            <form class="search-overlay-form"
                  action="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/search"
                  method="GET" role="search">
                <input class="search-overlay-input" type="search" name="q"
                       placeholder="Suche eingeben…" autocomplete="off" spellcheck="false"
                       aria-label="Suchbegriff">
                <button type="submit" class="search-overlay-submit" aria-label="Suchen">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <circle cx="11" cy="11" r="8"/>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                    </svg>
                </button>
            </form>
        </div>
    </div>

    <div id="content" class="site-content">
