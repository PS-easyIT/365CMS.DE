<?php
/**
 * Search Results Template
 *
 * @package CMS_Default_Theme
 * @var string $query    Suchbegriff
 * @var array  $results  Suchergebnisse
 * @var int    $total    Gesamtanzahl
 */

if (!defined('ABSPATH')) {
    exit;
}

$query   = isset($query)   ? htmlspecialchars((string)$query, ENT_QUOTES, 'UTF-8') : '';
$results = $results ?? [];
$total   = $total   ?? count($results);
$siteUrl = SITE_URL;

// Fallback: Query aus GET holen
if ($query === '' && isset($_GET['q'])) {
    $query = htmlspecialchars(trim((string)$_GET['q']), ENT_QUOTES, 'UTF-8');
}
?>

<main id="main" class="site-main" role="main">
    <div class="container">
        <div class="content-area">

            <!-- Suchformular -->
            <section class="search-form-section" style="margin-bottom:var(--spacing-xl);">
                <form action="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/search"
                      method="GET" role="search">
                    <div style="display:flex;gap:.5rem;max-width:600px;">
                        <input type="search" name="q"
                               value="<?php echo $query; ?>"
                               placeholder="Suche eingeben…"
                               aria-label="Suche"
                               class="form-control"
                               style="font-size:1.0625rem;">
                        <button type="submit" class="btn btn-primary" aria-label="Suchen">
                            Suchen
                        </button>
                    </div>
                </form>
            </section>

            <!-- Ergebnis-Header -->
            <?php if ($query !== '') : ?>
            <div class="search-results-header">
                <p class="search-results-count">
                    <?php if ($total > 0) : ?>
                        <strong><?php echo (int)$total; ?></strong>
                        <?php echo $total === 1 ? 'Ergebnis' : 'Ergebnisse'; ?>
                        für „<?php echo $query; ?>"
                    <?php else : ?>
                        Keine Ergebnisse für „<?php echo $query; ?>"
                    <?php endif; ?>
                </p>
            </div>
            <?php endif; ?>

            <!-- Ergebnisliste -->
            <?php if (!empty($results)) : ?>
                <div class="search-results-list">
                    <?php foreach ($results as $result) :
                        $rTitle   = htmlspecialchars($result['title']   ?? 'Ohne Titel', ENT_QUOTES, 'UTF-8');
                        $rUrl     = htmlspecialchars($result['url']     ?? '#',          ENT_QUOTES, 'UTF-8');
                        $rExcerpt = htmlspecialchars($result['excerpt'] ?? '',           ENT_QUOTES, 'UTF-8');
                        $rDate    = !empty($result['date'])
                            ? htmlspecialchars(date('d.m.Y', strtotime($result['date'])), ENT_QUOTES, 'UTF-8')
                            : '';
                    ?>
                    <article class="search-result-item">
                        <h2 class="search-result-title">
                            <a href="<?php echo $rUrl; ?>"><?php echo $rTitle; ?></a>
                        </h2>
                        <?php if ($rDate && trim($rDate) !== '') : ?>
                            <div class="entry-meta" style="margin-bottom:.375rem;">
                                <time><?php echo $rDate; ?></time>
                            </div>
                        <?php endif; ?>
                        <?php if ($rExcerpt && trim($rExcerpt) !== '') : ?>
                            <p class="search-result-excerpt"><?php echo $rExcerpt; ?></p>
                        <?php endif; ?>
                    </article>
                    <?php endforeach; ?>
                </div>

            <?php elseif ($query !== '') : ?>
                <div style="text-align:center;padding:var(--spacing-xl) 0;">
                    <p style="font-size:1.0625rem;color:var(--text-muted);margin-bottom:var(--spacing-lg);">
                        Keine Ergebnisse gefunden. Bitte versuchen Sie einen anderen Suchbegriff.
                    </p>
                    <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/"
                       class="btn btn-secondary">
                        ← Zur Startseite
                    </a>
                </div>
            <?php else : ?>
                <div style="text-align:center;padding:var(--spacing-xl) 0;color:var(--text-muted);">
                    <p>Bitte geben Sie einen Suchbegriff ein.</p>
                </div>
            <?php endif; ?>

        </div>
    </div>
</main>
