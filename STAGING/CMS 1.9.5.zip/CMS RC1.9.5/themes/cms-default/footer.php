<?php
/**
 * Footer Template
 *
 * @package CMS_Default_Theme
 */

if (!defined('ABSPATH')) {
    exit;
}

$themeManager = \CMS\ThemeManager::instance();
$siteTitle    = $themeManager->getSiteTitle();
$isLoggedIn   = theme_is_logged_in();
$siteUrl      = SITE_URL;

// Customizer Settings
try {
    $customizer         = \CMS\Services\ThemeCustomizer::instance();
    $footerText         = $customizer->get('footer', 'footer_text', 'Willkommen auf unserer Website. Ihr Kontakt für alle Anliegen.');
    $showWidgets        = $customizer->get('footer', 'show_footer_widgets', true);
    $copyrightTemplate  = $customizer->get('footer', 'copyright_text', '&copy; {year} {site_title}. Alle Rechte vorbehalten.');
} catch (\Throwable $e) {
    $footerText         = 'Willkommen auf unserer Website.';
    $showWidgets        = true;
    $copyrightTemplate  = '&copy; {year} {site_title}. Alle Rechte vorbehalten.';
}

// Copyright Platzhalter ersetzen
$copyrightText = str_replace(
    ['{year}', '{site_title}'],
    [gmdate('Y'), htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8')],
    $copyrightTemplate
);
?>
    </div><!-- #content .site-content -->

    <footer id="colophon" class="site-footer" role="contentinfo" aria-label="Seitenfuß">

        <div class="footer-content-band">
            <div class="footer-container">

                <?php if ($showWidgets) : ?>
                <div class="footer-widgets">

                    <!-- Spalte 1: Über -->
                    <div class="footer-widget">
                        <h3 class="footer-widget-title">
                            <?php echo htmlspecialchars($siteTitle, ENT_QUOTES, 'UTF-8'); ?>
                        </h3>
                        <p><?php echo nl2br(htmlspecialchars($footerText, ENT_QUOTES, 'UTF-8')); ?></p>
                    </div>

                    <!-- Spalte 2: Navigation -->
                    <div class="footer-widget">
                        <h3 class="footer-widget-title">Navigation</h3>
                        <ul>
                            <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/">Startseite</a></li>
                            <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/about">Über uns</a></li>
                            <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/services">Leistungen</a></li>
                            <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/blog">Blog</a></li>
                            <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/contact">Kontakt</a></li>
                        </ul>
                    </div>

                    <!-- Spalte 3: Konto -->
                    <div class="footer-widget">
                        <h3 class="footer-widget-title">Mein Konto</h3>
                        <ul>
                            <?php if ($isLoggedIn) : ?>
                                <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/member">Mein Dashboard</a></li>
                                <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/member/profile">Mein Profil</a></li>
                                <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/member/settings">Einstellungen</a></li>
                                <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/logout">Abmelden</a></li>
                            <?php else : ?>
                                <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/login">Anmelden</a></li>
                                <li><a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/register">Registrieren</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>

                </div>
                <?php endif; ?>

                <!-- Footer Bottom Bar -->
                <div class="footer-bottom">
                    <p><?php echo $copyrightText; ?></p>

                    <nav class="footer-legal-nav" aria-label="Rechtliche Informationen">
                        <?php theme_nav_menu('footer'); ?>
                    </nav>

                    <?php if ($isLoggedIn) : ?>
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/member"
                           class="footer-dashboard-btn">
                            ↗ Dashboard
                        </a>
                    <?php else : ?>
                        <a href="<?php echo htmlspecialchars($siteUrl, ENT_QUOTES, 'UTF-8'); ?>/login"
                           class="footer-login-btn">
                            Anmelden
                        </a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </footer>

</div><!-- #page .site -->

<?php \CMS\Hooks::doAction('before_footer'); ?>

</body>
</html>
