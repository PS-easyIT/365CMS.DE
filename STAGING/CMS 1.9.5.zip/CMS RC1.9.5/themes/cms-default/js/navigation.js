/**
 * Navigation - Mobile Menu, Search Overlay & Header Scroll
 *
 * @package CMS_Default_Theme
 */

(function () {
    'use strict';

    function init() {

        // ===== Header Scroll =====
        const header = document.getElementById('masthead');
        if (header) {
            let ticking = false;
            window.addEventListener('scroll', function () {
                if (!ticking) {
                    window.requestAnimationFrame(function () {
                        header.classList.toggle('scrolled', window.scrollY > 60);
                        ticking = false;
                    });
                    ticking = true;
                }
            }, { passive: true });
        }

        // ===== Mobile Menu =====
        const mobileToggle  = document.getElementById('mobileMenuToggle');
        const mobileDrawer  = document.getElementById('mobileMenuDrawer');
        const mobileOverlay = document.getElementById('mobileMenuOverlay');

        function openMobileMenu() {
            if (!mobileDrawer) return;
            mobileDrawer.classList.add('is-open');
            mobileDrawer.setAttribute('aria-hidden', 'false');
            if (mobileOverlay) mobileOverlay.classList.add('is-open');
            if (mobileToggle) {
                mobileToggle.classList.add('is-active');
                mobileToggle.setAttribute('aria-expanded', 'true');
                mobileToggle.setAttribute('aria-label', 'Menü schließen');
            }
            document.body.style.overflow = 'hidden';
        }

        function closeMobileMenu() {
            if (!mobileDrawer) return;
            mobileDrawer.classList.remove('is-open');
            mobileDrawer.setAttribute('aria-hidden', 'true');
            if (mobileOverlay) mobileOverlay.classList.remove('is-open');
            if (mobileToggle) {
                mobileToggle.classList.remove('is-active');
                mobileToggle.setAttribute('aria-expanded', 'false');
                mobileToggle.setAttribute('aria-label', 'Menü öffnen');
            }
            document.body.style.overflow = '';
        }

        if (mobileToggle) {
            mobileToggle.addEventListener('click', function () {
                const isOpen = mobileDrawer && mobileDrawer.classList.contains('is-open');
                isOpen ? closeMobileMenu() : openMobileMenu();
            });
        }

        if (mobileOverlay) {
            mobileOverlay.addEventListener('click', closeMobileMenu);
        }

        // ===== Search Overlay =====
        const searchToggle  = document.getElementById('searchToggle');
        const searchOverlay = document.getElementById('searchOverlay');
        const searchClose   = document.getElementById('searchOverlayClose');

        function openSearchOverlay() {
            if (!searchOverlay) return;
            searchOverlay.classList.add('is-active');
            searchOverlay.setAttribute('aria-hidden', 'false');
            if (searchToggle) searchToggle.setAttribute('aria-expanded', 'true');
            document.body.style.overflow = 'hidden';
            const input = searchOverlay.querySelector('input[type="search"]');
            if (input) setTimeout(function () { input.focus(); }, 80);
        }

        function closeSearchOverlay() {
            if (!searchOverlay) return;
            searchOverlay.classList.remove('is-active');
            searchOverlay.setAttribute('aria-hidden', 'true');
            if (searchToggle) {
                searchToggle.setAttribute('aria-expanded', 'false');
                searchToggle.focus();
            }
            document.body.style.overflow = '';
        }

        if (searchToggle) {
            searchToggle.addEventListener('click', openSearchOverlay);
        }
        if (searchClose) {
            searchClose.addEventListener('click', closeSearchOverlay);
        }
        if (searchOverlay) {
            searchOverlay.addEventListener('click', function (e) {
                if (e.target === searchOverlay) closeSearchOverlay();
            });
        }

        // ===== ESC schließt alles =====
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                closeMobileMenu();
                closeSearchOverlay();
            }
        });

        // ===== Focus Trap für Mobile Menu =====
        if (mobileDrawer) {
            mobileDrawer.addEventListener('keydown', function (e) {
                if (e.key !== 'Tab') return;
                const focusable = mobileDrawer.querySelectorAll(
                    'a[href], button:not([disabled]), input, textarea, select, [tabindex]:not([tabindex="-1"])'
                );
                if (focusable.length === 0) return;
                const first = focusable[0];
                const last  = focusable[focusable.length - 1];

                if (e.shiftKey && document.activeElement === first) {
                    e.preventDefault();
                    last.focus();
                } else if (!e.shiftKey && document.activeElement === last) {
                    e.preventDefault();
                    first.focus();
                }
            });
        }

    }

    // Init – sicher gegen race conditions
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

}());
