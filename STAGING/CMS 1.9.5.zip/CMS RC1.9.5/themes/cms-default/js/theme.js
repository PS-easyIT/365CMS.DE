/**
 * Theme JS – Dark Mode, Scroll-to-Top, Smooth-Scroll
 *
 * @package CMS_Default_Theme
 */

(function () {
    'use strict';

    const STORAGE_KEY = 'cms_dark_mode';
    const DARK_CLASS  = 'dark-mode';
    const body        = document.body;

    // ============================================================
    // DARK MODE
    // ============================================================

    function getStoredMode() {
        try {
            const stored = localStorage.getItem(STORAGE_KEY);
            if (stored !== null) return stored === '1';
        } catch (e) { /* localStorage blockiert */ }
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    }

    function applyDarkMode(isDark) {
        body.classList.toggle(DARK_CLASS, isDark);
    }

    function toggleDarkMode() {
        const isDark = body.classList.toggle(DARK_CLASS);
        try { localStorage.setItem(STORAGE_KEY, isDark ? '1' : '0'); } catch (e) { /* noop */ }
        updateToggleLabel(isDark);
    }

    function updateToggleLabel(isDark) {
        const btn = document.getElementById('themeToggle');
        if (btn) {
            btn.setAttribute('aria-label', isDark ? 'Hell-Modus aktivieren' : 'Dunkel-Modus aktivieren');
            btn.setAttribute('title',      isDark ? 'Hell-Modus' : 'Dunkel-Modus');
        }
    }

    // Sofort anwenden – verhindert FOUC
    applyDarkMode(getStoredMode());

    document.addEventListener('DOMContentLoaded', function () {

        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', toggleDarkMode);
            updateToggleLabel(body.classList.contains(DARK_CLASS));
        }

        // Auf System-Präferenzänderung reagieren (nur wenn keine gespeicherte Einstellung)
        if (window.matchMedia) {
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function (e) {
                try {
                    if (localStorage.getItem(STORAGE_KEY) === null) {
                        applyDarkMode(e.matches);
                        updateToggleLabel(e.matches);
                    }
                } catch (err) { /* noop */ }
            });
        }

        // ============================================================
        // SCROLL-TO-TOP BUTTON
        // ============================================================
        const scrollBtn = document.createElement('button');
        scrollBtn.id        = 'scrollToTop';
        scrollBtn.type      = 'button';
        scrollBtn.title     = 'Nach oben scrollen';
        scrollBtn.setAttribute('aria-label', 'Nach oben scrollen');
        scrollBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" '
            + 'stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" '
            + 'aria-hidden="true"><path d="M18 15l-6-6-6 6"/></svg>';

        Object.assign(scrollBtn.style, {
            position:         'fixed',
            bottom:           '1.75rem',
            right:            '1.75rem',
            width:            '46px',
            height:           '46px',
            borderRadius:     '50%',
            background:       'var(--primary-color)',
            color:            '#fff',
            border:           'none',
            cursor:           'pointer',
            display:          'flex',
            alignItems:       'center',
            justifyContent:   'center',
            boxShadow:        '0 4px 14px rgba(37,99,235,0.4)',
            opacity:          '0',
            visibility:       'hidden',
            transform:        'translateY(8px)',
            transition:       'opacity .3s ease, visibility .3s ease, transform .3s ease',
            zIndex:           '9990',
        });

        document.body.appendChild(scrollBtn);

        let scrollTicking = false;
        window.addEventListener('scroll', function () {
            if (!scrollTicking) {
                window.requestAnimationFrame(function () {
                    const show = window.scrollY > 400;
                    scrollBtn.style.opacity    = show ? '1' : '0';
                    scrollBtn.style.visibility = show ? 'visible' : 'hidden';
                    scrollBtn.style.transform  = show ? 'translateY(0)' : 'translateY(8px)';
                    scrollTicking = false;
                });
                scrollTicking = true;
            }
        }, { passive: true });

        scrollBtn.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        // ============================================================
        // SMOOTH SCROLL für Anker-Links
        // ============================================================
        document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
            anchor.addEventListener('click', function (e) {
                const href = anchor.getAttribute('href');
                if (!href || href === '#') return;
                const target = document.querySelector(href);
                if (!target) return;
                e.preventDefault();
                const headerHeight = document.getElementById('masthead')
                    ? document.getElementById('masthead').offsetHeight
                    : 80;
                const top = target.getBoundingClientRect().top + window.scrollY - headerHeight - 16;
                window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
                target.setAttribute('tabindex', '-1');
                target.focus({ preventScroll: true });
            });
        });

        // ============================================================
        // EXTERNAL LINKS – sicherheitshalber rel="noopener" setzen
        // ============================================================
        document.querySelectorAll('a[target="_blank"]').forEach(function (a) {
            if (!a.rel.includes('noopener')) {
                a.rel = (a.rel ? a.rel + ' ' : '') + 'noopener noreferrer';
            }
        });

        // ============================================================
        // FORM ENHANCEMENTS – Passwort-Stärke-Indikator (optional)
        // ============================================================
        const pwInput = document.getElementById('password');
        if (pwInput && document.getElementById('password_confirm')) {
            const form = pwInput.closest('form');
            if (form) {
                form.addEventListener('submit', function (e) {
                    const pw      = document.getElementById('password');
                    const pwConf  = document.getElementById('password_confirm');
                    if (pw && pwConf && pw.value !== pwConf.value) {
                        e.preventDefault();
                        pwConf.setCustomValidity('Passwörter stimmen nicht überein.');
                        pwConf.reportValidity();
                    } else if (pwConf) {
                        pwConf.setCustomValidity('');
                    }
                });

                const pwConf = document.getElementById('password_confirm');
                if (pwConf) {
                    pwConf.addEventListener('input', function () {
                        this.setCustomValidity('');
                    });
                }
            }
        }

    });

}());
