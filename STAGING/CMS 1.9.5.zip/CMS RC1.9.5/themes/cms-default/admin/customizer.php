<?php
/**
 * CMS Default Theme – eigener Admin-Customizer
 *
 * Wird vom CMS-Dispatcher (admin/theme-customizer.php) eingebunden.
 * Auth + ThemeCustomizer sind bereits initialisiert.
 *
 * @package CMS_Default_Theme\Admin
 */

declare(strict_types=1);

use CMS\Auth;
use CMS\Security;
use CMS\ThemeManager;
use CMS\Services\ThemeCustomizer;

// Bereits durch den Dispatcher gesichert, trotzdem doppelt prüfen
if (!Auth::instance()->isAdmin()) {
    header('Location: ' . SITE_URL . '/login');
    exit;
}

$security   = Security::instance();
$customizer = ThemeCustomizer::instance();                // Datenschicht des CMS
$themeMeta  = $customizer->getThemeMetadata();
$options    = $customizer->getCustomizationOptions();     // aus theme.json

$message     = '';
$messageType = '';
$activeTab   = $_GET['tab'] ?? 'colors';

// ── POST-Handler ─────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['_action'])) {
    if (!$security->verifyToken($_POST['_csrf'] ?? '', 'cms_default_customizer')) {
        $message     = 'Sicherheitsüberprüfung fehlgeschlagen.';
        $messageType = 'error';
    } else {
        $action   = $_POST['_action'];
        $category = $_POST['_category'] ?? '';

        if ($action === 'save' && $category && isset($options[$category])) {
            $settings = $_POST['settings'] ?? [];

            // Bild-Upload (logo)
            foreach ($_FILES as $fileKey => $fileData) {
                if (!str_starts_with($fileKey, 'img_upload_')) { continue; }
                if (($fileData['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) { continue; }
                $settingKey   = substr($fileKey, strlen('img_upload_'));
                $allowedMimes = ['image/jpeg','image/png','image/gif','image/webp','image/svg+xml'];
                $finfo        = new \finfo(FILEINFO_MIME_TYPE);
                if (!in_array($finfo->file($fileData['tmp_name']), $allowedMimes, true)) {
                    $message = 'Ungültiger Dateityp.'; $messageType = 'error'; break;
                }
                $uploadDir = ABSPATH . 'uploads/theme/';
                if (!is_dir($uploadDir)) { mkdir($uploadDir, 0755, true); }
                $ext      = strtolower(pathinfo($fileData['name'], PATHINFO_EXTENSION));
                $filename = 'logo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                if (move_uploaded_file($fileData['tmp_name'], $uploadDir . $filename)) {
                    $settings[$settingKey] = SITE_URL . '/uploads/theme/' . $filename;
                }
            }

            if (empty($message)) {
                $customizer->setMultiple([$category => $settings]);
                $message     = 'Gespeichert ✓';
                $messageType = 'success';
            }

        } elseif ($action === 'reset_category' && $category && isset($options[$category])) {
            foreach (array_keys($options[$category]['settings'] ?? []) as $key) {
                $customizer->reset($category, $key);
            }
            $message = 'Kategorie zurückgesetzt.'; $messageType = 'info';

        } elseif ($action === 'reset_all') {
            $customizer->resetAll();
            $message = 'Alle Einstellungen zurückgesetzt.'; $messageType = 'info';
        }

        // PRG-Redirect
        $qs = '?tab=' . urlencode($category ?: $activeTab)
            . '&msg=' . urlencode($message)
            . '&mtype=' . urlencode($messageType);
        header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?') . $qs);
        exit;
    }
}

// GET-Message
if (isset($_GET['msg'])) {
    $message     = htmlspecialchars(urldecode($_GET['msg']), ENT_QUOTES, 'UTF-8');
    $messageType = in_array($_GET['mtype'] ?? '', ['success','error','info','warning'], true)
                   ? $_GET['mtype'] : 'info';
}

$csrfToken = $security->generateToken('cms_default_customizer');

// Admin-Menü (CMS stellt Sidebar bereit)
require_once ABSPATH . 'admin/partials/admin-menu.php';

// ── Hilfsfunktion: Setting-Control rendern ────────────────────────────────────
function cmsDefaultRenderControl(string $category, string $key, array $cfg, mixed $value): void
{
    $id   = 'cms_' . $category . '_' . $key;
    $name = 'settings[' . $key . ']';
    $type = $cfg['type'] ?? 'text';

    echo '<div class="cdc-field">';
    echo '<label class="cdc-label" for="' . htmlspecialchars($id) . '">'
       . htmlspecialchars($cfg['label'] ?? $key) . '</label>';
    if (!empty($cfg['description'])) {
        echo '<p class="cdc-hint">' . htmlspecialchars($cfg['description']) . '</p>';
    }

    switch ($type) {
        case 'color':
            echo '<div class="cdc-color-wrap">';
            echo '<input type="color" id="' . $id . '" name="' . $name . '" value="'
               . htmlspecialchars($value ?: '#000000') . '" class="cdc-color-picker">';
            echo '<input type="text" class="cdc-color-text" value="'
               . htmlspecialchars($value ?: '') . '" maxlength="9" placeholder="#000000">';
            echo '</div>';
            break;

        case 'checkbox':
            $checked = $value === true || $value === '1' || $value === 'true' || $value === 1;
            // Hidden input zuerst → sendet '0' wenn Checkbox nicht angehakt
            echo '<input type="hidden" name="' . $name . '" value="0">';
            echo '<label class="cdc-toggle"><input type="checkbox" id="' . $id . '" name="' . $name
               . '" value="1"' . ($checked ? ' checked' : '') . '>'
               . '<span class="cdc-toggle-slider"></span></label>';
            break;

        case 'select':
            echo '<select id="' . $id . '" name="' . $name . '" class="cdc-select">';
            foreach ($cfg['options'] ?? [] as $optVal => $optLabel) {
                $sel = (string)$value === (string)$optVal ? ' selected' : '';
                echo '<option value="' . htmlspecialchars((string)$optVal) . '"' . $sel . '>'
                   . htmlspecialchars($optLabel) . '</option>';
            }
            echo '</select>';
            break;

        case 'textarea':
            echo '<textarea id="' . $id . '" name="' . $name . '" class="cdc-textarea" rows="4">'
               . htmlspecialchars((string)$value) . '</textarea>';
            break;

        case 'image':
            $imgSrc = !empty($value) ? $value : '';
            echo '<div class="cdc-image-upload">';
            if ($imgSrc) {
                echo '<img src="' . htmlspecialchars($imgSrc) . '" class="cdc-img-preview" alt="Logo-Vorschau">';
            } else {
                echo '<div class="cdc-img-placeholder">Kein Bild ausgewählt</div>';
            }
            echo '<input type="hidden" id="' . $id . '" name="' . $name . '" value="'
               . htmlspecialchars((string)$value) . '">';
            echo '<label class="cdc-btn cdc-btn-sm" style="margin-top:.5rem;cursor:pointer;">'
               . '📁 Bild hochladen'
               . '<input type="file" name="img_upload_' . htmlspecialchars($key) . '" accept="image/*" style="display:none"></label>';
            if ($imgSrc) {
                echo '<button type="button" class="cdc-btn cdc-btn-sm cdc-btn-danger" '
                   . 'onclick="document.getElementById(\'' . $id . '\').value=\'\';this.closest(\'.cdc-image-upload\').querySelector(\'.cdc-img-preview,.cdc-img-placeholder\').outerHTML=\'<div class=cdc-img-placeholder>Kein Bild</div>\'">'
                   . '✕ Entfernen</button>';
            }
            echo '</div>';
            break;

        case 'number':
            echo '<input type="number" id="' . $id . '" name="' . $name . '" value="'
               . htmlspecialchars((string)$value) . '" class="cdc-input"'
               . (!empty($cfg['min']) ? ' min="' . (int)$cfg['min'] . '"' : '')
               . (!empty($cfg['max']) ? ' max="' . (int)$cfg['max'] . '"' : '') . '>';
            break;

        default: // text, url, email
            echo '<input type="text" id="' . $id . '" name="' . $name . '" value="'
               . htmlspecialchars((string)$value) . '" class="cdc-input" placeholder="'
               . htmlspecialchars($cfg['placeholder'] ?? '') . '">';
    }

    echo '</div>';
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Design · <?php echo htmlspecialchars($themeMeta['name']); ?></title>
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/admin.css?v=<?php echo CMS_VERSION; ?>">
    <?php renderAdminSidebarStyles(); ?>
    <style>
        /* ── CMS Default Theme Customizer – eigenes Design ── */
        :root {
            --cdc-primary:   #2563eb;
            --cdc-primary-d: #1d4ed8;
            --cdc-accent:    #0ea5e9;
            --cdc-bg:        #f8fafc;
            --cdc-surface:   #ffffff;
            --cdc-border:    #e2e8f0;
            --cdc-text:      #1e293b;
            --cdc-muted:     #64748b;
            --cdc-success:   #22c55e;
            --cdc-error:     #ef4444;
            --cdc-warning:   #f59e0b;
            --cdc-radius:    10px;
        }

        .cdc-wrapper        { padding: 1.5rem 2rem; }
        .cdc-header         { display:flex; align-items:center; justify-content:space-between; margin-bottom:1.5rem; gap:1rem; flex-wrap:wrap; }
        .cdc-header-brand   { display:flex; align-items:center; gap:.75rem; }
        .cdc-header-icon    { width:44px; height:44px; background:linear-gradient(135deg,var(--cdc-primary),var(--cdc-accent)); border-radius:var(--cdc-radius); display:flex; align-items:center; justify-content:center; font-size:1.4rem; }
        .cdc-header-title   { font-size:1.4rem; font-weight:700; color:var(--cdc-text); margin:0; }
        .cdc-header-sub     { font-size:.8rem; color:var(--cdc-muted); margin:0; }
        .cdc-header-actions { display:flex; gap:.5rem; flex-wrap:wrap; }

        .cdc-layout         { display:grid; grid-template-columns:220px 1fr; gap:1.5rem; align-items:start; }
        @media(max-width:900px){ .cdc-layout{ grid-template-columns:1fr; } }

        /* Sidebar-Nav */
        .cdc-nav            { background:var(--cdc-surface); border:1px solid var(--cdc-border); border-radius:var(--cdc-radius); overflow:hidden; position:sticky; top:1.5rem; }
        .cdc-nav-header     { padding:.75rem 1rem; background:linear-gradient(135deg,var(--cdc-primary),var(--cdc-accent)); color:#fff; font-size:.75rem; font-weight:600; text-transform:uppercase; letter-spacing:.05em; }
        .cdc-nav-item       { display:flex; align-items:center; gap:.6rem; padding:.75rem 1rem; cursor:pointer; font-size:.875rem; color:var(--cdc-muted); border-left:3px solid transparent; transition:all .2s; text-decoration:none; }
        .cdc-nav-item:hover { background:#f1f5f9; color:var(--cdc-text); }
        .cdc-nav-item.active{ background:#eff6ff; color:var(--cdc-primary); border-left-color:var(--cdc-primary); font-weight:600; }
        .cdc-nav-item .cdc-nav-icon { font-size:1rem; width:1.25rem; text-align:center; }

        /* Content-Panel */
        .cdc-panel          { background:var(--cdc-surface); border:1px solid var(--cdc-border); border-radius:var(--cdc-radius); overflow:hidden; }
        .cdc-panel-head     { padding:1.25rem 1.5rem; border-bottom:1px solid var(--cdc-border); display:flex; align-items:center; justify-content:space-between; gap:1rem; flex-wrap:wrap; }
        .cdc-panel-title    { font-size:1.1rem; font-weight:700; color:var(--cdc-text); margin:0; }
        .cdc-panel-desc     { font-size:.8rem; color:var(--cdc-muted); margin:.2rem 0 0 0; }
        .cdc-panel-body     { padding:1.5rem; }

        .cdc-tab-content    { display:none; }
        .cdc-tab-content.active { display:block; }

        /* Settings-Grid */
        .cdc-grid           { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:1.25rem; }
        .cdc-field          { display:flex; flex-direction:column; gap:.4rem; }
        .cdc-label          { font-size:.8rem; font-weight:600; color:var(--cdc-text); }
        .cdc-hint           { font-size:.72rem; color:var(--cdc-muted); margin:0; }

        /* Controls */
        .cdc-input, .cdc-select, .cdc-textarea {
            width:100%; padding:.6rem .75rem; border:1.5px solid var(--cdc-border);
            border-radius:7px; font-size:.875rem; color:var(--cdc-text);
            background:var(--cdc-bg); transition:border-color .2s, box-shadow .2s;
            box-sizing:border-box;
        }
        .cdc-input:focus, .cdc-select:focus, .cdc-textarea:focus {
            outline:none; border-color:var(--cdc-primary);
            box-shadow:0 0 0 3px rgba(37,99,235,.12);
        }
        .cdc-textarea { min-height:100px; resize:vertical; font-family:inherit; }

        /* Color Picker */
        .cdc-color-wrap     { display:flex; gap:.5rem; align-items:center; }
        .cdc-color-picker   { width:48px; height:38px; border:1.5px solid var(--cdc-border); border-radius:7px; padding:2px; cursor:pointer; flex-shrink:0; }
        .cdc-color-text     { flex:1; padding:.5rem .75rem; border:1.5px solid var(--cdc-border); border-radius:7px; font-size:.8rem; font-family:monospace; background:var(--cdc-bg); }

        /* Toggle */
        .cdc-toggle         { position:relative; display:inline-flex; align-items:center; cursor:pointer; }
        .cdc-toggle input   { opacity:0; width:0; height:0; }
        .cdc-toggle-slider  { position:relative; display:inline-block; width:44px; height:24px; background:#cbd5e1; border-radius:12px; transition:background .2s; }
        .cdc-toggle-slider::after { content:''; position:absolute; top:3px; left:3px; width:18px; height:18px; background:#fff; border-radius:50%; transition:transform .2s; box-shadow:0 1px 4px rgba(0,0,0,.2); }
        .cdc-toggle input:checked + .cdc-toggle-slider { background:var(--cdc-primary); }
        .cdc-toggle input:checked + .cdc-toggle-slider::after { transform:translateX(20px); }

        /* Image Upload */
        .cdc-image-upload   { display:flex; flex-direction:column; gap:.5rem; }
        .cdc-img-preview    { max-height:72px; max-width:100%; border-radius:6px; border:1.5px solid var(--cdc-border); object-fit:contain; }
        .cdc-img-placeholder{ height:60px; border:2px dashed var(--cdc-border); border-radius:6px; display:flex; align-items:center; justify-content:center; color:var(--cdc-muted); font-size:.8rem; }

        /* Buttons */
        .cdc-btn            { display:inline-flex; align-items:center; gap:.4rem; padding:.55rem 1.1rem; border-radius:7px; font-size:.85rem; font-weight:600; cursor:pointer; border:none; text-decoration:none; transition:all .2s; }
        .cdc-btn-primary    { background:var(--cdc-primary); color:#fff; }
        .cdc-btn-primary:hover { background:var(--cdc-primary-d); }
        .cdc-btn-ghost      { background:transparent; color:var(--cdc-muted); border:1.5px solid var(--cdc-border); }
        .cdc-btn-ghost:hover { border-color:var(--cdc-primary); color:var(--cdc-primary); }
        .cdc-btn-danger     { background:#fee2e2; color:#991b1b; }
        .cdc-btn-danger:hover { background:#fecaca; }
        .cdc-btn-sm         { padding:.35rem .75rem; font-size:.78rem; }

        /* Alert */
        .cdc-alert          { padding:.75rem 1rem; border-radius:8px; font-size:.875rem; margin-bottom:1.25rem; display:flex; align-items:center; gap:.6rem; }
        .cdc-alert-success  { background:#f0fdf4; border:1px solid #86efac; color:#166534; }
        .cdc-alert-error    { background:#fef2f2; border:1px solid #fca5a5; color:#991b1b; }
        .cdc-alert-info     { background:#eff6ff; border:1px solid #93c5fd; color:#1e40af; }
        .cdc-alert-warning  { background:#fffbeb; border:1px solid #fcd34d; color:#92400e; }

        /* Footer-Bar */
        .cdc-form-footer    { display:flex; align-items:center; justify-content:space-between; padding:1rem 1.5rem; border-top:1px solid var(--cdc-border); background:#f8fafc; gap:.75rem; flex-wrap:wrap; }

        /* Section-Divider */
        .cdc-section        { margin-bottom:2rem; }
        .cdc-section + .cdc-section { padding-top:1.5rem; border-top:1px solid var(--cdc-border); }
        .cdc-section-title  { font-size:.9rem; font-weight:700; color:var(--cdc-text); margin:0 0 1rem 0; display:flex; align-items:center; gap:.5rem; }
    </style>
</head>
<body class="admin-body">

<?php renderAdminSidebar('theme-customizer'); ?>

<main class="admin-content">
<div class="cdc-wrapper">

    <!-- Header -->
    <div class="cdc-header">
        <div class="cdc-header-brand">
            <div class="cdc-header-icon">🎨</div>
            <div>
                <p class="cdc-header-title"><?php echo htmlspecialchars($themeMeta['name']); ?> – Design</p>
                <p class="cdc-header-sub">v<?php echo htmlspecialchars($themeMeta['version']); ?> · <?php echo htmlspecialchars($themeMeta['author']); ?></p>
            </div>
        </div>
        <div class="cdc-header-actions">
            <a href="<?php echo SITE_URL; ?>" target="_blank" class="cdc-btn cdc-btn-ghost cdc-btn-sm">🌐 Vorschau</a>
            <form method="post" style="margin:0" onsubmit="return confirm('Wirklich alle Werte zurücksetzen?');">
                <input type="hidden" name="_csrf"   value="<?php echo $csrfToken; ?>">
                <input type="hidden" name="_action" value="reset_all">
                <button type="submit" class="cdc-btn cdc-btn-ghost cdc-btn-sm">↩ Reset all</button>
            </form>
        </div>
    </div>

    <?php if ($message): ?>
    <div class="cdc-alert cdc-alert-<?php echo htmlspecialchars($messageType); ?>">
        <?php echo $messageType === 'success' ? '✓' : ($messageType === 'error' ? '✕' : 'ℹ'); ?>
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- Two-Column Layout: Nav + Panel -->
    <div class="cdc-layout">

        <!-- Sidebar-Navigation -->
        <nav class="cdc-nav">
            <div class="cdc-nav-header">Einstellungen</div>
            <?php
            $navIcons = [
                'colors'     => '🎨',
                'header'     => '🔝',
                'footer'     => '🔚',
                'typography' => '🆎',
                'layout'     => '📐',
                'hero'       => '✨',
            ];
            foreach ($options as $catKey => $catData): ?>
                <a href="?tab=<?php echo urlencode($catKey); ?>"
                   class="cdc-nav-item <?php echo $activeTab === $catKey ? 'active' : ''; ?>"
                   data-tab="<?php echo htmlspecialchars($catKey); ?>">
                    <span class="cdc-nav-icon"><?php echo $navIcons[$catKey] ?? '⚙️'; ?></span>
                    <?php echo htmlspecialchars($catData['label']); ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <!-- Settings Panel -->
        <div class="cdc-panel">
            <?php foreach ($options as $catKey => $catData):
                $isActive    = $activeTab === $catKey;
                $hasImage    = !empty(array_filter(array_column($catData['settings'], 'type'), fn($t) => $t === 'image'));
                $formSaveId  = 'form-save-'  . $catKey;
                $formResetId = 'form-reset-' . $catKey;
            ?>
            <div class="cdc-tab-content <?php echo $isActive ? 'active' : ''; ?>" data-panel="<?php echo htmlspecialchars($catKey); ?>">

                <!-- Speichern-Formular -->
                <form method="post" id="<?php echo $formSaveId; ?>" <?php echo $hasImage ? 'enctype="multipart/form-data"' : ''; ?>>
                    <input type="hidden" name="_csrf"     value="<?php echo $csrfToken; ?>">
                    <input type="hidden" name="_action"   value="save">
                    <input type="hidden" name="_category" value="<?php echo htmlspecialchars($catKey); ?>">

                    <div class="cdc-panel-head">
                        <div>
                            <p class="cdc-panel-title">
                                <?php echo ($navIcons[$catKey] ?? '⚙️') . ' ' . htmlspecialchars($catData['label']); ?>
                            </p>
                            <?php if (!empty($catData['description'])): ?>
                                <p class="cdc-panel-desc"><?php echo htmlspecialchars($catData['description']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="cdc-panel-body">
                        <div class="cdc-grid">
                            <?php foreach ($catData['settings'] as $settingKey => $setting):
                                $val = $customizer->get($catKey, $settingKey, $setting['default'] ?? '');
                                cmsDefaultRenderControl($catKey, $settingKey, $setting, $val);
                            endforeach; ?>
                        </div>
                    </div>

                    <div class="cdc-form-footer">
                        <!-- Zurücksetzen-Button referenziert das separate Reset-Formular via form="" -->
                        <button type="submit"
                                form="<?php echo $formResetId; ?>"
                                class="cdc-btn cdc-btn-ghost cdc-btn-sm"
                                onclick="return confirm('Kategorie zurücksetzen?')">
                            ↩ Zurücksetzen
                        </button>
                        <button type="submit" class="cdc-btn cdc-btn-primary">
                            💾 Speichern
                        </button>
                    </div>
                </form>

                <!-- Reset-Formular – getrennt vom Speichern-Formular (kein Nesting!) -->
                <form method="post" id="<?php echo $formResetId; ?>" style="display:none">
                    <input type="hidden" name="_csrf"     value="<?php echo $csrfToken; ?>">
                    <input type="hidden" name="_action"   value="reset_category">
                    <input type="hidden" name="_category" value="<?php echo htmlspecialchars($catKey); ?>">
                </form>

            </div>
            <?php endforeach; ?>
        </div>

    </div><!-- /.cdc-layout -->
</div><!-- /.cdc-wrapper -->
</main>

<script>
/* Color-Picker ↔ Text-Input sync */
document.querySelectorAll('.cdc-color-wrap').forEach(wrap => {
    const picker = wrap.querySelector('.cdc-color-picker');
    const text   = wrap.querySelector('.cdc-color-text');
    if (!picker || !text) return;
    picker.addEventListener('input', () => { text.value = picker.value; });
    text.addEventListener('input', () => {
        if (/^#([0-9a-f]{3}){1,2}$/i.test(text.value)) picker.value = text.value;
    });
    text.removeAttribute('name');
});

/* Tab-Navigation ohne Seiten-Reload */
document.querySelectorAll('.cdc-nav-item[data-tab]').forEach(link => {
    link.addEventListener('click', e => {
        const tab = link.dataset.tab;
        document.querySelectorAll('.cdc-nav-item').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        document.querySelectorAll('.cdc-tab-content').forEach(p => p.classList.remove('active'));
        const panel = document.querySelector('[data-panel="' + tab + '"]');
        if (panel) { panel.classList.add('active'); e.preventDefault(); }
    });
});

/* Homepage-Modus: Hero-Felder ein-/ausblenden */
(function () {
    const modeSelect = document.getElementById('cms_hero_homepage_mode');
    if (!modeSelect) return;

    // IDs aller Felder die nur im Hero-Modus relevant sind
    const heroOnlyKeys = [
        'hero_title', 'hero_subtitle', 'hero_description',
        'hero_button_primary_text', 'hero_button_primary_url',
        'hero_button_secondary_text', 'hero_button_secondary_url',
        'hero_gradient_start', 'hero_gradient_end'
    ];

    function toggleHeroFields(mode) {
        heroOnlyKeys.forEach(key => {
            const field = document.getElementById('cms_hero_' + key);
            if (!field) return;
            const wrap = field.closest('.cdc-field');
            if (!wrap) return;
            wrap.style.display = (mode === 'landing') ? 'none' : '';
        });

        // Hinweis-Banner ein-/ausblenden
        let banner = document.getElementById('cdc-landing-hint');
        if (mode === 'landing') {
            if (!banner) {
                banner = document.createElement('div');
                banner.id = 'cdc-landing-hint';
                banner.className = 'cdc-alert cdc-alert-info';
                banner.style.marginTop = '1rem';
                banner.innerHTML = 'ℹ️ Die Startseite zeigt die <strong>Landing Page</strong> an. '
                    + 'Inhalte (Titel, Features, Farben) werden unter '
                    + '<a href="/admin/landing-page" style="color:inherit;font-weight:700;">'
                    + 'Admin → Landing Page</a> verwaltet.';
                const grid = modeSelect.closest('.cdc-field').closest('.cdc-grid');
                if (grid) grid.insertAdjacentElement('afterend', banner);
            }
            banner.style.display = '';
        } else if (banner) {
            banner.style.display = 'none';
        }
    }

    // Initial state
    toggleHeroFields(modeSelect.value);
    modeSelect.addEventListener('change', () => toggleHeroFields(modeSelect.value));
})();
</script>

</body>
</html>
