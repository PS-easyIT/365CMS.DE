<?php
/**
 * Page Template – Einzelne CMS-Seite
 *
 * @package CMS_Default_Theme
 * @var array $page  Felder: id, title, slug, content, meta_description, status, created_at, updated_at
 */

if (!defined('ABSPATH')) {
    exit;
}

if (empty($page) || !is_array($page)) {
    http_response_code(404);
    \CMS\ThemeManager::instance()->render('404');
    return;
}

$pageTitle   = $page['title']      ?? '';
$pageContent = $page['content']    ?? '';
$pageSlug    = $page['slug']       ?? '';
$updatedAt   = $page['updated_at'] ?? '';
$createdAt   = $page['created_at'] ?? '';
?>

<main id="main" class="site-main" role="main">
    <div class="container">
        <div class="content-area">

            <!-- Breadcrumb -->
            <?php if ($pageSlug && $pageSlug !== 'home') : ?>
            <nav class="breadcrumb" aria-label="Brotkrümelnavigation">
                <a href="<?php echo htmlspecialchars(SITE_URL, ENT_QUOTES, 'UTF-8'); ?>/">Startseite</a>
                <span class="breadcrumb-sep" aria-hidden="true">/</span>
                <span class="breadcrumb-current">
                    <?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?>
                </span>
            </nav>
            <?php endif; ?>

            <article class="entry-article" itemscope itemtype="https://schema.org/WebPage">

                <?php if ($pageTitle && trim($pageTitle) !== '') : ?>
                <header class="entry-header">
                    <h1 class="page-title" itemprop="name">
                        <?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?>
                    </h1>
                    <?php if ($createdAt && trim($createdAt) !== '') : ?>
                    <div class="entry-meta">
                        <time datetime="<?php echo htmlspecialchars($createdAt, ENT_QUOTES, 'UTF-8'); ?>"
                              itemprop="datePublished">
                            <?php echo htmlspecialchars(date('d. F Y', strtotime($createdAt)), ENT_QUOTES, 'UTF-8'); ?>
                        </time>
                    </div>
                    <?php endif; ?>
                </header>
                <?php endif; ?>

                <?php if ($pageContent && trim($pageContent) !== '') : ?>
                <div class="entry-content" itemprop="text">
                    <?php theme_the_content($pageContent); ?>
                </div>
                <?php endif; ?>

                <?php if ($updatedAt && trim($updatedAt) !== '') : ?>
                <footer class="entry-footer">
                    <span class="entry-meta">
                        Zuletzt aktualisiert:
                        <time datetime="<?php echo htmlspecialchars($updatedAt, ENT_QUOTES, 'UTF-8'); ?>"
                              itemprop="dateModified">
                            <?php echo htmlspecialchars(date('d.m.Y', strtotime($updatedAt)), ENT_QUOTES, 'UTF-8'); ?>
                        </time>
                    </span>
                </footer>
                <?php endif; ?>

            </article>

        </div>
    </div>
</main>
