CREATE TABLE IF NOT EXISTS `cms_orders` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `order_number` varchar(50) NOT NULL,
    `user_id` int(11) NOT NULL,
    `plan_id` int(11) NOT NULL,
    `status` enum('pending','completed','cancelled') DEFAULT 'pending',
    `total_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
    `payment_method` varchar(50) DEFAULT NULL,
    `billing_address` text DEFAULT NULL,
    `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`),
    KEY `order_number` (`order_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `cms_settings` (`setting_key`, `setting_value`, `setting_group`)
SELECT 'order_number_format', 'ORD-{Y}-{ID}', 'orders'
WHERE NOT EXISTS (SELECT 1 FROM `cms_settings` WHERE `setting_key` = 'order_number_format');
