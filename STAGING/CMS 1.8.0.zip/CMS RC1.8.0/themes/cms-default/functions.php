﻿<?php
/**
 * CMS Default Theme - Functions
 *
 * Universelles Theme für das CMSv2-System.
 * Einsetzbar für Blogs, Business-Sites, Portfolios und allgemeine CMS-Seiten.
 *
 * @package CMS_Default_Theme
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

define('DEFAULT_THEME_VERSION', '1.0.0');
define('DEFAULT_THEME_DIR', THEME_PATH . 'cms-default/');
define('DEFAULT_THEME_URL', \CMS\ThemeManager::instance()->getThemeUrl());

/**
 * CMS Default Theme Bootstrap
 */
class CMS_Default_Theme
{
    private static ?self $instance = null;

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        // Assets im <head>
        \CMS\Hooks::addAction('head', [$this, 'enqueueStyles']);
        \CMS\Hooks::addAction('head', [$this, 'outputMetaTags']);
        \CMS\Hooks::addAction('head', [$this, 'outputGoogleFonts'], 5);
        \CMS\Hooks::addAction('head', [$this, 'outputCustomStyles'], 20);
        \CMS\Hooks::addAction('head', [$this, 'outputPreconnect'], 1);
        \CMS\Hooks::addAction('head', [$this, 'outputCustomHeaderCode'], 99);
        \CMS\Hooks::addAction('head', [$this, 'outputAnalyticsHeadCode'], 98);
        \CMS\Hooks::addAction('body_open', [$this, 'outputAnalyticsBodyCode'], 1);

        // Footer
        \CMS\Hooks::addAction('before_footer', [$this, 'enqueueScripts']);
        \CMS\Hooks::addAction('before_footer', [$this, 'outputCookieBanner'], 10);

        // Navigation
        \CMS\Hooks::addFilter('register_menu_locations', [$this, 'registerMenuLocations']);

        // Standard-Menüs beim ersten Start
        \CMS\Hooks::addAction('cms_init', [$this, 'seedDefaultMenus']);
    }

    /**
     * Custom Header Code (aus SEO-Einstellungen)
     */
    public function outputCustomHeaderCode(): void
    {
        try {
            $code = \CMS\Services\SEOService::getInstance()->getCustomHeaderCode();
            if (!empty($code)) {
                echo "\n<!-- Custom Header Code -->\n" . $code . "\n<!-- /Custom Header Code -->\n";
            }
        } catch (\Throwable $e) {
            // SEOService nicht verfügbar
        }
    }

    /**
     * Analytics Head Code (Matomo, GA4, GTM, FB Pixel, Eigener Code)
     * Wird automatisch per Hook in <head> ausgegeben.
     */
    public function outputAnalyticsHeadCode(): void
    {
        try {
            $code = \CMS\Services\SEOService::getInstance()->getAnalyticsHeadCode();
            if (!empty($code)) {
                echo $code;
            }
        } catch (\Throwable $e) {
            // SEOService nicht verfügbar
        }
    }

    /**
     * Analytics Body Code (GTM noscript, Eigener Body-Code)
     * Wird per Hook direkt nach <body> ausgegeben.
     */
    public function outputAnalyticsBodyCode(): void
    {
        try {
            $code = \CMS\Services\SEOService::getInstance()->getAnalyticsBodyCode();
            if (!empty($code)) {
                echo $code;
            }
        } catch (\Throwable $e) {
            // SEOService nicht verfügbar
        }
    }

    /**
     * Cookie Banner einbinden
     */
    public function outputCookieBanner(): void
    {
        try {
            $db = \CMS\Database::instance();
            $enabled = $db->execute(
                "SELECT option_value FROM {$db->getPrefix()}settings WHERE option_name = 'cookie_consent_enabled'"
            )->fetch();

            if (!$enabled || $enabled->option_value !== '1') {
                return;
            }

            $keys     = ['cookie_banner_position','cookie_banner_text','cookie_accept_text','cookie_essential_text','cookie_policy_url','cookie_primary_color'];
            $settings = [];
            foreach ($keys as $k) {
                $row = $db->execute(
                    "SELECT option_value FROM {$db->getPrefix()}settings WHERE option_name = ?", [$k]
                )->fetch();
                $settings[$k] = $row ? $row->option_value : '';
            }

            $pos         = $settings['cookie_banner_position'] ?: 'bottom';
            $text        = htmlspecialchars($settings['cookie_banner_text']      ?: 'Wir verwenden Cookies, um Ihnen die bestmögliche Erfahrung zu bieten.', ENT_QUOTES, 'UTF-8');
            $btnAccept   = htmlspecialchars($settings['cookie_accept_text']      ?: 'Alle akzeptieren', ENT_QUOTES, 'UTF-8');
            $btnEssential = htmlspecialchars($settings['cookie_essential_text'] ?: 'Nur notwendige', ENT_QUOTES, 'UTF-8');
            $linkPolicy  = htmlspecialchars($settings['cookie_policy_url']      ?: '/datenschutz', ENT_QUOTES, 'UTF-8');
            $color       = htmlspecialchars($settings['cookie_primary_color']   ?: '#2563eb', ENT_QUOTES, 'UTF-8');

            $posStyle = $pos === 'bottom'
                ? 'position:fixed;bottom:0;left:0;width:100%;border-top:1px solid #e5e7eb;'
                : 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:90%;max-width:480px;border-radius:12px;';

            echo <<<HTML
<style>
#cms-cookie-banner{background:#fff;color:#374151;padding:1rem 1.5rem;z-index:9999;display:none;font-family:sans-serif;font-size:14px;line-height:1.5;box-shadow:0 -4px 20px rgba(0,0,0,0.08);{$posStyle}}
#cms-cookie-banner p{margin:0 0 0.75rem}
#cms-cookie-actions{display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap}
.cms-cookie-btn{border:none;padding:8px 18px;border-radius:8px;cursor:pointer;font-weight:600;font-size:13px;transition:opacity .2s}
.cms-cookie-btn:hover{opacity:.85}
.cms-cookie-accept{background:{$color};color:#fff}
.cms-cookie-essential{background:#f3f4f6;color:#374151}
</style>
<div id="cms-cookie-banner" role="dialog" aria-label="Cookie-Einstellungen">
    <p>{$text} <a href="{$linkPolicy}" style="color:{$color};text-decoration:underline">Mehr erfahren</a></p>
    <div id="cms-cookie-actions">
        <button class="cms-cookie-btn cms-cookie-essential" onclick="cmsDeclineCookies()">{$btnEssential}</button>
        <button class="cms-cookie-btn cms-cookie-accept" onclick="cmsAcceptCookies()">{$btnAccept}</button>
    </div>
</div>
<script>
(function(){var b=document.getElementById('cms-cookie-banner');if(!localStorage.getItem('cms_cookie_consent'))b.style.display='block';
window.cmsAcceptCookies=function(){localStorage.setItem('cms_cookie_consent','all');b.style.display='none'};
window.cmsDeclineCookies=function(){localStorage.setItem('cms_cookie_consent','essential');b.style.display='none'}})();
</script>
HTML;
        } catch (\Throwable $e) {
            // Cookie-Banner nicht verfügbar
        }
    }

    /**
     * Menüpositionen registrieren
     */
    public function registerMenuLocations(array $locations): array
    {
        $locations[] = ['slug' => 'primary', 'label' => 'Hauptmenü (Header)'];
        $locations[] = ['slug' => 'mobile',  'label' => 'Mobiles Menü (Drawer)'];
        $locations[] = ['slug' => 'footer',  'label' => 'Footer-Navigation'];
        return $locations;
    }

    /**
     * Standard-Menüeinträge beim ersten Start anlegen
     */
    public function seedDefaultMenus(): void
    {
        $themeManager = \CMS\ThemeManager::instance();

        $defaults = [
            'primary' => [
                ['label' => 'Startseite', 'url' => '/',        'target' => '_self'],
                ['label' => 'Über uns',   'url' => '/about',   'target' => '_self'],
                ['label' => 'Leistungen', 'url' => '/services','target' => '_self'],
                ['label' => 'Blog',       'url' => '/blog',    'target' => '_self'],
                ['label' => 'Kontakt',    'url' => '/contact', 'target' => '_self'],
            ],
            'mobile'  => [
                ['label' => 'Startseite', 'url' => '/',        'target' => '_self'],
                ['label' => 'Über uns',   'url' => '/about',   'target' => '_self'],
                ['label' => 'Leistungen', 'url' => '/services','target' => '_self'],
                ['label' => 'Blog',       'url' => '/blog',    'target' => '_self'],
                ['label' => 'Kontakt',    'url' => '/contact', 'target' => '_self'],
                ['label' => 'Login',      'url' => '/login',   'target' => '_self'],
            ],
            'footer'  => [
                ['label' => 'Impressum',   'url' => '/impressum',   'target' => '_self'],
                ['label' => 'Datenschutz', 'url' => '/datenschutz', 'target' => '_self'],
                ['label' => 'AGB',         'url' => '/agb',         'target' => '_self'],
                ['label' => 'Kontakt',     'url' => '/contact',     'target' => '_self'],
            ],
        ];

        foreach ($defaults as $location => $items) {
            if (empty($themeManager->getMenu($location))) {
                $themeManager->saveMenu($location, $items);
            }
        }
    }

    /**
     * Stylesheets einbinden
     */
    public function enqueueStyles(): void
    {
        $v = DEFAULT_THEME_VERSION;
        echo '<link rel="stylesheet" href="' . DEFAULT_THEME_URL . '/style.css?v=' . $v . '">' . "\n";
    }

    /**
     * JavaScript einbinden (am Ende des Body)
     */
    public function enqueueScripts(): void
    {
        $v = DEFAULT_THEME_VERSION;
        echo '<script src="' . DEFAULT_THEME_URL . '/js/navigation.js?v=' . $v . '"></script>' . "\n";
        echo '<script src="' . DEFAULT_THEME_URL . '/js/theme.js?v=' . $v . '"></script>' . "\n";
    }

    /**
     * Meta-Tags ausgeben
     */
    public function outputMetaTags(): void
    {
        $themeManager = \CMS\ThemeManager::instance();
        $siteDesc  = htmlspecialchars($themeManager->getSiteDescription(), ENT_QUOTES, 'UTF-8');
        $siteTitle = htmlspecialchars($themeManager->getSiteTitle(),        ENT_QUOTES, 'UTF-8');
        $siteUrl   = htmlspecialchars(SITE_URL,                             ENT_QUOTES, 'UTF-8');

        echo '<meta name="description" content="' . $siteDesc . '">' . "\n";
        echo '<meta property="og:type" content="website">' . "\n";
        echo '<meta property="og:site_name" content="' . $siteTitle . '">' . "\n";
        echo '<meta property="og:url" content="' . $siteUrl . '">' . "\n";
        echo '<meta name="theme-color" content="#2563eb">' . "\n";
        echo '<meta name="robots" content="index,follow">' . "\n";
    }

    /**
     * Preconnect Hints für Performance
     */
    public function outputPreconnect(): void
    {
        try {
            $db       = \CMS\Database::instance();
            $useLocal = $db->execute(
                "SELECT option_value FROM {$db->getPrefix()}settings WHERE option_name = 'privacy_use_local_fonts'"
            )->fetch();

            if ($useLocal && $useLocal->option_value === '1') {
                return;
            }
        } catch (\Throwable $e) {
            // DB nicht verfügbar – sicherheitshalber laden
        }

        echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
        echo '<link rel="dns-prefetch" href="//fonts.googleapis.com">' . "\n";
    }

    /**
     * Google Fonts einbinden (basierend auf Typography-Einstellungen)
     */
    public function outputGoogleFonts(): void
    {
        try {
            $db       = \CMS\Database::instance();
            $useLocal = $db->execute(
                "SELECT option_value FROM {$db->getPrefix()}settings WHERE option_name = 'privacy_use_local_fonts'"
            )->fetch();

            if ($useLocal && $useLocal->option_value === '1') {
                if (file_exists(ASSETS_PATH . 'css/local-fonts.css')) {
                    echo '<link rel="stylesheet" href="' . SITE_URL . '/assets/css/local-fonts.css">' . "\n";
                }
                return;
            }
        } catch (\Throwable $e) {
            // DB nicht verfügbar
        }

        try {
            $customizer  = \CMS\Services\ThemeCustomizer::instance();
            $typo        = $customizer->getCategory('typography');
            $googleFonts = ['inter','roboto','open-sans','lato','montserrat','poppins','raleway'];
            $fontMap     = [
                'inter'      => 'Inter:wght@400;500;600;700;800',
                'roboto'     => 'Roboto:wght@400;500;700',
                'open-sans'  => 'Open+Sans:wght@400;600;700',
                'lato'       => 'Lato:wght@400;700',
                'montserrat' => 'Montserrat:wght@400;500;600;700',
                'poppins'    => 'Poppins:wght@400;500;600;700',
                'raleway'    => 'Raleway:wght@400;600;700',
            ];

            $fontsToLoad  = [];
            $baseFont     = $typo['font_family_base']    ?? 'inter';
            $headingFont  = $typo['font_family_heading'] ?? 'inter';

            if (in_array($baseFont, $googleFonts, true) && isset($fontMap[$baseFont])) {
                $fontsToLoad[$baseFont] = $fontMap[$baseFont];
            }
            if ($headingFont !== $baseFont && in_array($headingFont, $googleFonts, true) && isset($fontMap[$headingFont])) {
                $fontsToLoad[$headingFont] = $fontMap[$headingFont];
            }

            if (!empty($fontsToLoad)) {
                $families = implode('&family=', array_values($fontsToLoad));
                $url = 'https://fonts.googleapis.com/css2?family=' . $families . '&display=swap';
                echo '<link rel="stylesheet" href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">' . "\n";
            }
        } catch (\Throwable $e) {
            // Fallback auf System-Fonts
        }
    }

    /**
     * Benutzerdefinierte CSS-Variablen aus Customizer
     */
    public function outputCustomStyles(): void
    {
        try {
            $customizer = \CMS\Services\ThemeCustomizer::instance();
            $css        = $customizer->generateCSS();

            // Theme-spezifische CSS-Variablen ergänzen (nicht in generateCSS() enthalten)
            $extraVars = '';

            $headerAccent = $customizer->get('header', 'header_border_color');
            if (!empty($headerAccent)) {
                $extraVars .= "    --header-accent: " . htmlspecialchars($headerAccent, ENT_QUOTES, 'UTF-8') . ";\n";
            }

            $headingColor = $customizer->get('colors', 'heading_color');
            if (!empty($headingColor)) {
                $extraVars .= "    --heading-color: " . htmlspecialchars($headingColor, ENT_QUOTES, 'UTF-8') . ";\n";
            }

            if (!empty($extraVars)) {
                $css .= "\n/* Theme-spezifische Variablen */\n:root {\n" . $extraVars . "}\n";
            }

            if (trim($css) !== '') {
                echo '<style id="cms-theme-customizer">' . "\n" . $css . '</style>' . "\n";
            }
        } catch (\Throwable $e) {
            // Customizer nicht verfügbar – Default-CSS aus style.css greift
        }
    }
}

// Theme initialisieren
CMS_Default_Theme::instance();

// ============================================================
// HELPER FUNCTIONS
// ============================================================

/**
 * Aktuelle Seiten-URL ermitteln
 */
function theme_current_url(): string
{
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    return rtrim(SITE_URL, '/') . $uri;
}

/**
 * Prüft ob eine URL der aktuellen Seite entspricht (für aktive Nav-Links)
 */
function theme_is_active_url(string $url): bool
{
    $requestUri = rtrim($_SERVER['REQUEST_URI'] ?? '/', '/');
    $path       = rtrim(parse_url($url, PHP_URL_PATH) ?? '/', '/');

    if ($path === '' || $path === '/') {
        return $requestUri === '' || $requestUri === '/';
    }

    return str_starts_with($requestUri, $path);
}

/**
 * CSRF-Token generieren
 */
function theme_csrf_token(string $action = 'form'): string
{
    return \CMS\Security::instance()->generateToken($action);
}

/**
 * CSRF-Hidden-Field ausgeben
 */
function theme_csrf_field(string $action = 'form'): void
{
    $token = theme_csrf_token($action);
    echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">' . "\n";
}

/**
 * Flash-Nachricht aus Session lesen und löschen
 */
function theme_get_flash(string $type = 'error'): string
{
    $key = ($type === 'success') ? 'success' : 'error';
    $msg = $_SESSION[$key] ?? '';
    unset($_SESSION[$key]);
    return is_string($msg) ? $msg : '';
}

/**
 * Prüft ob Nutzer eingeloggt ist
 */
function theme_is_logged_in(): bool
{
    return \CMS\Auth::instance()->isLoggedIn();
}

/**
 * Navigationsmenü für eine Position rendern
 */
function theme_nav_menu(string $location = 'primary'): void
{
    $themeManager = \CMS\ThemeManager::instance();
    $menuItems    = $themeManager->getMenu($location);

    if (empty($menuItems)) {
        return;
    }

    echo '<ul class="nav-menu">' . "\n";
    foreach ($menuItems as $item) {
        $isActive = theme_is_active_url($item['url'] ?? '');
        $class    = $isActive ? ' class="active"' : '';
        $target   = (!empty($item['target']) && $item['target'] === '_blank')
            ? ' target="_blank" rel="noopener noreferrer"' : '';
        $url   = htmlspecialchars($item['url']   ?? '#', ENT_QUOTES, 'UTF-8');
        $label = htmlspecialchars($item['label'] ?? '',  ENT_QUOTES, 'UTF-8');
        echo '<li' . $class . '><a href="' . $url . '"' . $target . '>' . $label . '</a></li>' . "\n";
    }
    echo '</ul>' . "\n";
}

/**
 * Standard-Seiteninhalt mit erlaubten HTML-Tags ausgeben
 */
function theme_the_content(string $content): void
{
    $allowed = '<p><br><strong><b><em><i><u><s>'
        . '<h1><h2><h3><h4><h5><h6>'
        . '<ul><ol><li>'
        . '<a><img>'
        . '<blockquote><pre><code>'
        . '<table><thead><tbody><tr><th><td>'
        . '<div><span><section><article><aside>'
        . '<hr><figure><figcaption>'
        . '<mark><small><sub><sup>';
    echo strip_tags($content, $allowed);
}
