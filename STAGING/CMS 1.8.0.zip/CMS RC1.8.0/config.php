<?php
/**
 * CMS Configuration File
 * 
 * SECURITY: Keep this file outside web root in production!
 * 
 * @package 365CMS
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}

// Debug Mode (DISABLE in production!)
define('CMS_DEBUG', true);

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'u185238248_CMS365v1');
define('DB_USER', 'u185238248_CMS365v1');
define('DB_PASS', '%F9NQu#guJ@4*6');
define('DB_CHARSET', 'utf8mb4');
define('DB_PREFIX', 'cms_');

// Security Keys (CHANGE THESE!)
define('AUTH_KEY', 'put-your-unique-phrase-here-change-in-production');
define('SECURE_AUTH_KEY', 'put-your-unique-phrase-here-change-in-production');
define('NONCE_KEY', 'put-your-unique-phrase-here-change-in-production');

// Site Configuration
define('SITE_NAME', '365CMS.DE');
define('SITE_URL', 'https://365cms.de'); // NIEMALS mit Unterverzeichnis!
define('ADMIN_EMAIL', 'admin@example.com');
define('CMS_VERSION', '1.6.14');

// Paths
define('CORE_PATH', ABSPATH . 'core/');
define('THEME_PATH', ABSPATH . 'themes/');
define('PLUGIN_PATH', ABSPATH . 'plugins/');
define('UPLOAD_PATH', ABSPATH . 'uploads/');
define('ASSETS_PATH', ABSPATH . 'assets/');

// URLs (NIEMALS in Unterverzeichnis)
define('SITE_URL_PATH', '/');
define('ASSETS_URL', SITE_URL . '/assets');
define('UPLOAD_URL', SITE_URL . '/uploads');

// System Settings
define('DEFAULT_THEME', 'cms-default');
define('SESSIONS_LIFETIME', 3600 * 2); // 2 hours
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_TIMEOUT', 300); // 5 minutes

// Error Reporting
if (CMS_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    ini_set('log_errors', '1');
    ini_set('error_log', ABSPATH . 'logs/error.log');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '0');  // keine Logdateien im Produktivbetrieb
}

// Timezone
date_default_timezone_set('Europe/Berlin');
